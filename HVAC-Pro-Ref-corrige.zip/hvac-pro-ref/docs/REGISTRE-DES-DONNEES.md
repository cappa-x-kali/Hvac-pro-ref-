# Registre de provenance des donnees

Ce registre distingue les donnees presentes dans le produit de celles dont la provenance a ete demontree. Une donnee integree au catalogue n'est pas automatiquement une donnee validee.

| Jeu de donnees | Fichier principal | Statut dans l'archive | Travail requis avant de le presenter comme reference |
|---|---|---|---|
| Refrigerants P/T | `packages/mobile/data/refrigerants.ts` | Indicatif; provenance et version absentes | Verifier les valeurs et publier source/version; ajouter les courbes bulle/rosee des melanges |
| Modeles et specifications | `catalog-qc.ts`, `models.ts`, `multizone.ts` | Plusieurs fiches sont marquees approximatives | Relier chaque combinaison exacte interieur/exterieur a une fiche constructeur ou AHRI |
| Codes d'erreur | `errors-mural.ts`, `errors-central.ts`, `code-details.ts` | Sources non attachees a chaque code | Ajouter fabricant, famille, modele, annees, document et page; signaler les codes generiques |
| Marques et documentation | `brands.ts` | Liens de recherche/documentation | Verifier que les liens menent aux portails officiels et qu'ils restent actifs |
| Pieces et compatibilite | `parts.ts` | Provenance par piece non explicitee | Ajouter reference constructeur, modele compatible et date de verification |
| Protocoles infrarouges | `ir-protocols.ts`, module `ir-blaster` | Implementation presente; couverture non certifiee | Tester sur appareils reels et consigner marque, modele, trame, repetition et resultat |
| Formules des outils | `components/tools/*.tsx` | Formules et heuristiques embarquees; revue independante absente | Revue par technicien/formateur, jeux de cas et tolerances documentees |

## Regle editoriale

Une fiche doit afficher l'etat de validation : `Verifiee constructeur`, `Verifiee source secondaire`, `Indicative`, ou `A verifier`. Ne pas transformer une estimation en valeur certifiee par simple reformulation.
