# Validation technique — HVAC Pro Ref

## Statut des donnees de refrigerants

Les quatre tableaux P/T historiques fournis avec le projet sont conserves pour ne pas supprimer une fonction existante, mais ils sont explicitement classes comme **indicatifs / non certifies**. L'archive ne contenait pas de references de source, de version de donnees, ni de provenance suffisante pour affirmer une precision metrologique.

- Plage d'utilisation logicielle : -40 a +60 °C uniquement.
- Aucune extrapolation hors plage : le calcul retourne `NaN`, presente dans l'interface comme « Hors plage ».
- Un identifiant de refrigerant inconnu ne bascule plus silencieusement sur le R-410A.
- R-454B : la courbe interne est identifiee comme point de bulle seulement. La surchauffe est donc desactivee tant que la courbe de rosee fabricant n'est pas integree. Le sous-refroidissement reste indicatif et doit etre confirme avec le fabricant.
- L'interpolation actuelle est une interpolation numerique entre points; ce n'est pas une equation d'etat certifiee.

## Conditions pour une validation de niveau professionnel

Chaque jeu de donnees P/T doit etre reconstruit ou verifie a partir d'une source primaire identifiee (fabricant du refrigerant, logiciel de proprietes reconnu, ou documentation technique fiable), avec :

1. Source, URL ou reference documentaire, date et version.
2. Pressions absolues clairement distinguees des pressions manometriques.
3. Pour chaque melange zeotropique : courbes bulle et rosee distinctes, composition et glide.
4. Unite, plage, methode d'interpolation et tolerance declarees.
5. Jeux de tests avec points de controle publies et tests de regression.

Ne pas utiliser les donnees indicatives de l'application comme unique base pour charger, recuperer, diagnostiquer ou mettre en service un circuit frigorifique.

## Limites de calcul a documenter

Les calculateurs de dimensionnement, de charge thermique, de debit, d'electricite et de recuperation sont des outils d'estimation. Les resultats doivent etre rapproches des plaques signaletiques, manuels de service, exigences du fabricant, normes et codes applicables au lieu des travaux. En particulier, le dimensionnement des conducteurs et protections ne peut pas etre certifie sans les conditions d'installation, materiaux, temperature, nombre de conducteurs, longueur, chute de tension, regles locales et donnees de plaque.

## Tests automatises

Depuis la racine :

```bash
bun run test:refrigerants
```

Le test verifie les points tabules, la monotonie, les limites de plage, l'inversion pression/temperature, les conversions et le comportement des identifiants inconnus.
