# Liste de controle avant publication

## Securite et configuration

- [ ] Copier `.env.template` vers `.env` et renseigner les secrets localement.
- [ ] Ne jamais joindre `.env`, `packages/mobile/.env`, certificats, cles ou jetons a une archive de livraison.
- [ ] Renouveler les secrets qui ont deja ete partages dans une archive ou un depot accessible.
- [ ] Verifier les domaines autorises, CORS, authentification, autorisations et politique de confidentialite.
- [ ] Verifier les permissions Android/iOS et la politique de conservation des photos et pieces jointes.

## Qualite logicielle

- [ ] `bun install`
- [ ] `bun run test:refrigerants`
- [ ] `bun run typecheck`
- [ ] `bun run lint`
- [ ] `bun run build`
- [ ] Tester sur appareils Android reels, dont un appareil sans emetteur IR.
- [ ] Tester le mode hors ligne, la restauration des donnees locales et les migrations.
- [ ] Tester les langues francaise et anglaise, les unites imperiales et metriques.

## Validation metier

- [ ] Faire valider chaque formule par un technicien/formateur qualifie.
- [ ] Ajouter la source et la date de verification a chaque table, modele et code defaut.
- [ ] Comparer les tableaux P/T a une source primaire pour chaque refrigerant.
- [ ] Ajouter les courbes bulle/rosee des melanges zeotropiques.
- [ ] Verifier les facteurs de charge, les conversions, les limites et les messages d'alerte.
- [ ] Ne pas presenter un resultat indicatif comme une prescription ou une conformite au code.

## Publication

- [ ] Confirmer l'identifiant Android/iOS deja publie avant toute modification.
- [ ] Definir `EXPO_PUBLIC_API_URL` vers le backend de production dans l'environnement EAS (le build production echoue volontairement si absent).
- [ ] Verifier que le backend de production n'est pas une URL `preview`.
- [ ] Generer les builds de production avec les secrets de signature stockes hors du depot.
- [ ] Verifier que le build Electron contient `packages/desktop/web-dist/index.html` apres la compilation Web.
- [ ] Tester l'APK/AAB signe sur un appareil propre.
- [ ] Verifier sauvegarde, export, politique de confidentialite, mentions legales et support.
