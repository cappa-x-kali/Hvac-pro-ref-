# HVAC Pro Ref — Design

## Concept
Outil de référence terrain pour techniciens HVAC (Québec/Canada). Ton professionnel, lisible au soleil, "friendly".
Dualité froid/chaud : bleu glacier (refroidissement) + orange braise (chauffage) en accents.

## Typographie
- Titres : **Sora** (600/700) — géométrique, technique.
- Texte : **Manrope** (400/500/700) — très lisible en petite taille.
- Chiffres de résultats : Sora 700, grande taille (28–40).

## Thèmes (sélectionnables dans Réglages)
| Thème | Fond | Carte | Primaire | Accent |
|---|---|---|---|---|
| Glacier (clair, défaut) | #EEF3F9 | #FFFFFF | #0B6BCB | #FF7A1A |
| Nuit technique (sombre) | #0A0F17 | #131B26 | #4CC2FF | #FF9447 |
| Braise (chaud clair) | #FBF5EF | #FFFFFF | #C2410C | #0E7490 |
| Forêt (vert) | #EFF5F0 | #FFFFFF | #1F7A4D | #D99A0B |
| Chantier (contraste élevé) | #000000 | #121212 | #FFD400 | #22D3EE |
+ "Auto" = Glacier / Nuit selon le système.

## Composants
- En-tête : dégradé primaire → primaire foncé, coins inférieurs arrondis 28, titre Sora blanc.
- Cartes : rayon 18, bordure 1px `border`, aucune ombre lourde.
- Puces (chips) de filtre : rayon 999, fond `muted`, actif = `primary`.
- Pastilles réfrigérant : R22 gris-brun, R410A rose, R32 bleu ciel, R454B vert.
- Avatars de marque : cercle couleur marque + initiales (pas de logos).
- Espacement : 4/8/12/16/20/24.

## UX
- Favoris : la marque principale et les marques favorites apparaissent toujours en premier.
- Tout fonctionne hors-ligne ; notes et modèles perso stockés localement.
- Avertissement discret : valider avec le manuel officiel du fabricant.
