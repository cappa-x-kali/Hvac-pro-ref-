# HVAC Pro Ref

Application de reference technique pour les professionnels du chauffage, de la ventilation, de la climatisation et de la refrigeration.

Le depot contient trois clients :

- `packages/mobile` : application Android/iOS construite avec Expo et React Native.
- `packages/web` : interface Web et API Hono/oRPC.
- `packages/desktop` : application de bureau Electron qui embarque l'interface Web.

## Demarrage

Prerequis : Bun 1.3.14 et un environnement Node compatible avec Expo 54.

```bash
cp .env.template .env
bun install
bun run dev:mobile
```

Pour lancer le Web :

```bash
bun run dev
```

Pour lancer le client bureau en developpement :

```bash
bun run dev:desktop
```

Pour produire un APK de test ou un AAB de publication Android avec EAS :

```bash
bun run build:android:preview
bun run build:android:production
```

Le profil `production` exige `EXPO_PUBLIC_API_URL` configure vers le backend de production. Le profil `preview` conserve le backend de previsualisation par defaut.

## Verification

```bash
bun run test:refrigerants
bun run typecheck
bun run lint
bun run build
```

Les commandes de build et de publication peuvent exiger les identifiants de signature et les variables d'environnement propres a chaque plateforme. Les secrets doivent rester dans un gestionnaire de secrets ou dans un fichier `.env` local non versionne.

## Principes de fiabilite

- Les calculs doivent afficher leurs unites, hypotheses, plages et limites.
- Les resultats d'estimation ne remplacent jamais une plaque signaletique, un manuel constructeur, une mesure instrumentee ou les codes/normes applicables.
- Les donnees techniques doivent avoir une provenance, une date de verification et une version.
- Les tables de melanges zeotropiques doivent distinguer les points de bulle et de rosee.
- Toute modification d'une formule doit etre accompagnee de tests de regression.

Voir `docs/VALIDATION-TECHNIQUE.md`, `docs/REGISTRE-DES-DONNEES.md` et `docs/RELEASE-CHECKLIST.md` avant toute publication.
