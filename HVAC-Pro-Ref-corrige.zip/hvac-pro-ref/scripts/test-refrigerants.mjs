import assert from 'node:assert/strict';
import {
  REFS,
  REF_TEMP_MIN_C,
  REF_TEMP_MAX_C,
  refById,
  satPressureKpaAbs,
  satTempC,
  psigToKpaAbs,
  kpaAbsToPsig,
  cToF,
  fToC,
} from '../packages/mobile/data/refrigerants.ts';

const close = (a, b, tolerance = 1e-6) => assert.ok(Math.abs(a - b) <= tolerance, `${a} is not within ${tolerance} of ${b}`);

assert.equal(REFS.length, 4);
assert.equal(refById('DOES-NOT-EXIST'), undefined, 'unknown refrigerants must not silently fall back');
assert.equal(Number.isNaN(satPressureKpaAbs('DOES-NOT-EXIST', 10)), true);
assert.equal(Number.isNaN(satTempC('DOES-NOT-EXIST', 500)), true);
assert.equal(Number.isNaN(satPressureKpaAbs('R410A', REF_TEMP_MIN_C - 0.01)), true, 'no low-temperature extrapolation');
assert.equal(Number.isNaN(satPressureKpaAbs('R410A', REF_TEMP_MAX_C + 0.01)), true, 'no high-temperature extrapolation');
assert.equal(Number.isNaN(satTempC('R410A', 1)), true, 'pressure below the table must be rejected');

for (const refrigerant of REFS) {
  assert.equal(refrigerant.table.length, 11, `${refrigerant.id} must have 11 table points`);
  assert.ok(refrigerant.table.every(Number.isFinite), `${refrigerant.id} values must be finite`);
  for (let i = 1; i < refrigerant.table.length; i++) {
    assert.ok(refrigerant.table[i] > refrigerant.table[i - 1], `${refrigerant.id} pressure must increase with temperature`);
  }
  for (const temp of [-40, -25, 0, 17.5, 40, 60]) {
    const pressure = satPressureKpaAbs(refrigerant.id, temp);
    assert.ok(Number.isFinite(pressure) && pressure > 0, `${refrigerant.id} at ${temp} C must return a positive pressure`);
    close(satTempC(refrigerant.id, pressure), temp, 1e-5);
  }
}

assert.equal(refById('R454B').tableBasis, 'bubble-only', 'R454B curve must be identified as bubble-only');
close(kpaAbsToPsig(psigToKpaAbs(0)), 0);
close(fToC(cToF(23.5)), 23.5);
console.log('HVAC Pro Ref refrigerant checks: PASS');
