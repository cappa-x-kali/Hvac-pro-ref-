import { cp, access, mkdir, rm } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const source = path.join(root, "packages", "web", "dist");
const destination = path.join(root, "packages", "desktop", "web-dist");

await access(path.join(source, "index.html"));
await rm(destination, { recursive: true, force: true });
await mkdir(path.dirname(destination), { recursive: true });
await cp(source, destination, { recursive: true });
console.log("Copied the production Web build into the Electron package.");
