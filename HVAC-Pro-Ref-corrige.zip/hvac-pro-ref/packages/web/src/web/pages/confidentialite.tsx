const SECTIONS: [string, string][] = [
  [
    "Données enregistrées sur l'appareil",
    "Les notes d'intervention, réglages, modèles personnalisés, photos et documents joints sont enregistrés dans le stockage local de l'application. Ils peuvent contenir des renseignements que vous saisissez, par exemple des coordonnées de clients ou des adresses. Protégez votre appareil et évitez d'y inscrire des renseignements qui ne sont pas nécessaires.",
  ],
  [
    "Caméra, photos et documents",
    "L'accès à la caméra, à la galerie et au sélecteur de documents sert à joindre des photos de plaques signalétiques, des schémas et des fichiers à vos fiches. Le code de l'application enregistre ces pièces jointes dans l'espace de stockage local de l'appareil. Une sauvegarde du téléphone ou une application tierce peut toutefois les copier selon ses propres réglages.",
  ],
  [
    "Statistiques d'utilisation",
    "L'application intègre OneDollarStats et configure l'envoi d'événements vers un service de collecte tiers. Les catégories exactes de données, les durées de conservation, les sous-traitants et les options de retrait doivent être confirmés dans la documentation et les paramètres du fournisseur avant publication. Ne présumez pas que les événements sont anonymes tant que cette vérification n'a pas été faite. Les notes et pièces jointes ne doivent pas être saisies dans des champs de télémétrie.",
  ],
  [
    "Services réseau",
    "L'application mobile peut communiquer avec l'API configurée pour les fonctions réseau. Le portail Web vérifie la disponibilité de cette API. Les données envoyées dépendent des fonctions activées et de la configuration du serveur. Les environnements de test et de production doivent être distingués.",
  ],
  [
    "Conservation et suppression",
    "Les données locales peuvent être supprimées en effaçant les données de l'application ou en la désinstallant, selon le système d'exploitation. Les sauvegardes du système, exports ou copies créées par l'utilisateur peuvent subsister séparément. Les données de télémétrie éventuellement collectées par le fournisseur tiers suivent sa propre politique de conservation.",
  ],
  [
    "Sécurité et renseignements clients",
    "N'enregistrez que les renseignements nécessaires à votre intervention. Utilisez un verrouillage d'appareil, maintenez le système à jour et ne partagez pas les archives de projet contenant des secrets ou des données clients. Les identifiants serveur ne doivent jamais être intégrés à l'application mobile.",
  ],
  [
    "Avertissement technique",
    "Les fiches, codes d'erreur, tableaux et calculs peuvent être incomplets ou indicatifs. Ils ne remplacent pas les manuels de service, les plaques signalétiques, les instruments vérifiés, les prescriptions des fabricants ni les codes et normes applicables.",
  ],
  [
    "Contact et révision",
    "Création : Jean Marion. Cette page décrit la configuration logicielle examinée et doit être revue avant toute distribution publique, notamment pour confirmer les conditions du fournisseur d'analytique, les coordonnées de contact officielles et les obligations légales applicables.",
  ],
];

export default function Confidentialite() {
  return (
    <main className="min-h-screen bg-[#071427] px-5 py-12 text-slate-200 sm:px-8">
      <article className="mx-auto max-w-3xl">
        <a href="/" className="text-sm text-cyan-300 hover:text-cyan-200">← HVAC Pro Ref</a>
        <h1 className="mt-6 text-3xl font-semibold tracking-tight text-white sm:text-4xl">Politique de confidentialité</h1>
        <p className="mt-3 text-sm text-slate-500">HVAC Pro Ref · Révision du 8 novembre 2026</p>
        <p className="mt-7 rounded-xl border border-amber-300/20 bg-amber-300/5 p-4 text-sm leading-6 text-amber-100">
          Version de travail basée sur le code actuellement fourni. Les modalités du fournisseur d'analytique et les coordonnées officielles doivent être confirmées avant publication.
        </p>
        {SECTIONS.map(([title, body]) => (
          <section key={title} className="mt-8 border-b border-white/10 pb-7 last:border-0">
            <h2 className="text-lg font-semibold text-white">{title}</h2>
            <p className="mt-3 leading-7 text-slate-300">{body}</p>
          </section>
        ))}
      </article>
    </main>
  );
}
