import {
  Activity,
  ArrowUpRight,
  BookOpen,
  Calculator,
  Database,
  Gauge,
  ShieldCheck,
  Smartphone,
  Wrench,
  Zap,
} from "lucide-react";
import { usePing } from "../queries/ping";
import { useDesktop } from "../hooks/use-desktop";

const FEATURES = [
  {
    icon: Gauge,
    title: "Réfrigération",
    description: "Outils P/T, surchauffe, sous-refroidissement, vide, azote et récupération.",
  },
  {
    icon: Calculator,
    title: "Calculs terrain",
    description: "Débit d'air, psychrométrie, BTU, électricité, conduits et conversions.",
  },
  {
    icon: Database,
    title: "Références équipements",
    description: "Catalogue de modèles, marques, systèmes multizones et pièces.",
  },
  {
    icon: BookOpen,
    title: "Diagnostic",
    description: "Codes d'erreur, documentation, notes d'intervention et pièces jointes.",
  },
  {
    icon: Zap,
    title: "Contrôle",
    description: "Fonctions infrarouges sur les appareils Android compatibles.",
  },
  {
    icon: ShieldCheck,
    title: "Données prudentes",
    description: "Plages, hypothèses et limites affichées pour éviter les résultats trompeurs.",
  },
];

export default function Index() {
  const ping = usePing();
  const desktop = useDesktop();
  const apiState = ping.isLoading ? "Vérification…" : ping.isError ? "Indisponible" : "Connectée";
  const apiTone = ping.isLoading ? "bg-amber-300" : ping.isError ? "bg-rose-400" : "bg-emerald-400";

  return (
    <main className="min-h-screen overflow-hidden bg-[#071427] text-white">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[520px] bg-[radial-gradient(ellipse_at_top,_rgba(27,126,191,0.28),_transparent_65%)]" />
      <div className="relative mx-auto max-w-6xl px-5 pb-16 pt-7 sm:px-8">
        <header className="flex items-center justify-between gap-4">
          <a href="/" className="flex items-center gap-3" aria-label="HVAC Pro Ref, accueil">
            <span className="flex h-11 w-11 items-center justify-center rounded-2xl border border-cyan-300/20 bg-cyan-300/10 text-cyan-200">
              <Wrench size={22} />
            </span>
            <span>
              <span className="block text-sm font-bold tracking-[0.18em]">HVAC PRO REF</span>
              <span className="block text-xs text-slate-400">Référence technique HVAC/R</span>
            </span>
          </a>
          <nav className="flex items-center gap-4 text-sm text-slate-300">
            <a href="#fonctionnalites" className="hidden transition hover:text-white sm:inline">Fonctionnalités</a>
            <a href="/confidentialite" className="transition hover:text-white">Confidentialité</a>
          </nav>
        </header>

        <section className="grid items-center gap-12 py-20 md:grid-cols-[1.15fr_0.85fr] md:py-28">
          <div>
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-cyan-300/20 bg-cyan-300/10 px-3 py-1.5 text-xs font-medium text-cyan-100">
              <Activity size={14} /> L'atelier technique dans votre poche
            </div>
            <h1 className="max-w-3xl text-4xl font-semibold leading-tight tracking-tight sm:text-5xl lg:text-6xl">
              Les bonnes données.
              <span className="block text-cyan-300">Les bons calculs.</span>
              Moins d'improvisation.
            </h1>
            <p className="mt-6 max-w-2xl text-base leading-7 text-slate-300 sm:text-lg">
              HVAC Pro Ref rassemble des outils de calcul, des références d'équipements et des aides au diagnostic pour les techniciens en chauffage, ventilation, climatisation et réfrigération.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <a href="#fonctionnalites" className="inline-flex items-center gap-2 rounded-xl bg-cyan-300 px-5 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-200">
                Explorer les outils <ArrowUpRight size={17} />
              </a>
              <a href="/confidentialite" className="rounded-xl border border-white/15 px-5 py-3 text-sm font-medium text-slate-200 transition hover:bg-white/5">
                Politique de confidentialité
              </a>
            </div>
            <p className="mt-5 max-w-xl text-xs leading-5 text-slate-500">
              Les résultats de calcul et les données non sourcées sont indicatifs. Toujours confirmer avec la plaque signalétique, le manuel constructeur, les instruments et les règles applicables.
            </p>
          </div>

          <div className="rounded-3xl border border-white/10 bg-white/[0.045] p-5 shadow-2xl shadow-black/20 backdrop-blur">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <p className="text-xs uppercase tracking-[0.16em] text-slate-400">État des services</p>
                <p className="mt-1 text-lg font-semibold">Tableau de bord</p>
              </div>
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-300/10 text-cyan-200"><Activity size={20} /></span>
            </div>
            <div className="mt-5 space-y-3">
              <div className="flex items-center justify-between rounded-xl bg-black/20 px-4 py-3">
                <span className="text-sm text-slate-300">API HVAC Pro Ref</span>
                <span className="inline-flex items-center gap-2 text-sm font-medium"><span className={`h-2 w-2 rounded-full ${apiTone}`} />{apiState}</span>
              </div>
              <div className="flex items-center justify-between rounded-xl bg-black/20 px-4 py-3">
                <span className="text-sm text-slate-300">Environnement</span>
                <span className="text-sm font-medium">{desktop ? `Bureau · ${desktop.platform}` : "Web"}</span>
              </div>
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div className="rounded-xl border border-white/10 bg-white/[0.035] p-4">
                  <Calculator className="mb-3 text-cyan-200" size={21} />
                  <p className="text-2xl font-semibold">24</p>
                  <p className="mt-1 text-xs text-slate-400">Outils et calculateurs</p>
                </div>
                <div className="rounded-xl border border-white/10 bg-white/[0.035] p-4">
                  <Smartphone className="mb-3 text-cyan-200" size={21} />
                  <p className="text-2xl font-semibold">Mobile</p>
                  <p className="mt-1 text-xs text-slate-400">Application principale</p>
                </div>
              </div>
            </div>
            <p className="mt-4 text-xs leading-5 text-slate-500">La connexion API indique uniquement que le service répond. Elle ne valide pas les données techniques ni les calculs.</p>
          </div>
        </section>

        <section id="fonctionnalites" className="scroll-mt-10 py-10">
          <div className="max-w-2xl">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-cyan-300">Une boîte à outils intégrée</p>
            <h2 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">Conçu pour le travail sur le terrain.</h2>
            <p className="mt-4 leading-7 text-slate-400">Les fonctions principales sont regroupées dans l'application mobile. Ce portail présente le produit et surveille la disponibilité de son API.</p>
          </div>
          <div className="mt-9 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map(({ icon: Icon, title, description }) => (
              <article key={title} className="rounded-2xl border border-white/10 bg-white/[0.035] p-5 transition hover:border-cyan-200/30 hover:bg-white/[0.06]">
                <span className="mb-4 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-300/10 text-cyan-200"><Icon size={20} /></span>
                <h3 className="text-base font-semibold">{title}</h3>
                <p className="mt-2 text-sm leading-6 text-slate-400">{description}</p>
              </article>
            ))}
          </div>
        </section>

        <footer className="mt-16 flex flex-col gap-3 border-t border-white/10 pt-6 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between">
          <p>HVAC Pro Ref · Outil d'aide technique pour HVAC/R</p>
          <a href="/confidentialite" className="inline-flex items-center gap-1 transition hover:text-slate-200">Confidentialité <ArrowUpRight size={13} /></a>
        </footer>
      </div>
    </main>
  );
}
