import { View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Btn, Card, Chip, Disclaimer, Empty, Hero, Screen, Section, T } from "../../components/ui";
import { NoteCard } from "../../components/hvac";
import { TechnicianCard, severityColor } from "../../components/technician";
import { useColors } from "../../hooks/use-colors";
import { useStore } from "../../lib/store";
import { BRANDS, manualSearchUrl } from "../../data/brands";
import { codeSetById } from "../../data/errors";
import { categorize, codeTag, SEVERITY_LABEL, splitList, splitSteps } from "../../data/code-details";
import { openUrl } from "../../lib/files";
import { Fonts } from "../../constants/theme";

const g = (q: string) => `https://www.google.com/search?q=${encodeURIComponent(q)}`;

export default function CodeDetailScreen() {
  const c = useColors();
  const { notes } = useStore();
  const { key } = useLocalSearchParams<{ key: string }>();
  const raw = decodeURIComponent(key ?? "");
  const sep = raw.indexOf("|");
  const setId = raw.slice(0, sep);
  const codeId = raw.slice(sep + 1);
  const set = codeSetById(setId);
  const code = set?.codes.find((x) => x.code === codeId);

  if (!set || !code) {
    return (
      <Screen>
        <Hero back title="Code introuvable" />
        <Empty icon="help" title="Ce code n'existe plus" />
      </Screen>
    );
  }

  const cat = categorize(code, set);
  const sc = severityColor(cat.severity, c);
  const brands = BRANDS.filter((b) => (b.codeSets[set.type] ?? []).includes(set.id));
  const brandLabel = brands[0]?.name ?? set.name.split(" ")[0];
  const causes = splitList(code.causes);
  const fix = splitSteps(code.fix);
  const tag = codeTag(code.code);
  const linked = notes.filter((n) => n.tags.includes(tag));

  const pillOnHero = (label: string, color: string, icon?: keyof typeof Ionicons.glyphMap) => (
    <View style={{ flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: "rgba(255,255,255,0.95)", borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4 }}>
      {icon ? <Ionicons name={icon} size={13} color={color} /> : null}
      <T v="small" style={{ fontFamily: Fonts.bodyBold, color }}>{label}</T>
    </View>
  );

  const bullet = (items: string[], color: string, icon: keyof typeof Ionicons.glyphMap) => (
    <Card style={{ gap: 10 }}>
      {items.map((x, i) => (
        <View key={i} style={{ flexDirection: "row", gap: 10, alignItems: "flex-start" }}>
          <Ionicons name={icon} size={16} color={color} style={{ marginTop: 3 }} />
          <T style={{ flex: 1 }}>{x}</T>
        </View>
      ))}
    </Card>
  );

  const numbered = (items: string[], color: string) => (
    <Card style={{ gap: 12 }}>
      {items.map((x, i) => (
        <View key={i} style={{ flexDirection: "row", gap: 12, alignItems: "flex-start" }}>
          <View style={{ width: 26, height: 26, borderRadius: 13, backgroundColor: color + "1F", alignItems: "center", justifyContent: "center" }}>
            <T v="small" style={{ fontFamily: Fonts.bodyBold, color }}>{i + 1}</T>
          </View>
          <T style={{ flex: 1 }}>{x}</T>
        </View>
      ))}
    </Card>
  );

  const link = (label: string, sub: string, url: string, icon: keyof typeof Ionicons.glyphMap, color: string) => (
    <Card key={label} onPress={() => openUrl(url)} style={{ flexDirection: "row", alignItems: "center", gap: 12, padding: 14 }}>
      <View style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: color + "16", alignItems: "center", justifyContent: "center" }}>
        <Ionicons name={icon} size={19} color={color} />
      </View>
      <View style={{ flex: 1 }}>
        <T v="h3" style={{ fontSize: 15 }}>{label}</T>
        <T v="small" numberOfLines={1}>{sub}</T>
      </View>
      <Ionicons name="open-outline" size={18} color={c.mutedForeground} />
    </Card>
  );

  const addNote = () =>
    router.push({ pathname: "/note/[id]", params: { id: "new", title: `Code ${code.code} — ${code.title}`, tag } });

  return (
    <Screen>
      <Hero back title={`${code.code} · ${code.title}`} subtitle={set.name}>
        <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
          {pillOnHero(`Gravité : ${SEVERITY_LABEL[cat.severity]}`, sc, "alert-circle")}
          {pillOnHero(cat.label, "#0E1726", cat.icon as keyof typeof Ionicons.glyphMap)}
          {pillOnHero(set.type === "mural" ? "Mural / mini-split" : "Central", "#0E1726")}
        </View>
      </Hero>

      <View style={{ paddingHorizontal: 16, marginTop: -18 }}>
        <TechnicianCard severity={cat.severity} label={SEVERITY_LABEL[cat.severity]} />
      </View>

      <Section title="Ce que ça signifie">
        <Card style={{ gap: 10, borderLeftWidth: 5, borderLeftColor: sc }}>
          <T>{cat.what}</T>
          <View style={{ flexDirection: "row", gap: 8, alignItems: "flex-start" }}>
            <Ionicons name="pulse" size={16} color={sc} style={{ marginTop: 3 }} />
            <T style={{ flex: 1, fontFamily: Fonts.bodyBold }}>{cat.impact}</T>
          </View>
        </Card>
      </Section>

      <Section title="Causes probables (fabricant)">{bullet(causes, c.warning, "warning-outline")}</Section>
      <Section title="Correctif du fabricant">{numbered(fix, c.success)}</Section>
      <Section title="Diagnostic pas à pas">{numbered(cat.steps, c.primary)}</Section>

      {cat.values?.length ? (
        <Section title="Valeurs typiques">
          <Card style={{ padding: 0, overflow: "hidden" }}>
            {cat.values.map(([k, v], i) => (
              <View key={k} style={{ flexDirection: "row", justifyContent: "space-between", gap: 12, paddingHorizontal: 16, paddingVertical: 12, borderTopWidth: i ? 1 : 0, borderTopColor: c.border }}>
                <T v="small" style={{ flex: 1 }}>{k}</T>
                <T style={{ fontFamily: Fonts.bodyBold, flexShrink: 1, textAlign: "right" }}>{v}</T>
              </View>
            ))}
          </Card>
        </Section>
      ) : null}

      <Section title="Outils requis">
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
          {cat.tools.map((t) => <Chip key={t} label={t} icon="construct-outline" />)}
        </View>
      </Section>

      {cat.parts.length ? (
        <Section title="Pièces à vérifier">
          {cat.parts.map(([fr, en]) => link(fr, `Rechercher : ${brandLabel} ${en}`, g(`${brandLabel} ${en} ${code.code}`), "hardware-chip-outline", c.accent))}
        </Section>
      ) : null}

      <Section title="Pièges fréquents">{bullet(cat.pitfalls, c.destructive, "close-circle-outline")}</Section>

      {cat.safety ? (
        <Section title="Sécurité">
          <Card style={{ flexDirection: "row", gap: 10, borderLeftWidth: 5, borderLeftColor: c.destructive, backgroundColor: c.destructive + "0D" }}>
            <Ionicons name="flash" size={20} color={c.destructive} />
            <T style={{ flex: 1 }}>{cat.safety}</T>
          </Card>
        </Section>
      ) : null}

      {set.note ? (
        <Section title="Note sur ce jeu de codes">
          <Card><T v="small" style={{ color: c.foreground }}>{set.note}</T></Card>
        </Section>
      ) : null}

      {brands.length ? (
        <Section title={`Marques concernées (${brands.length})`}>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
            {brands.map((b) => (
              <Chip key={b.id} label={b.name} color={b.color} onPress={() => router.push(`/marque/${b.id}?type=${set.type}&tab=codes`)} />
            ))}
          </View>
        </Section>
      ) : null}

      <Section title="Documentation">
        {link(`Fiche du code ${code.code}`, `${brandLabel} code ${code.code} ${code.title}`, g(`${brandLabel} code ${code.code} ${code.title}`), "search-outline", c.primary)}
        {link("Manuel de service (PDF)", `${brandLabel} · dépannage / troubleshooting`, manualSearchUrl(brandLabel, `error code ${code.code} troubleshooting`, "service"), "document-text-outline", c.destructive)}
        {link("Vidéos de diagnostic", `YouTube · ${brandLabel} ${code.code}`, `https://www.youtube.com/results?search_query=${encodeURIComponent(`${brandLabel} error ${code.code}`)}`, "logo-youtube", c.destructive)}
      </Section>

      <Section title={`Mes notes · #${tag}`}>
        <Btn label="Ajouter une note sur ce code" icon="create-outline" onPress={addNote} />
        {linked.map((n) => <NoteCard key={n.id} n={n} />)}
        {!linked.length ? <T v="small" style={{ paddingHorizontal: 4 }}>Aucune note pour ce code. Les notes créées ici sont étiquetées #{tag}.</T> : null}
      </Section>

      <Disclaimer text="Diagnostic générique par famille de défaut, combiné aux causes et correctifs propres au fabricant. Toujours valider avec le manuel de service du modèle exact." />
    </Screen>
  );
}
