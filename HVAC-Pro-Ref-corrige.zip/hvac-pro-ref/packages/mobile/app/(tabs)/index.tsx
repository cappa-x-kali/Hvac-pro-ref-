import { useLocalSearchParams } from "expo-router";
import { Screen } from "../../components/ui";
import { SystemBrowser } from "../../components/browser";

export default function MurauxScreen() {
  const { btu, zone } = useLocalSearchParams<{ btu?: string; zone?: string }>();
  const n = btu ? Number(btu) : undefined;
  return (
    <Screen>
      <SystemBrowser type="mural" initialBtu={n && Number.isFinite(n) ? n : undefined} initialZone={zone === "multi" || zone === "mono" ? zone : undefined} />
    </Screen>
  );
}
