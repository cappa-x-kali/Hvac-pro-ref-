import { Tabs } from "expo-router";
import { View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useColors } from "../../hooks/use-colors";
import { Fonts } from "../../constants/theme";
import { tr, useLang } from "../../lib/i18n";

type IconName = keyof typeof Ionicons.glyphMap;

const TABS: { name: string; title: string; icon: IconName; iconOn: IconName }[] = [
  { name: "index", title: "Muraux", icon: "snow-outline", iconOn: "snow" },
  { name: "centraux", title: "Centraux", icon: "home-outline", iconOn: "home" },
  { name: "codes", title: "Codes", icon: "warning-outline", iconOn: "warning" },
  { name: "outils", title: "Outils", icon: "calculator-outline", iconOn: "calculator" },
  { name: "notes", title: "Notes", icon: "document-text-outline", iconOn: "document-text" },
];

export default function TabLayout() {
  const c = useColors();
  const insets = useSafeAreaInsets();
  const lang = useLang();
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: c.primary,
        tabBarInactiveTintColor: c.mutedForeground,
        tabBarLabelStyle: { fontFamily: Fonts.bodyBold, fontSize: 11, marginTop: 2 },
        tabBarStyle: {
          backgroundColor: c.card, borderTopWidth: 0, height: 72 + insets.bottom, paddingTop: 6, paddingBottom: 6 + insets.bottom,
          shadowColor: "#0B1B33", shadowOpacity: 0.1, shadowRadius: 16, shadowOffset: { width: 0, height: -4 }, elevation: 12,
        },
      }}
    >
      {TABS.map((t) => (
        <Tabs.Screen
          key={t.name}
          name={t.name}
          options={{
            title: tr(t.title, lang),
            tabBarIcon: ({ color, focused }) => (
              <View style={{ width: 46, height: 28, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: focused ? c.primary + "1A" : "transparent" }}>
                <Ionicons name={focused ? t.iconOn : t.icon} size={21} color={color} />
              </View>
            ),
          }}
        />
      ))}
    </Tabs>
  );
}
