import { Screen } from "../../components/ui";
import { SystemBrowser } from "../../components/browser";

export default function CentrauxScreen() {
  return (
    <Screen>
      <SystemBrowser type="central" />
    </Screen>
  );
}
