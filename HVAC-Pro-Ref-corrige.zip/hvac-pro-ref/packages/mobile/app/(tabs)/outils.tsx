import { CreditFooter } from "../../components/credits";
import { useMemo, useState } from "react";
import { View } from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Card, Hero, HeroIcon, Screen, SearchBar, Section, T } from "../../components/ui";
import { TOOLS, TOOL_CATS } from "../../components/tools/registry";
import { useColors } from "../../hooks/use-colors";
import { useStore } from "../../lib/store";

export default function OutilsScreen() {
  const c = useColors();
  const { settings, setSetting } = useStore();
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    const n = q.trim().toLowerCase();
    return n ? TOOLS.filter((t) => (t.title + " " + t.desc).toLowerCase().includes(n)) : TOOLS;
  }, [q]);
  const catColor: Record<string, string> = { ref: c.primary, air: "#0EA5A4", elec: c.warning, gen: c.accent, ctl: "#8B5CF6" };
  return (
    <Screen>
      <Hero
        title="Outils"
        subtitle={`${TOOLS.length} calculateurs terrain`}
        right={
          <View style={{ flexDirection: "row", gap: 8 }}>
            <HeroIcon name="thermometer-outline" active={settings.tempUnit === "C"} onPress={() => setSetting("tempUnit", settings.tempUnit === "F" ? "C" : "F")} />
            <HeroIcon name="settings-outline" onPress={() => router.push("/reglages")} />
          </View>
        }
      >
        <SearchBar value={q} onChange={setQ} placeholder="Chercher un outil…" onDark />
        <T v="small" color={c.heroText} style={{ marginTop: 8, opacity: 0.85 }}>
          Unités : {settings.tempUnit === "F" ? "°F" : "°C"} · {settings.pressureUnit === "psig" ? "psig" : "kPa"} — touchez le thermomètre pour basculer
        </T>
      </Hero>
      {TOOL_CATS.map((cat) => {
        const items = list.filter((t) => t.cat === cat.id);
        if (!items.length) return null;
        return (
          <Section key={cat.id} title={cat.label}>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
              {items.map((t) => (
                <Card key={t.id} onPress={() => router.push(`/outils/${t.id}`)} style={{ width: "48%", flexGrow: 1, padding: 14, gap: 10 }}>
                  <View style={{ width: 42, height: 42, borderRadius: 13, backgroundColor: catColor[cat.id] + "1C", alignItems: "center", justifyContent: "center" }}>
                    <Ionicons name={t.icon} size={22} color={catColor[cat.id]} />
                  </View>
                  <View style={{ gap: 2 }}>
                    <T v="h3" style={{ fontSize: 14, lineHeight: 19 }}>{t.title}</T>
                    <T v="small" numberOfLines={2} style={{ fontSize: 12, lineHeight: 16 }}>{t.desc}</T>
                  </View>
                </Card>
              ))}
            </View>
          </Section>
        );
      })}
      <CreditFooter />
    </Screen>
  );
}
