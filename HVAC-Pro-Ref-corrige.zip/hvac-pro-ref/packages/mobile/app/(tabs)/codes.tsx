import { useMemo, useState } from "react";
import { View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { Card, Chip, ChipRow, Disclaimer, Empty, Hero, HeroIcon, Screen, SearchBar, Section, Segmented, T, Pill } from "../../components/ui";
import { CodeCard } from "../../components/hvac";
import { useColors } from "../../hooks/use-colors";
import { useStore } from "../../lib/store";
import { BRANDS, brandById } from "../../data/brands";
import { CODE_SETS, searchCodes } from "../../data/errors";
import type { SystemType } from "../../data/types";

export default function CodesScreen() {
  const c = useColors();
  const { sortBrands, settings } = useStore();
  const [q, setQ] = useState("");
  const [type, setType] = useState<"all" | SystemType>("all");
  const [brand, setBrand] = useState<string | null>(null);
  const [setId, setSetId] = useState<string | null>(null);

  const brands = useMemo(() => sortBrands(BRANDS.filter((b) => (type === "all" ? true : (b.codeSets[type] ?? []).length > 0))), [sortBrands, type]);

  const brandRank = (ids: string[]) => {
    if (settings.primaryBrand && ids.includes(settings.primaryBrand)) return 0;
    if (ids.some((i) => settings.favoriteBrands.includes(i))) return 1;
    return 2;
  };

  const sets = useMemo(() => {
    const withBrands = CODE_SETS.filter((s) => type === "all" || s.type === type).map((s) => ({
      s,
      brands: BRANDS.filter((b) => [...(b.codeSets.mural ?? []), ...(b.codeSets.central ?? [])].includes(s.id)).map((b) => b.id),
    }));
    return withBrands
      .filter((x) => !brand || x.brands.includes(brand))
      .sort((a, b) => brandRank(a.brands) - brandRank(b.brands));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type, brand, settings.primaryBrand, settings.favoriteBrands]);

  const hits = useMemo(() => {
    if (!q.trim() && !setId) return [];
    let list = searchCodes(q, brand ? [brand] : undefined);
    if (type !== "all") list = list.filter((h) => h.set.type === type);
    if (setId) list = list.filter((h) => h.set.id === setId);
    return list.sort((a, b) => brandRank(a.brands) - brandRank(b.brands));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, brand, type, setId, settings.primaryBrand, settings.favoriteBrands]);

  const currentSet = setId ? CODE_SETS.find((s) => s.id === setId) : null;
  const showList = !!q.trim() || !!setId;

  return (
    <Screen>
      <Hero
        title="Codes d'erreur"
        subtitle={`${CODE_SETS.reduce((n, s) => n + s.codes.length, 0)} codes · ${CODE_SETS.length} familles`}
        right={<HeroIcon name="settings-outline" onPress={() => router.push("/reglages")} />}
      >
        <SearchBar value={q} onChange={setQ} placeholder="Code (E1, P4, CH05, 33…) ou symptôme" onDark />
      </Hero>

      <View style={{ paddingHorizontal: 16, marginTop: 14 }}>
        <Segmented
          value={type}
          onChange={(v) => { setType(v); setSetId(null); }}
          options={[{ value: "all", label: "Tous" }, { value: "mural", label: "Muraux" }, { value: "central", label: "Centraux" }]}
        />
      </View>
      <View style={{ marginTop: 10 }}>
        <ChipRow>
          <Chip label="Toutes marques" active={!brand} onPress={() => { setBrand(null); setSetId(null); }} />
          {brands.map((b) => (
            <Chip key={b.id} label={(b.id === settings.primaryBrand ? "★ " : "") + b.name} color={b.color} active={brand === b.id} onPress={() => { setBrand(brand === b.id ? null : b.id); setSetId(null); }} />
          ))}
        </ChipRow>
      </View>

      {showList ? (
        <Section
          title={currentSet ? currentSet.name : `${hits.length} code${hits.length > 1 ? "s" : ""}`}
          action={setId ? <Chip label="Fermer" icon="close" onPress={() => setSetId(null)} /> : undefined}
        >
          {currentSet?.note ? <T v="small">{currentSet.note}</T> : null}
          {hits.slice(0, 120).map((h, i) => (
            <CodeCard key={`${h.set.id}-${h.code.code}-${i}`} code={h.code} set={h.set} setName={currentSet ? undefined : h.set.name} brands={currentSet ? undefined : h.brands} defaultOpen={!!q.trim() && hits.length <= 3} />
          ))}
          {!hits.length ? <Empty icon="search" title="Aucun code trouvé" text="Vérifiez la marque sélectionnée ou cherchez par symptôme (ex. « communication », « haute pression »)." /> : null}
        </Section>
      ) : (
        <Section title="Familles de codes">
          {sets.map(({ s, brands: bs }) => {
            const prim = settings.primaryBrand && bs.includes(settings.primaryBrand);
            return (
              <Card key={s.id} onPress={() => setSetId(s.id)} style={{ gap: 8, borderColor: prim ? c.accent : c.border, borderWidth: prim ? 2 : 1 }}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                  <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: (s.type === "mural" ? c.primary : c.accent) + "1F", alignItems: "center", justifyContent: "center" }}>
                    <Ionicons name={s.type === "mural" ? "snow" : "flame"} size={20} color={s.type === "mural" ? c.primary : c.accent} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <T v="h3" style={{ fontSize: 15 }}>{s.name}</T>
                    <T v="small">{s.codes.length} codes · {s.type === "mural" ? "Mural" : "Central"}</T>
                  </View>
                  <Ionicons name="chevron-forward" size={18} color={c.mutedForeground} />
                </View>
                <View style={{ flexDirection: "row", gap: 6, flexWrap: "wrap" }}>
                  {bs.map((id) => <Pill key={id} label={(id === settings.primaryBrand ? "★ " : "") + (brandById(id)?.name ?? id)} color={id === settings.primaryBrand ? c.accent : undefined} />)}
                </View>
              </Card>
            );
          })}
        </Section>
      )}
      <Disclaimer text="Les codes peuvent varier selon la génération et la carte électronique. Confirmez toujours avec le manuel de service du modèle exact." />
    </Screen>
  );
}
