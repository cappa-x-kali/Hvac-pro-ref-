import { useMemo, useState } from "react";
import { View } from "react-native";
import { router } from "expo-router";
import { Btn, Chip, ChipRow, Empty, Hero, HeroIcon, Screen, SearchBar, Section } from "../../components/ui";
import { NoteCard } from "../../components/hvac";
import { useStore } from "../../lib/store";
import { brandById } from "../../data/brands";

export default function NotesScreen() {
  const { notes, sortBrands, settings } = useStore();
  const [q, setQ] = useState("");
  const [brand, setBrand] = useState<string | null>(null);
  const [tag, setTag] = useState<string | null>(null);

  const brands = useMemo(() => {
    const ids = [...new Set(notes.map((n) => n.brandId).filter(Boolean))] as string[];
    return sortBrands(ids.map((id) => ({ id, name: brandById(id)?.name ?? id })));
  }, [notes, sortBrands]);
  const tags = useMemo(() => [...new Set(notes.flatMap((n) => n.tags))].sort(), [notes]);

  const list = useMemo(() => {
    const n = q.trim().toLowerCase();
    return notes
      .filter((x) => !brand || x.brandId === brand)
      .filter((x) => !tag || x.tags.includes(tag))
      .filter((x) => !n || [x.title, x.body, x.client, x.address, x.modelLabel, brandById(x.brandId)?.name, ...x.tags].join(" ").toLowerCase().includes(n))
      .sort((a, b) => Number(!!b.pinned) - Number(!!a.pinned) || b.updatedAt - a.updatedAt);
  }, [notes, q, brand, tag]);

  return (
    <Screen>
      <Hero
        title="Mes notes"
        subtitle={`${notes.length} note${notes.length > 1 ? "s" : ""} · stockées sur ce téléphone`}
        right={<HeroIcon name="add" onPress={() => router.push("/note/new")} />}
      >
        <SearchBar value={q} onChange={setQ} placeholder="Client, adresse, modèle, mot-clé…" onDark />
      </Hero>
      {brands.length || tags.length ? (
        <View style={{ marginTop: 14 }}>
          <ChipRow>
            <Chip label="Toutes" active={!brand && !tag} onPress={() => { setBrand(null); setTag(null); }} />
            {brands.map((b) => <Chip key={b.id} label={(b.id === settings.primaryBrand ? "★ " : "") + b.name} active={brand === b.id} onPress={() => setBrand(brand === b.id ? null : b.id)} />)}
            {tags.map((t) => <Chip key={t} label={`#${t}`} active={tag === t} onPress={() => setTag(tag === t ? null : t)} />)}
          </ChipRow>
        </View>
      ) : null}
      <Section title={q || brand || tag ? `${list.length} résultat(s)` : "Récentes"}>
        {list.map((n) => <NoteCard key={n.id} n={n} />)}
        {!list.length ? (
          <Empty icon="document-text-outline" title={notes.length ? "Aucune note trouvée" : "Aucune note pour l'instant"} text="Notez vos remarques d'installation, pressions mesurées, infos client et joignez photos ou PDF." />
        ) : null}
        <Btn label="Nouvelle note" icon="create-outline" onPress={() => router.push("/note/new")} />
      </Section>
    </Screen>
  );
}
