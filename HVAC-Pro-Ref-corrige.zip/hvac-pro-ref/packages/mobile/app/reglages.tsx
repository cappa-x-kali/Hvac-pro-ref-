import { useMemo, useState } from "react";
import { Image, Pressable, Switch, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Intro } from "../components/intro";
import { Fonts } from "../constants/theme";
import { Ionicons } from "@expo/vector-icons";
import { BrandAvatar, Btn, Card, Chip, Hero, Screen, Section, Segmented, T, Disclaimer } from "../components/ui";
import { FavStar } from "../components/hvac";
import { useColors } from "../hooks/use-colors";
import { useStore } from "../lib/store";
import { THEMES, THEME_CATS, type ThemeId } from "../constants/theme";
import { BRANDS, brandById } from "../data/brands";
import { MODELS } from "../data/models";
import { CODE_SETS } from "../data/errors";

export default function Reglages() {
  const c = useColors();
  const { settings, setSetting, sortBrands, isFavBrand, toggleFavoriteBrand, notes, customModels } = useStore();
  const brands = useMemo(() => sortBrands(BRANDS), [sortBrands]);
  const primary = brandById(settings.primaryBrand);
  const [replay, setReplay] = useState(false);

  const setPrimary = (id: string) => {
    if (settings.primaryBrand === id) return setSetting("primaryBrand", undefined);
    setSetting("primaryBrand", id);
    if (!settings.favoriteBrands.includes(id)) toggleFavoriteBrand(id);
  };

  return (
    <View style={{ flex: 1 }}>
    <Screen>
      <Hero back compact title="Réglages" subtitle="Thème, unités et marques favorites" />

      <Section title="Langue · Language">
        <Segmented value={settings.lang === "en" ? "en" : "fr"} onChange={(v) => setSetting("lang", v)} options={[{ value: "fr", label: "Français" }, { value: "en", label: "English" }]} />
      </Section>

      <Section title="Thème">
        <Pressable onPress={() => setSetting("theme", "auto")}>
          <Card style={{ flexDirection: "row", alignItems: "center", gap: 12, borderColor: settings.theme === "auto" ? c.primary : c.border, borderWidth: settings.theme === "auto" ? 2 : 1 }}>
            <Ionicons name="contrast" size={22} color={c.primary} />
            <View style={{ flex: 1 }}>
              <T v="h3">Automatique</T>
              <T v="small">Glacier le jour, Nuit technique si le téléphone est en mode sombre</T>
            </View>
            {settings.theme === "auto" ? <Ionicons name="checkmark-circle" size={22} color={c.primary} /> : null}
          </Card>
        </Pressable>
        <T v="small">{Object.keys(THEMES).length} thèmes — touchez pour appliquer</T>
        {THEME_CATS.map((cat) => (
        <View key={cat.id} style={{ gap: 8 }}>
        <T v="label" style={{ marginTop: 6 }}>{cat.label}</T>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
          {(Object.keys(THEMES) as ThemeId[]).filter((id) => THEMES[id].cat === cat.id).map((id) => {
            const th = THEMES[id];
            const sel = settings.theme === id;
            return (
              <Pressable key={id} onPress={() => setSetting("theme", id)} style={{ width: "48%", flexGrow: 1 }}>
                <View style={{ borderRadius: 18, overflow: "hidden", borderWidth: sel ? 2 : 1, borderColor: sel ? c.primary : c.border, backgroundColor: th.colors.card }}>
                  <View style={{ height: 54, backgroundColor: th.colors.primary, flexDirection: "row", alignItems: "flex-end", padding: 8, gap: 6 }}>
                    <View style={{ width: 18, height: 18, borderRadius: 9, backgroundColor: th.colors.accent }} />
                    <View style={{ width: 18, height: 18, borderRadius: 9, backgroundColor: th.colors.primaryDeep }} />
                    <View style={{ width: 18, height: 18, borderRadius: 9, backgroundColor: th.colors.background, borderWidth: 1, borderColor: "rgba(0,0,0,0.1)" }} />
                  </View>
                  <View style={{ padding: 10, gap: 2, backgroundColor: th.colors.card }}>
                    <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                      <T v="h3" color={th.colors.foreground}>{th.label}</T>
                      {sel ? <Ionicons name="checkmark-circle" size={18} color={th.colors.primary} /> : null}
                    </View>
                    <T v="small" color={th.colors.mutedForeground} numberOfLines={2}>{th.desc}</T>
                  </View>
                </View>
              </Pressable>
            );
          })}
        </View>
        </View>
        ))}
      </Section>

      <Section title="Unités">
        <T v="small">Température</T>
        <Segmented value={settings.tempUnit} onChange={(v) => setSetting("tempUnit", v)} options={[{ value: "F", label: "°F (Fahrenheit)" }, { value: "C", label: "°C (Celsius)" }]} />
        <T v="small">Pression</T>
        <Segmented value={settings.pressureUnit} onChange={(v) => setSetting("pressureUnit", v)} options={[{ value: "psig", label: "psig" }, { value: "kPa", label: "kPa" }]} />
      </Section>

      <Section title="Marque principale">
        <Card style={{ flexDirection: "row", alignItems: "center", gap: 12, borderColor: primary ? c.accent : c.border, borderWidth: primary ? 2 : 1 }}>
          {primary ? <BrandAvatar name={primary.name} color={primary.color} size={46} /> : <Ionicons name="star-outline" size={30} color={c.mutedForeground} />}
          <View style={{ flex: 1 }}>
            <T v="h3">{primary ? primary.name : "Aucune"}</T>
            <T v="small">Affichée en premier partout : listes de marques, recherches, codes d'erreur et notes.</T>
          </View>
        </Card>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
          {brands.map((b) => (
            <Chip key={b.id} label={b.name} color={b.color} active={settings.primaryBrand === b.id} icon={settings.primaryBrand === b.id ? "star" : undefined} onPress={() => setPrimary(b.id)} />
          ))}
        </View>
      </Section>

      <Section title={`Marques favorites (${settings.favoriteBrands.length})`}>
        <T v="small">Les favoris s'affichent juste après la marque principale. Touchez l'étoile pour ajouter ou retirer.</T>
        <Card style={{ padding: 0, overflow: "hidden" }}>
          {brands.map((b, i) => (
            <View key={b.id} style={{ flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 14, paddingVertical: 10, borderTopWidth: i ? 1 : 0, borderTopColor: c.border }}>
              <BrandAvatar name={b.name} color={b.color} size={32} />
              <View style={{ flex: 1 }}>
                <T v="h3" style={{ fontSize: 14 }}>{b.name}</T>
                <T v="small" style={{ fontSize: 12 }}>{b.types.map((t) => (t === "mural" ? "Mural" : "Central")).join(" · ")}{b.oem ? ` · plateforme ${b.oem}` : ""}</T>
              </View>
              {settings.primaryBrand === b.id ? <T v="label" color={c.accent}>Principale</T> : null}
              <FavStar active={isFavBrand(b.id)} onPress={() => toggleFavoriteBrand(b.id)} />
            </View>
          ))}
        </Card>
      </Section>

      <Section title="Données">
        <Card style={{ gap: 6 }}>
          <T>{BRANDS.length} marques · {MODELS.length} modèles de référence · {CODE_SETS.reduce((n, s) => n + s.codes.length, 0)} codes d'erreur</T>
          <T v="small">{customModels.length} modèle(s) perso · {notes.length} note(s) — stockés uniquement sur cet appareil, fonctionne hors ligne.</T>
        </Card>
      </Section>
      <Section title="À propos">
        <View style={{ borderRadius: 22, overflow: "hidden" }}>
          <LinearGradient colors={["#03070F", "#0A2540", "#03070F"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ padding: 20, alignItems: "center", gap: 6 }}>
            <Image source={require("../assets/brand/emblem.png")} style={{ width: 92, height: 92 }} />
            <T v="h2" color="#FFFFFF">
              <T v="h2" color="#7FD3FF">HVAC </T>Pro <T v="h2" color="#FF9A3D">Ref</T>
            </T>
            <T v="small" style={{ color: "rgba(255,255,255,0.65)", letterSpacing: 1.6, fontFamily: Fonts.bodyBold, fontSize: 10 }}>CLIMATISATION · CHAUFFAGE · DIAGNOSTIC</T>
            <View style={{ height: 1, alignSelf: "stretch", backgroundColor: "rgba(255,255,255,0.12)", marginVertical: 10 }} />
            <T v="label" color="rgba(255,255,255,0.55)">Création et conception</T>
            <T v="h3" color="#FFFFFF">Jean Marion</T>
            <T v="label" color="rgba(255,255,255,0.55)" style={{ marginTop: 8 }}>Crédits</T>
            <T v="h3" color="#FFFFFF">Cappa-X Tools</T>
            <T v="small" style={{ color: "rgba(255,255,255,0.5)", marginTop: 8 }}>Version 1.0.0</T>
            <T v="small" style={{ color: "rgba(255,255,255,0.4)", fontSize: 10, textAlign: "center", marginTop: 4 }}>Encodeurs IR adaptés de la bibliothèque libre IRremoteESP8266 (LGPL-2.1)</T>
          </LinearGradient>
        </View>
        <Card style={{ flexDirection: "row", alignItems: "center", gap: 12, padding: 14 }}>
          <Ionicons name="sparkles-outline" size={20} color={c.primary} />
          <View style={{ flex: 1 }}>
            <T v="h3" style={{ fontSize: 15 }}>Introduction au démarrage</T>
            <T v="small">Animation flocon + flamme à l'ouverture</T>
          </View>
          <Switch value={settings.intro} onValueChange={(v) => setSetting("intro", v)} trackColor={{ true: c.primary, false: c.border }} />
        </Card>
        <Btn label="Revoir l'introduction" icon="play-circle-outline" variant="ghost" onPress={() => setReplay(true)} />
      </Section>
      <Disclaimer text="HVAC Pro Ref est un aide-mémoire terrain. Les données (modèles, codes, valeurs de calcul) sont indicatives : validez toujours avec le manuel officiel, la plaque signalétique et les codes en vigueur (CSA B52, Code de construction du Québec)." />
    </Screen>
    {replay ? <Intro onDone={() => setReplay(false)} /> : null}
    </View>
  );
}
