import { useMemo, useState } from "react";
import { View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { BrandAvatar, Btn, Card, Chip, ChipRow, Empty, Hero, HeroIcon, Screen, SearchBar, Section, Segmented, T, Disclaimer } from "../../components/ui";
import { CodeCard, ModelRow } from "../../components/hvac";
import { useColors } from "../../hooks/use-colors";
import { useStore } from "../../lib/store";
import { brandById, manualSearchUrl } from "../../data/brands";
import { setsForBrand } from "../../data/errors";
import { SERIAL_DECODERS, SERIAL_TIPS } from "../../data/serial";
import type { SystemType } from "../../data/types";
import { allModels, fmtK, searchModels } from "../../lib/search";
import { openUrl } from "../../lib/files";
import { BTU_OPTIONS } from "../../data/models";

type Tab = "models" | "codes" | "docs";

export default function BrandScreen() {
  const c = useColors();
  const { id, type: tParam, tab: tabParam } = useLocalSearchParams<{ id: string; type?: string; tab?: string }>();
  const b = brandById(id);
  const { isFavBrand, toggleFavoriteBrand, settings, setSetting, customModels } = useStore();
  const [tab, setTab] = useState<Tab>(tabParam === "codes" || tabParam === "docs" ? tabParam : "models");
  const initialType: SystemType = tParam === "central" || tParam === "mural" ? tParam : b?.types[0] ?? "mural";
  const [type, setType] = useState<SystemType>(b?.types.includes(initialType) ? initialType : b?.types[0] ?? "mural");
  const [q, setQ] = useState("");
  const [btu, setBtu] = useState<number | null>(null);
  const [setIdx, setSetIdx] = useState(0);

  const models = useMemo(() => (b ? searchModels(q, { type, brandIds: [b.id], btu }, customModels) : []), [b, q, type, btu, customModels]);
  const total = useMemo(() => (b ? allModels(customModels).filter((m) => m.brandId === b.id).length : 0), [b, customModels]);
  const sets = b ? setsForBrand(b.id, type) : [];
  const set = sets[Math.min(setIdx, sets.length - 1)];

  if (!b) {
    return (
      <Screen>
        <Hero back title="Marque introuvable" />
        <Empty icon="help" title="Cette marque n'existe pas" />
      </Screen>
    );
  }
  const isPrimary = settings.primaryBrand === b.id;
  const decoder = b.serial ? SERIAL_DECODERS[b.serial] : undefined;

  return (
    <Screen>
      <Hero
        back
        title={b.name}
        subtitle={`${b.origin}${b.oem ? ` · plateforme ${b.oem}` : ""} · ${total} modèles`}
        right={
          <View style={{ flexDirection: "row", gap: 8 }}>
            <HeroIcon name={isFavBrand(b.id) ? "star" : "star-outline"} active={isFavBrand(b.id)} onPress={() => toggleFavoriteBrand(b.id)} />
          </View>
        }
      >
        <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <BrandAvatar name={b.name} color={b.color} size={46} />
          <Chip
            label={isPrimary ? "★ Marque principale" : "Définir comme principale"}
            active={isPrimary}
            color={c.accent}
            onPress={() => {
              setSetting("primaryBrand", isPrimary ? undefined : b.id);
              if (!isPrimary && !isFavBrand(b.id)) toggleFavoriteBrand(b.id);
            }}
          />
        </View>
      </Hero>

      <View style={{ paddingHorizontal: 16, marginTop: 14, gap: 10 }}>
        {b.types.length > 1 ? (
          <Segmented value={type} onChange={(v) => { setType(v); setBtu(null); setSetIdx(0); }} options={[{ value: "mural", label: "Muraux" }, { value: "central", label: "Centraux" }]} />
        ) : null}
        <Segmented value={tab} onChange={setTab} options={[{ value: "models", label: "Modèles" }, { value: "codes", label: "Codes" }, { value: "docs", label: "Manuels & série" }]} />
      </View>

      {tab === "models" ? (
        <>
          <View style={{ paddingHorizontal: 16, marginTop: 12 }}>
            <SearchBar value={q} onChange={setQ} placeholder={`Modèle ${b.name}…`} />
          </View>
          <View style={{ marginTop: 10 }}>
            <ChipRow>
              <Chip label="Tous BTU" active={!btu} onPress={() => setBtu(null)} />
              {BTU_OPTIONS[type].map((v) => <Chip key={v} label={fmtK(v)} active={btu === v} onPress={() => setBtu(btu === v ? null : v)} />)}
            </ChipRow>
          </View>
          <Section title={`${models.length} modèle(s)`} action={<Chip label="Ajouter" icon="add" onPress={() => router.push(`/modele-perso/new?type=${type}&brandId=${b.id}`)} />}>
            {models.map((m) => <ModelRow key={m.id} m={m} />)}
            {!models.length ? <Empty icon="cube-outline" title="Aucun modèle" text="Ajoutez votre propre modèle avec ses manuels PDF." /> : null}
          </Section>
        </>
      ) : null}

      {tab === "codes" ? (
        <Section title={set ? set.name : "Codes"}>
          {sets.length > 1 ? (
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
              {sets.map((s, i) => <Chip key={s.id} label={s.name.split("—")[0].split("(")[0].trim()} active={i === setIdx} onPress={() => setSetIdx(i)} />)}
            </View>
          ) : null}
          {set?.note ? <T v="small">{set.note}</T> : null}
          {set ? set.codes.map((code) => <CodeCard key={code.code} code={code} set={set} />) : <Empty icon="warning-outline" title="Pas de codes pour ce type" text="Consultez le manuel de service du modèle." />}
        </Section>
      ) : null}

      {tab === "docs" ? (
        <>
          <Section title="Portails officiels">
            {b.links.map((l) => (
              <Card key={l.url} onPress={() => openUrl(l.url)} style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                <Ionicons name="globe-outline" size={22} color={c.primary} />
                <View style={{ flex: 1 }}>
                  <T v="h3" style={{ fontSize: 15 }}>{l.label}</T>
                  <T v="small" numberOfLines={1}>{l.url.replace(/^https?:\/\//, "")}</T>
                </View>
                <Ionicons name="open-outline" size={18} color={c.mutedForeground} />
              </Card>
            ))}
            <Btn label={`Chercher un manuel ${b.name} (PDF)`} icon="search" variant="ghost" onPress={() => openUrl(manualSearchUrl(b.name, "", "install"))} />
          </Section>
          <Section title="Numéro de série">
            <Card style={{ gap: 8 }}>
              <T v="h3">{decoder ? decoder.label : "Lecture de la date"}</T>
              <T v="small" style={{ color: c.foreground }}>{decoder ? decoder.format : SERIAL_TIPS[b.id] ?? "Consultez la plaque signalétique : la date de fabrication y est généralement inscrite."}</T>
              {decoder ? <Btn label="Décoder un numéro" icon="barcode-outline" onPress={() => router.push(`/serie?b=${b.id}`)} /> : null}
            </Card>
          </Section>
        </>
      ) : null}
      <Disclaimer />
    </Screen>
  );
}
