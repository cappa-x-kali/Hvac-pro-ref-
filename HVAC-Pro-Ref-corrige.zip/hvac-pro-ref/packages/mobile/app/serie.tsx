import { useMemo, useState } from "react";
import { View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Card, Chip, ChipRow, Field, Hero, Screen, Section, T, Disclaimer } from "../components/ui";
import { ModelRow } from "../components/hvac";
import { useColors } from "../hooks/use-colors";
import { useStore } from "../lib/store";
import { BRANDS } from "../data/brands";
import { SERIAL_DECODERS, SERIAL_TIPS, decodeSerial } from "../data/serial";
import { Fonts } from "../constants/theme";

export default function SerialScreen() {
  const c = useColors();
  const p = useLocalSearchParams<{ s?: string; b?: string }>();
  const { sortBrands, customModels } = useStore();
  const brands = useMemo(() => sortBrands(BRANDS), [sortBrands]);
  const [brandId, setBrandId] = useState<string>(p.b ?? brands[0]?.id ?? "carrier");
  const [serial, setSerial] = useState(p.s ?? "");
  const brand = BRANDS.find((b) => b.id === brandId);
  const decoder = brand?.serial ? SERIAL_DECODERS[brand.serial] : undefined;
  const res = decoder && serial.trim() ? decodeSerial(brand!.serial!, serial) : null;
  const age = res?.year ? new Date().getFullYear() - res.year : null;
  const matches = serial.trim().length >= 4 ? customModels.filter((m) => m.serial && m.serial.includes(serial.trim().toUpperCase())) : [];

  return (
    <Screen>
      <Hero back compact title="Numéro de série" subtitle="Trouver l'année de fabrication d'un appareil" />
      <View style={{ gap: 8, marginTop: 16 }}>
        <T v="label" style={{ paddingHorizontal: 16 }}>Marque</T>
        <ChipRow>
          {brands.map((b) => <Chip key={b.id} label={b.name} color={b.color} active={brandId === b.id} icon={b.serial ? "flash" : undefined} onPress={() => setBrandId(b.id)} />)}
        </ChipRow>
      </View>
      <View style={{ padding: 16, gap: 12 }}>
        <Field label="Numéro de série" value={serial} onChangeText={setSerial} placeholder="ex. 1209E12345" autoCapitalize="characters" autoCorrect={false} />
        <Card style={{ gap: 6 }}>
          <T v="label">{decoder ? decoder.label : "Pas de décodage automatique"}</T>
          <T v="small" style={{ color: c.foreground }}>{decoder ? decoder.format : SERIAL_TIPS[brandId] ?? "La date de fabrication est indiquée sur la plaque signalétique de l'appareil."}</T>
        </Card>
        {res ? (
          <Card style={{ gap: 6, borderColor: res.ok ? c.success : c.warning, borderWidth: 2 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
              <Ionicons name={res.ok ? "checkmark-circle" : "alert-circle"} size={22} color={res.ok ? c.success : c.warning} />
              <T v="h3">{res.ok ? "Date de fabrication" : "Décodage impossible"}</T>
            </View>
            {res.date ? <T v="h1" style={{ fontSize: 26 }}>{res.date}</T> : null}
            <T v="small" style={{ color: c.foreground }}>{res.detail}</T>
            {age != null && age >= 0 ? (
              <T v="small" style={{ fontFamily: Fonts.bodyBold, color: age > 15 ? c.destructive : c.foreground }}>
                Âge ≈ {age} an{age > 1 ? "s" : ""}{res.year && res.year < 2010 ? " — probablement R-22 si climatiseur/thermopompe" : ""}
              </T>
            ) : null}
          </Card>
        ) : null}
      </View>
      {matches.length ? (
        <Section title="Mes modèles avec ce n° de série">
          {matches.map((m) => <ModelRow key={m.id} m={m} />)}
        </Section>
      ) : null}
      <Disclaimer text="Les formats de numéros de série changent selon l'usine et l'époque. Confirmez avec la plaque signalétique ou le fabricant." />
    </Screen>
  );
}
