import { Stack, useLocalSearchParams } from "expo-router";
import { Disclaimer, Empty, Hero, Screen } from "../../components/ui";
import { toolById } from "../../components/tools/registry";

export default function ToolScreen() {
  const { tool } = useLocalSearchParams<{ tool: string }>();
  const t = toolById(tool);
  return (
    <Screen>
      <Stack.Screen options={{ headerShown: false }} />
      <Hero back title={t?.title ?? "Outil"} subtitle={t?.desc} compact />
      {t ? <t.C /> : <Empty icon="construct" title="Outil introuvable" />}
      {tool === "remote" ? null : <Disclaimer text="Outil d'aide au calcul. Les valeurs du fabricant (plaque, manuel d'installation) ont toujours préséance." />}
    </Screen>
  );
}
