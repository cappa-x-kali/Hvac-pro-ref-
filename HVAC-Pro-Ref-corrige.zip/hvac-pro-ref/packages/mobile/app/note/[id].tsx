import { useMemo, useState } from "react";
import { Alert, Platform, TextInput, View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Btn, Chip, ChipRow, Field, Hero, HeroIcon, Screen, Section, T } from "../../components/ui";
import { Attachments } from "../../components/attachments";
import { useColors } from "../../hooks/use-colors";
import { useStore, type Attachment } from "../../lib/store";
import { BRANDS } from "../../data/brands";
import { modelById } from "../../data/models";
import { Fonts } from "../../constants/theme";
import { tr, loc } from "../../lib/i18n";

export default function NoteEditor() {
  const c = useColors();
  const params = useLocalSearchParams<{ id: string; modelId?: string; brandId?: string; title?: string; tag?: string }>();
  const { notes, saveNote, deleteNote, sortBrands, customModels } = useStore();
  const existing = notes.find((n) => n.id === params.id);
  const preModel = params.modelId ? modelById(params.modelId) ?? customModels.find((m) => m.id === params.modelId) : undefined;

  const [title, setTitle] = useState(existing?.title ?? params.title ?? "");
  const [body, setBody] = useState(existing?.body ?? "");
  const [brandId, setBrandId] = useState<string | undefined>(existing?.brandId ?? preModel?.brandId ?? params.brandId);
  const [modelLabel, setModelLabel] = useState(existing?.modelLabel ?? preModel?.indoor ?? "");
  const [client, setClient] = useState(existing?.client ?? "");
  const [address, setAddress] = useState(existing?.address ?? "");
  const [tags, setTags] = useState(existing ? existing.tags.join(", ") : params.tag ?? "");
  const [pinned, setPinned] = useState(!!existing?.pinned);
  const [attachments, setAttachments] = useState<Attachment[]>(existing?.attachments ?? []);
  const brands = useMemo(() => sortBrands(BRANDS), [sortBrands]);

  const save = () => {
    saveNote({
      id: existing?.id,
      title: title.trim() || modelLabel || "Sans titre",
      body, brandId, modelLabel: modelLabel.trim() || undefined,
      modelId: existing?.modelId ?? params.modelId,
      client: client.trim() || undefined, address: address.trim() || undefined,
      tags: tags.split(/[,#]/).map((t) => t.trim().toLowerCase()).filter(Boolean),
      pinned, attachments,
    });
    router.back();
  };
  const remove = () => {
    if (!existing) return router.back();
    const doIt = () => { deleteNote(existing.id); router.back(); };
    if (Platform.OS === "web") return doIt();
    Alert.alert(tr("Supprimer la note ?"), tr("Cette action est définitive."), [{ text: tr("Annuler"), style: "cancel" }, { text: tr("Supprimer"), style: "destructive", onPress: doIt }]);
  };

  return (
    <Screen>
      <Hero
        back compact
        title={existing ? "Modifier la note" : "Nouvelle note"}
        subtitle={existing ? `Modifiée le ${new Date(existing.updatedAt).toLocaleString(loc())}` : "Enregistrée seulement sur ce téléphone"}
        right={<HeroIcon name={pinned ? "pin" : "pin-outline"} active={pinned} onPress={() => setPinned(!pinned)} />}
      />
      <View style={{ padding: 16, gap: 14 }}>
        <Field label="Titre" value={title} onChangeText={setTitle} placeholder="ex. Installation 12k — Mme Tremblay" />
        <View style={{ gap: 6 }}>
          <T v="label">Remarques</T>
          <TextInput
            value={body}
            onChangeText={setBody}
            multiline
            placeholder="Pressions, surchauffe, charge ajoutée, pièces remplacées, observations…"
            placeholderTextColor={c.mutedForeground}
            style={{ minHeight: 160, textAlignVertical: "top", backgroundColor: c.muted, borderRadius: 12, borderWidth: 1, borderColor: c.border, padding: 12, fontFamily: Fonts.body, fontSize: 15, color: c.foreground }}
          />
        </View>
      </View>
      <View style={{ gap: 8 }}>
        <T v="label" style={{ paddingHorizontal: 16 }}>Marque</T>
        <ChipRow>
          <Chip label="Aucune" active={!brandId} onPress={() => setBrandId(undefined)} />
          {brands.map((b) => <Chip key={b.id} label={b.name} color={b.color} active={brandId === b.id} onPress={() => setBrandId(b.id)} />)}
        </ChipRow>
      </View>
      <View style={{ padding: 16, gap: 14 }}>
        <Field label="Modèle / n° de série" value={modelLabel} onChangeText={setModelLabel} placeholder="ex. MSZ-FS12NA / 1ZU01234" autoCapitalize="characters" />
        <View style={{ flexDirection: "row", gap: 10 }}>
          <Field label="Client" value={client} onChangeText={setClient} placeholder="Nom" />
          <Field label="Mots-clés" value={tags} onChangeText={setTags} placeholder="garantie, fuite" autoCapitalize="none" />
        </View>
        <Field label="Adresse" value={address} onChangeText={setAddress} placeholder="Adresse du chantier" />
      </View>
      <Section title="Pièces jointes (photos, PDF)">
        <Attachments items={attachments} onChange={setAttachments} />
      </Section>
      <View style={{ padding: 16, gap: 10, marginTop: 8 }}>
        <Btn label="Enregistrer" icon="checkmark" onPress={save} />
        {existing ? <Btn label="Supprimer" icon="trash-outline" variant="danger" onPress={remove} /> : null}
      </View>
    </Screen>
  );
}
