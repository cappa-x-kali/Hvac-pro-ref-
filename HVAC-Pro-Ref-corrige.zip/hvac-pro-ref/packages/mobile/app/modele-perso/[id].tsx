import { useMemo, useState } from "react";
import { Alert, Platform, TextInput, View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Btn, Chip, ChipRow, Field, Hero, Screen, Section, Segmented, T } from "../../components/ui";
import { Attachments } from "../../components/attachments";
import { useColors } from "../../hooks/use-colors";
import { useStore, type Attachment } from "../../lib/store";
import { BRANDS, brandById } from "../../data/brands";
import { BTU_OPTIONS, REFRIGERANTS, modelById } from "../../data/models";
import { fmtK } from "../../lib/search";
import { REF_COLORS, Fonts } from "../../constants/theme";
import type { Refrigerant, SystemType } from "../../data/types";
import { tr } from "../../lib/i18n";

export default function CustomModelEditor() {
  const c = useColors();
  const p = useLocalSearchParams<{ id: string; type?: string; brandId?: string; from?: string }>();
  const id = decodeURIComponent(p.id ?? "new");
  const { customModels, saveCustomModel, sortBrands } = useStore();
  const ex = customModels.find((m) => m.id === id);
  const src = ex ?? (p.from ? modelById(decodeURIComponent(p.from)) : undefined);
  const brands = useMemo(() => sortBrands(BRANDS), [sortBrands]);

  const [type, setType] = useState<SystemType>((src?.type ?? (p.type === "central" ? "central" : "mural")) as SystemType);
  const [brandId, setBrandId] = useState<string>(src?.brandId ?? p.brandId ?? "custom");
  const [otherBrand, setOtherBrand] = useState(ex?.brandId === "custom" ? ex.brandName : "");
  const [series, setSeries] = useState(src?.series ?? "");
  const [indoor, setIndoor] = useState(src?.indoor ?? "");
  const [outdoor, setOutdoor] = useState(src?.outdoor ?? "");
  const [btu, setBtu] = useState(String(src?.btu ?? 12000));
  const [refr, setRefr] = useState<Refrigerant>(src?.refrigerant ?? "R410A");
  const [yearFrom, setYearFrom] = useState(String(src?.yearFrom ?? new Date().getFullYear()));
  const [yearTo, setYearTo] = useState(src?.yearTo ? String(src.yearTo) : "");
  const [seer, setSeer] = useState(src?.seer ?? "");
  const [voltage, setVoltage] = useState(src?.voltage ?? "208/230 V 1 ph");
  const [serial, setSerial] = useState(ex?.serial ?? "");
  const [remarks, setRemarks] = useState(ex?.remarks ?? "");
  const [manuals, setManuals] = useState<Attachment[]>(ex?.manuals ?? []);

  const save = () => {
    if (!indoor.trim()) {
      const msg = "Indiquez au moins le numéro de modèle.";
      return Platform.OS === "web" ? undefined : Alert.alert(tr("Modèle requis"), tr(msg));
    }
    const n = Number(btu.replace(/\s/g, ""));
    const newId = saveCustomModel({
      id: ex?.id,
      type, brandId,
      brandName: brandId === "custom" ? otherBrand.trim() || "Autre" : brandById(brandId)?.name ?? "",
      series: series.trim() || "Perso",
      indoor: indoor.trim().toUpperCase(),
      outdoor: outdoor.trim().toUpperCase() || undefined,
      btu: Number.isFinite(n) && n > 0 ? n : 12000,
      refrigerant: refr,
      yearFrom: Number(yearFrom) || new Date().getFullYear(),
      yearTo: Number(yearTo) || undefined,
      seer: seer.trim() || undefined,
      voltage: voltage.trim(),
      serial: serial.trim().toUpperCase() || undefined,
      remarks: remarks.trim() || undefined,
      manuals,
      custom: true,
    });
    router.replace(`/modele/${encodeURIComponent(newId)}`);
  };

  return (
    <Screen>
      <Hero back compact title={ex ? "Modifier le modèle" : "Nouveau modèle perso"} subtitle="Ajoutez un modèle absent du catalogue, avec vos manuels PDF" />
      <View style={{ padding: 16, gap: 12 }}>
        <Segmented value={type} onChange={(v) => { setType(v); }} options={[{ value: "mural", label: "Mural" }, { value: "central", label: "Central" }]} />
      </View>
      <View style={{ gap: 8 }}>
        <T v="label" style={{ paddingHorizontal: 16 }}>Marque</T>
        <ChipRow>
          {brands.map((b) => <Chip key={b.id} label={b.name} color={b.color} active={brandId === b.id} onPress={() => setBrandId(b.id)} />)}
          <Chip label="Autre…" active={brandId === "custom"} onPress={() => setBrandId("custom")} />
        </ChipRow>
      </View>
      <View style={{ padding: 16, gap: 12 }}>
        {brandId === "custom" ? <Field label="Nom de la marque" value={otherBrand} onChangeText={setOtherBrand} placeholder="ex. Klimaire" /> : null}
        <Field label="Modèle intérieur *" value={indoor} onChangeText={setIndoor} placeholder="ex. MSZ-FS12NA" autoCapitalize="characters" />
        <Field label="Modèle extérieur" value={outdoor} onChangeText={setOutdoor} placeholder="ex. MUZ-FS12NAH" autoCapitalize="characters" />
        <Field label="Série" value={series} onChangeText={setSeries} placeholder="ex. FS Hyper-Heat" />
        <Field label="Numéro de série" value={serial} onChangeText={setSerial} placeholder="Plaque signalétique" autoCapitalize="characters" />
      </View>
      <Section title="Capacité">
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
          {BTU_OPTIONS[type].map((v) => <Chip key={v} label={fmtK(v)} active={Number(btu) === v} onPress={() => setBtu(String(v))} />)}
        </View>
        <Field label="BTU/h" value={btu} onChangeText={setBtu} keyboardType="numeric" />
      </Section>
      <Section title="Réfrigérant">
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
          {REFRIGERANTS.map((r) => <Chip key={r} label={r} color={REF_COLORS[r]} active={refr === r} onPress={() => setRefr(r)} />)}
        </View>
      </Section>
      <View style={{ padding: 16, gap: 12 }}>
        <View style={{ flexDirection: "row", gap: 10 }}>
          <Field label="Année début" value={yearFrom} onChangeText={setYearFrom} keyboardType="numeric" />
          <Field label="Année fin" value={yearTo} onChangeText={setYearTo} keyboardType="numeric" placeholder="—" />
        </View>
        <View style={{ flexDirection: "row", gap: 10 }}>
          <Field label="SEER" value={seer} onChangeText={setSeer} placeholder="ex. 22" />
          <Field label="Alimentation" value={voltage} onChangeText={setVoltage} />
        </View>
        <View style={{ gap: 6 }}>
          <T v="label">Remarques</T>
          <TextInput
            value={remarks}
            onChangeText={setRemarks}
            multiline
            placeholder="Charge d'usine, longueur pré-chargée, particularités…"
            placeholderTextColor={c.mutedForeground}
            style={{ minHeight: 100, textAlignVertical: "top", backgroundColor: c.muted, borderRadius: 12, borderWidth: 1, borderColor: c.border, padding: 12, fontFamily: Fonts.body, fontSize: 15, color: c.foreground }}
          />
        </View>
      </View>
      <Section title="Manuels PDF et photos">
        <Attachments items={manuals} onChange={setManuals} pdfLabel="Ajouter un PDF" />
      </Section>
      <View style={{ padding: 16, marginTop: 8 }}>
        <Btn label="Enregistrer le modèle" icon="checkmark" onPress={save} />
      </View>
    </Screen>
  );
}
