import { useState } from "react";
import { Alert, Platform, View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Btn, Card, Empty, Hero, HeroIcon, Pill, RefBadge, Screen, Section, Segmented, T, Disclaimer } from "../../components/ui";
import { PartsTab, SystemImage, WiringTab } from "../../components/model-tabs";
import { NoteCard } from "../../components/hvac";
import { Attachments } from "../../components/attachments";
import { useColors } from "../../hooks/use-colors";
import { useStore } from "../../lib/store";
import { brandById, manualSearchUrl } from "../../data/brands";
import { modelById } from "../../data/models";
import { setsForBrand } from "../../data/errors";
import { refById } from "../../data/refrigerants";
import { brandName, fmtBtu, fmtTons, fmtYears } from "../../lib/search";
import { openUrl } from "../../lib/files";
import { Fonts } from "../../constants/theme";
import { tr, loc } from "../../lib/i18n";

export default function ModelScreen() {
  const c = useColors();
  const { id: raw } = useLocalSearchParams<{ id: string }>();
  const id = decodeURIComponent(raw ?? "");
  const { customModels, isFavModel, toggleFavoriteModel, notes, saveCustomModel, deleteCustomModel } = useStore();
  const custom = customModels.find((m) => m.id === id);
  const m = custom ?? modelById(id);
  const [tab, setTab] = useState<"fiche" | "pieces" | "plans">("fiche");

  if (!m) {
    return (
      <Screen>
        <Hero back title="Modèle introuvable" />
        <Empty icon="help" title="Ce modèle n'existe plus" />
      </Screen>
    );
  }
  const b = brandById(m.brandId);
  const bName = brandName(m);
  const sets = b ? setsForBrand(b.id, m.type) : [];
  const nCodes = sets.reduce((n, s) => n + s.codes.length, 0);
  const linked = notes.filter((n) => n.modelId === m.id || (n.modelLabel && m.indoor && n.modelLabel.toUpperCase().includes(m.indoor.replace(/\*/g, "").toUpperCase().slice(0, 8))));
  const ref = refById(m.refrigerant);

  const specs: [string, string | undefined][] = [
    ["Série", m.series],
    [m.zones ? "Unité extérieure (multizone)" : "Unité intérieure", m.indoor],
    ["Unité extérieure", m.outdoor],
    ["Zones", m.zones],
    ["Têtes compatibles", m.heads],
    ["Capacité", `${m.btu.toLocaleString(loc())} BTU/h · ${fmtTons(m.btu)} · ${(m.btu / 3412).toLocaleString(loc(), { maximumFractionDigits: 1 })} kW`],
    ["Années", m.approx ? `≈ ${fmtYears(m)}` : fmtYears(m)],
    ["Type", m.kind],
    ["SEER", m.seer],
    ["HSPF", m.hspf],
    ["Chauffage jusqu'à", m.minHeat],
    ["Alimentation", m.voltage],
    ["N° de série", custom?.serial],
  ];

  const remove = () => {
    const doIt = () => { deleteCustomModel(m.id); router.back(); };
    if (Platform.OS === "web") return doIt();
    Alert.alert(tr("Supprimer ce modèle ?"), m.indoor, [{ text: tr("Annuler"), style: "cancel" }, { text: tr("Supprimer"), style: "destructive", onPress: doIt }]);
  };

  const manual = (kind: "owner" | "install" | "service", label: string, icon: keyof typeof Ionicons.glyphMap) => (
    <Card onPress={() => openUrl(manualSearchUrl(bName, (m.indoor || "").replace(/\*/g, ""), kind))} style={{ flexDirection: "row", alignItems: "center", gap: 12, padding: 14 }}>
      <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: c.destructive + "14", alignItems: "center", justifyContent: "center" }}>
        <Ionicons name={icon} size={20} color={c.destructive} />
      </View>
      <View style={{ flex: 1 }}>
        <T v="h3" style={{ fontSize: 15 }}>{label}</T>
        <T v="small">Recherche PDF · {m.indoor}</T>
      </View>
      <Ionicons name="open-outline" size={18} color={c.mutedForeground} />
    </Card>
  );

  return (
    <Screen>
      <Hero
        back
        title={m.indoor}
        subtitle={`${bName} · ${m.series}`}
        right={<HeroIcon name={isFavModel(m.id) ? "star" : "star-outline"} active={isFavModel(m.id)} onPress={() => toggleFavoriteModel(m.id)} />}
      >
        <View style={{ flexDirection: "row", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
          <View style={{ backgroundColor: "rgba(255,255,255,0.95)", borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4 }}>
            <T v="small" style={{ fontFamily: Fonts.bodyBold, color: "#0E1726" }}>{fmtBtu(m.btu)}</T>
          </View>
          <View style={{ backgroundColor: "rgba(255,255,255,0.95)", borderRadius: 999, padding: 2 }}>
            <RefBadge r={m.refrigerant} />
          </View>
          <View style={{ backgroundColor: "rgba(255,255,255,0.95)", borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4 }}>
            <T v="small" style={{ fontFamily: Fonts.bodyBold, color: "#0E1726" }}>{m.type === "mural" ? "Mural" : "Central"}</T>
          </View>
          {m.custom ? <Pill label="MODÈLE PERSO" color="#FFB300" /> : null}
        </View>
      </Hero>

      <View style={{ paddingHorizontal: 16, marginTop: 14, gap: 12 }}>
        <SystemImage m={m} brand={bName} />
        <Segmented value={tab} onChange={setTab} options={[{ value: "fiche", label: "Fiche" }, { value: "pieces", label: "Pièces" }, { value: "plans", label: "Plans élec." }]} />
      </View>

      {tab === "pieces" ? <PartsTab m={m} brand={bName} /> : null}
      {tab === "plans" ? <WiringTab m={m} brand={bName} /> : null}

      {tab === "fiche" ? (<>
      <Section title="Fiche technique">
        <Card style={{ padding: 0, overflow: "hidden" }}>
          {specs.filter(([, v]) => !!v).map(([k, v], i) => (
            <View key={k} style={{ flexDirection: "row", justifyContent: "space-between", gap: 12, paddingHorizontal: 16, paddingVertical: 12, borderTopWidth: i ? 1 : 0, borderTopColor: c.border }}>
              <T v="small">{k}</T>
              <T style={{ fontFamily: Fonts.bodyBold, flexShrink: 1, textAlign: "right" }}>{v}</T>
            </View>
          ))}
        </Card>
        {m.approx ? (
          <T v="small" style={{ paddingHorizontal: 4 }}>Fiche issue du catalogue des distributeurs québécois : années et performances approximatives. Validez toujours avec la plaque signalétique et le manuel officiel.</T>
        ) : null}
        {custom?.remarks ? (
          <Card style={{ gap: 4 }}>
            <T v="label">Remarques</T>
            <T>{custom.remarks}</T>
          </Card>
        ) : null}
      </Section>

      <Section title="Réfrigérant">
        {ref ? (
          <Card onPress={() => router.push("/outils/pt")} style={{ flexDirection: "row", alignItems: "center", gap: 12, borderLeftWidth: 5, borderLeftColor: ref.color }}>
            <View style={{ flex: 1, gap: 2 }}>
              <T v="h3">{ref.name}</T>
              <T v="small">{ref.safety} · huile {ref.oil} · PRP {ref.gwp}</T>
            </View>
            <View style={{ alignItems: "flex-end" }}>
              <T v="small" color={c.primary} style={{ fontFamily: Fonts.bodyBold }}>Tableau P/T</T>
              <Ionicons name="chevron-forward" size={18} color={c.primary} />
            </View>
          </Card>
        ) : <T v="small">Réfrigérant non référencé : vérifiez la plaque signalétique et la documentation du fabricant.</T>}
      </Section>

      <Section title="Codes d'erreur">
        <Card onPress={() => b && router.push(`/marque/${b.id}?type=${m.type}&tab=codes`)} style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <Ionicons name="warning" size={24} color={c.destructive} />
          <View style={{ flex: 1 }}>
            <T v="h3">{nCodes ? `${nCodes} codes ${bName}` : "Aucun jeu de codes associé"}</T>
            <T v="small" numberOfLines={2}>{sets.map((s) => s.name).join(" · ") || "Consultez le manuel de service."}</T>
          </View>
          {nCodes ? <Ionicons name="chevron-forward" size={18} color={c.mutedForeground} /> : null}
        </Card>
      </Section>

      {custom ? (
        <Section title="Mes manuels (PDF)">
          <Attachments items={custom.manuals} onChange={(manuals) => saveCustomModel({ id: custom.id, manuals })} pdfLabel="Ajouter un PDF" />
        </Section>
      ) : null}

      <Section title="Manuels en ligne">
        {manual("owner", "Manuel d'utilisation", "person-outline")}
        {manual("install", "Manuel d'installation", "construct-outline")}
        {manual("service", "Manuel de service / dépannage", "medkit-outline")}
        {b?.links[0] ? <Btn label={b.links[0].label} icon="globe-outline" variant="ghost" onPress={() => openUrl(b.links[0].url)} /> : null}
      </Section>

      <Section title={`Mes notes (${linked.length})`} action={<Btn label="Ajouter" icon="add" variant="ghost" style={{ height: 36, paddingHorizontal: 12 }} onPress={() => router.push(`/note/new?modelId=${encodeURIComponent(m.id)}`)} />}>
        {linked.map((n) => <NoteCard key={n.id} n={n} />)}
        {!linked.length ? <T v="small">Ajoutez une note ou joignez votre propre manuel PDF pour ce modèle.</T> : null}
      </Section>

      </>) : null}

      {custom ? (
        <View style={{ padding: 16, gap: 10 }}>
          <Btn label="Modifier le modèle" icon="create-outline" onPress={() => router.push(`/modele-perso/${encodeURIComponent(custom.id)}`)} />
          <Btn label="Supprimer" icon="trash-outline" variant="danger" onPress={remove} />
        </View>
      ) : (
        <View style={{ paddingHorizontal: 16, marginTop: 16 }}>
          <Btn label="Dupliquer en modèle perso" icon="copy-outline" variant="ghost" onPress={() => router.push(`/modele-perso/new?from=${encodeURIComponent(m.id)}`)} />
        </View>
      )}
      <Disclaimer text="Données indicatives (séries courantes). Les suffixes de modèle, cotes SEER et tensions varient : vérifiez la plaque signalétique et le manuel du modèle exact." />
    </Screen>
  );
}
