import type { ThemeColors } from "../constants/theme";
import { useStore } from "../lib/store";

/** Palette du thème actif (choisi dans Réglages). */
export function useColors(): ThemeColors {
  return useStore().colors;
}
