import { Platform } from "react-native";

export type ThemeColors = {
  background: string;
  foreground: string;
  card: string;
  cardForeground: string;
  primary: string;
  primaryDeep: string;
  primaryForeground: string;
  secondary: string;
  secondaryForeground: string;
  muted: string;
  mutedForeground: string;
  accent: string;
  accentForeground: string;
  border: string;
  destructive: string;
  success: string;
  warning: string;
  heroText: string;
  dark: boolean;
};

export type ThemeCat = "clair" | "sombre" | "contraste";
type ThemeDef = { label: string; desc: string; cat: ThemeCat; colors: ThemeColors };

/** Construit une palette complète à partir de quelques couleurs clés. */
function mk(o: { bg: string; fg: string; card: string; primary: string; deep: string; onPrimary?: string; secondary: string; muted: string; mutedFg: string; accent: string; onAccent?: string; border: string; dark: boolean; destructive?: string; success?: string; warning?: string; heroText?: string }): ThemeColors {
  return {
    background: o.bg, foreground: o.fg, card: o.card, cardForeground: o.fg,
    primary: o.primary, primaryDeep: o.deep, primaryForeground: o.onPrimary ?? "#FFFFFF",
    secondary: o.secondary, secondaryForeground: o.fg, muted: o.muted, mutedForeground: o.mutedFg,
    accent: o.accent, accentForeground: o.onAccent ?? "#FFFFFF", border: o.border,
    destructive: o.destructive ?? (o.dark ? "#F87171" : "#DC2626"), success: o.success ?? (o.dark ? "#34D399" : "#15803D"), warning: o.warning ?? (o.dark ? "#FBBF24" : "#B45309"),
    heroText: o.heroText ?? "#FFFFFF", dark: o.dark,
  };
}

const BASE: Record<"glacier" | "nuit" | "braise" | "foret" | "chantier", ThemeDef> = {
  glacier: {
    label: "Glacier", desc: "Clair, bleu froid — par défaut", cat: "clair",
    colors: {
      background: "#EEF3F9", foreground: "#0E1726", card: "#FFFFFF", cardForeground: "#0E1726",
      primary: "#0B6BCB", primaryDeep: "#063F7A", primaryForeground: "#FFFFFF",
      secondary: "#E2EAF4", secondaryForeground: "#0E1726", muted: "#E6EDF6", mutedForeground: "#5B6B80",
      accent: "#FF7A1A", accentForeground: "#FFFFFF", border: "#D6E0EC",
      destructive: "#DC2626", success: "#16A34A", warning: "#D97706", heroText: "#FFFFFF", dark: false,
    },
  },
  nuit: {
    label: "Nuit technique", desc: "Sombre, idéal en soirée", cat: "sombre",
    colors: {
      background: "#0A0F17", foreground: "#E8EEF6", card: "#131B26", cardForeground: "#E8EEF6",
      primary: "#4CC2FF", primaryDeep: "#0B3A5C", primaryForeground: "#04121D",
      secondary: "#1B2533", secondaryForeground: "#E8EEF6", muted: "#18212E", mutedForeground: "#8A9AB0",
      accent: "#FF9447", accentForeground: "#1A0B00", border: "#223042",
      destructive: "#F87171", success: "#34D399", warning: "#FBBF24", heroText: "#FFFFFF", dark: true,
    },
  },
  braise: {
    label: "Braise", desc: "Clair, tons chauds", cat: "clair",
    colors: {
      background: "#FBF5EF", foreground: "#2A160B", card: "#FFFFFF", cardForeground: "#2A160B",
      primary: "#C2410C", primaryDeep: "#7C2D12", primaryForeground: "#FFFFFF",
      secondary: "#F5E7DA", secondaryForeground: "#2A160B", muted: "#F3E8DD", mutedForeground: "#7A6150",
      accent: "#0E7490", accentForeground: "#FFFFFF", border: "#EBD9C8",
      destructive: "#B91C1C", success: "#15803D", warning: "#B45309", heroText: "#FFFFFF", dark: false,
    },
  },
  foret: {
    label: "Forêt", desc: "Clair, vert naturel", cat: "clair",
    colors: {
      background: "#EFF5F0", foreground: "#0F1F16", card: "#FFFFFF", cardForeground: "#0F1F16",
      primary: "#1F7A4D", primaryDeep: "#0F4229", primaryForeground: "#FFFFFF",
      secondary: "#DDEBE1", secondaryForeground: "#0F1F16", muted: "#E2EEE5", mutedForeground: "#56705F",
      accent: "#D99A0B", accentForeground: "#1F1500", border: "#D2E3D7",
      destructive: "#DC2626", success: "#15803D", warning: "#B45309", heroText: "#FFFFFF", dark: false,
    },
  },
  chantier: {
    label: "Chantier", desc: "Contraste élevé, lisible au soleil", cat: "contraste",
    colors: {
      background: "#000000", foreground: "#FFFFFF", card: "#121212", cardForeground: "#FFFFFF",
      primary: "#FFD400", primaryDeep: "#3A3000", primaryForeground: "#000000",
      secondary: "#1E1E1E", secondaryForeground: "#FFFFFF", muted: "#1A1A1A", mutedForeground: "#BDBDBD",
      accent: "#22D3EE", accentForeground: "#000000", border: "#3A3A3A",
      destructive: "#FF5252", success: "#4ADE80", warning: "#FFD400", heroText: "#FFD400", dark: true,
    },
  },
};

const EXTRA = {
  ocean: { label: "Océan", desc: "Clair, bleu-vert marin", cat: "clair", colors: mk({ bg: "#EDF7F7", fg: "#0B2125", card: "#FFFFFF", primary: "#0F8A8F", deep: "#06474B", secondary: "#DCEEEE", muted: "#E1F0F0", mutedFg: "#557276", accent: "#F2546B", border: "#CFE4E5", dark: false }) },
  lavande: { label: "Lavande", desc: "Clair, violet doux", cat: "clair", colors: mk({ bg: "#F4F1FB", fg: "#1D1530", card: "#FFFFFF", primary: "#6D4AD8", deep: "#3A2380", secondary: "#E8E1F7", muted: "#ECE6F8", mutedFg: "#6C6285", accent: "#E89B12", onAccent: "#1D1200", border: "#DDD4F0", dark: false }) },
  sable: { label: "Sable", desc: "Clair, beige et brun", cat: "clair", colors: mk({ bg: "#F7F2E8", fg: "#2B2216", card: "#FFFDF8", primary: "#8A6A2F", deep: "#4D3A17", secondary: "#EDE4D2", muted: "#EFE7D8", mutedFg: "#7A6A52", accent: "#2F7D6D", border: "#E2D6BF", dark: false }) },
  ardoise: { label: "Ardoise", desc: "Clair, gris neutre professionnel", cat: "clair", colors: mk({ bg: "#F1F3F5", fg: "#15191E", card: "#FFFFFF", primary: "#3E4C5E", deep: "#1F2833", secondary: "#E3E7EC", muted: "#E7EAEE", mutedFg: "#616B78", accent: "#E8590C", border: "#D7DCE2", dark: false }) },
  cerise: { label: "Cerise", desc: "Clair, rouge framboise", cat: "clair", colors: mk({ bg: "#FCF1F3", fg: "#2A0F16", card: "#FFFFFF", primary: "#C2185B", deep: "#6E0D33", secondary: "#F6E0E6", muted: "#F7E5EA", mutedFg: "#7E5A64", accent: "#0277BD", border: "#EED3DA", dark: false }) },
  menthe: { label: "Menthe", desc: "Clair, vert frais", cat: "clair", colors: mk({ bg: "#EEF9F4", fg: "#0D2219", card: "#FFFFFF", primary: "#10A37F", deep: "#065A45", secondary: "#D9F1E7", muted: "#DFF3EA", mutedFg: "#527064", accent: "#7C3AED", border: "#CBE9DC", dark: false }) },
  arctique: { label: "Arctique", desc: "Très clair, cyan glacial", cat: "clair", colors: mk({ bg: "#F4FBFE", fg: "#0A1D29", card: "#FFFFFF", primary: "#0891B2", deep: "#0C4A6E", secondary: "#E0F2F9", muted: "#E6F5FA", mutedFg: "#557486", accent: "#F43F5E", border: "#D3EAF3", dark: false }) },
  papier: { label: "Papier", desc: "Clair, crème reposant pour les yeux", cat: "clair", colors: mk({ bg: "#F5EFE0", fg: "#33291B", card: "#FBF7EC", primary: "#5B4636", deep: "#2E2219", secondary: "#EAE1CC", muted: "#ECE4D1", mutedFg: "#7D705C", accent: "#B4532A", border: "#DED2B8", dark: false }) },
  minuit: { label: "Minuit", desc: "Sombre, bleu marine profond", cat: "sombre", colors: mk({ bg: "#070B1F", fg: "#E6E9F7", card: "#10163A", primary: "#6C8CFF", deep: "#1B2470", onPrimary: "#060A20", secondary: "#182052", muted: "#141B45", mutedFg: "#8C94BE", accent: "#FFB547", onAccent: "#1F1200", border: "#232C61", dark: true }) },
  carbone: { label: "Carbone", desc: "Sombre, graphite neutre", cat: "sombre", colors: mk({ bg: "#111111", fg: "#ECECEC", card: "#1C1C1C", primary: "#A3A3A3", deep: "#3A3A3A", onPrimary: "#0A0A0A", secondary: "#262626", muted: "#222222", mutedFg: "#9A9A9A", accent: "#F97316", onAccent: "#1A0A00", border: "#2F2F2F", dark: true }) },
  aurore: { label: "Aurore", desc: "Sombre, violet et rose", cat: "sombre", colors: mk({ bg: "#120B1E", fg: "#F1E9FB", card: "#1D1430", primary: "#C084FC", deep: "#4C1D95", onPrimary: "#16062B", secondary: "#2A1D45", muted: "#24193B", mutedFg: "#A596BF", accent: "#F472B6", onAccent: "#2A0518", border: "#33254F", dark: true }) },
  volcan: { label: "Volcan", desc: "Sombre, rouge et orange", cat: "sombre", colors: mk({ bg: "#140A08", fg: "#F8E9E4", card: "#221310", primary: "#FF6B3D", deep: "#7A1E0A", onPrimary: "#1F0700", secondary: "#2E1A16", muted: "#291713", mutedFg: "#B39189", accent: "#FFC23D", onAccent: "#1F1400", border: "#3A2420", dark: true }) },
  emeraude: { label: "Émeraude", desc: "Sombre, vert profond", cat: "sombre", colors: mk({ bg: "#06120D", fg: "#E3F4EC", card: "#0F1F18", primary: "#34D399", deep: "#065F46", onPrimary: "#03140D", secondary: "#173027", muted: "#132A21", mutedFg: "#86A99A", accent: "#FACC15", onAccent: "#1A1500", border: "#1F3A2F", dark: true }) },
  cuivre: { label: "Cuivre", desc: "Sombre, brun et cuivre", cat: "sombre", colors: mk({ bg: "#15100C", fg: "#F3E8DE", card: "#211913", primary: "#E08A4F", deep: "#6B3A17", onPrimary: "#1C0D02", secondary: "#2E241C", muted: "#2A2018", mutedFg: "#AA9888", accent: "#4FC3C9", onAccent: "#031A1B", border: "#3A2E24", dark: true }) },
  terminal: { label: "Terminal", desc: "Noir et vert, style écran rétro", cat: "contraste", colors: mk({ bg: "#000000", fg: "#C8FFD4", card: "#07120A", primary: "#22E36B", deep: "#0A4A22", onPrimary: "#001A08", secondary: "#0D1F12", muted: "#0B1A0F", mutedFg: "#7FBF8E", accent: "#FFB000", onAccent: "#1A1100", border: "#173A21", dark: true, heroText: "#C8FFD4" }) },
  contraste: { label: "Contraste clair", desc: "Blanc pur, texte noir — lisibilité maximale", cat: "contraste", colors: mk({ bg: "#FFFFFF", fg: "#000000", card: "#FFFFFF", primary: "#0033CC", deep: "#001A66", secondary: "#EDEDED", muted: "#F0F0F0", mutedFg: "#333333", accent: "#C40000", border: "#000000", dark: false, destructive: "#B00000", success: "#006B1F", warning: "#8A5A00" }) },
} satisfies Record<string, ThemeDef>;

export type ThemeId = keyof typeof BASE | keyof typeof EXTRA;
export const THEMES: Record<ThemeId, ThemeDef> = { ...BASE, ...EXTRA };
export const THEME_CATS: { id: ThemeCat; label: string }[] = [
  { id: "clair", label: "Clairs" },
  { id: "sombre", label: "Sombres" },
  { id: "contraste", label: "Contraste élevé" },
];

/** Compatibilité template */
export const Colors = { light: THEMES.glacier.colors, dark: THEMES.nuit.colors };
export type ColorScheme = keyof typeof Colors;

export const Fonts = {
  display: "Sora_700Bold",
  displaySemi: "Sora_600SemiBold",
  body: "Manrope_500Medium",
  bodyRegular: "Manrope_400Regular",
  bodyBold: "Manrope_700Bold",
  mono: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }) as string,
};

export const REF_COLORS: Record<string, string> = {
  R22: "#8D7B68",
  R410A: "#E1467A",
  R32: "#2BA8E0",
  R454B: "#2E9E5B",
};
