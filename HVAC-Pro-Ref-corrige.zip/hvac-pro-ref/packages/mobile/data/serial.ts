const MONTHS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];

export type SerialResult = { ok: boolean; date?: string; year?: number; detail: string };

const nowY = new Date().getFullYear() % 100;
const yy = (n: number) => (n <= nowY + 1 ? 2000 + n : 1900 + n);
const weekStr = (w: number) => `semaine ${w}`;

type Decoder = { label: string; format: string; decode: (s: string) => SerialResult };

export const SERIAL_DECODERS: Record<string, Decoder> = {
  carrier: {
    label: "Carrier / Bryant / Payne",
    format: "WWYY + usine + séquence (ex. 1209E12345 = semaine 12 de 2009)",
    decode: (s) => {
      const m = s.match(/^(\d{2})(\d{2})/);
      if (!m) return { ok: false, detail: "Doit commencer par 4 chiffres (semaine + année)." };
      const w = +m[1], y = yy(+m[2]);
      if (w < 1 || w > 53) return { ok: false, detail: "Semaine invalide." };
      return { ok: true, year: y, date: `${weekStr(w)}, ${y}`, detail: `Semaine ${m[1]}, année ${m[2]}` };
    },
  },
  icp: {
    label: "ICP (KeepRite, Tempstar, Heil, Comfortmaker, Day & Night)",
    format: "Lettre (usine) + YY + WW (ex. E061512345 = 2006, semaine 15)",
    decode: (s) => {
      const m = s.match(/^[A-Z](\d{2})(\d{2})/);
      if (!m) return { ok: false, detail: "Format attendu : 1 lettre puis 4 chiffres." };
      const y = yy(+m[1]), w = +m[2];
      return { ok: true, year: y, date: `${weekStr(w)}, ${y}`, detail: `Année ${m[1]}, semaine ${m[2]}` };
    },
  },
  goodman: {
    label: "Goodman / Amana / Daikin (central)",
    format: "YYMM + séquence (ex. 0601123456 = janvier 2006)",
    decode: (s) => {
      const m = s.match(/^(\d{2})(\d{2})/);
      if (!m) return { ok: false, detail: "Doit commencer par 4 chiffres." };
      const y = yy(+m[1]), mo = +m[2];
      if (mo < 1 || mo > 12) return { ok: false, detail: "Mois invalide (positions 3-4)." };
      return { ok: true, year: y, date: `${MONTHS[mo - 1]} ${y}`, detail: `Année ${m[1]}, mois ${m[2]}` };
    },
  },
  lennox: {
    label: "Lennox",
    format: "Usine (2) + YY + lettre du mois A–M sans I (ex. 5810C12345 = mars 2010)",
    decode: (s) => {
      const m = s.match(/^\d{2}(\d{2})([A-HJ-M])/);
      if (!m) return { ok: false, detail: "Format : 4 chiffres + lettre de mois." };
      const letters = "ABCDEFGHJKLM";
      const mo = letters.indexOf(m[2]) + 1;
      const y = yy(+m[1]);
      return { ok: true, year: y, date: `${MONTHS[mo - 1]} ${y}`, detail: `Année ${m[1]}, mois ${m[2]}` };
    },
  },
  trane: {
    label: "Trane / American Standard",
    format: "Depuis 2010 : YYWW… (ex. 10131XXXXX = 2010, semaine 13). 2002-2009 : 1er chiffre = année, 2-3 = semaine.",
    decode: (s) => {
      const m10 = s.match(/^(\d{2})(\d{2})\d/);
      if (m10 && +m10[1] >= 10 && +m10[1] <= nowY + 1 && +m10[2] <= 53) {
        const y = 2000 + +m10[1];
        return { ok: true, year: y, date: `${weekStr(+m10[2])}, ${y}`, detail: `Année ${m10[1]}, semaine ${m10[2]}` };
      }
      const m0 = s.match(/^(\d)(\d{2})/);
      if (m0 && +m0[1] >= 2) {
        const y = 2000 + +m0[1];
        return { ok: true, year: y, date: `${weekStr(+m0[2])}, ${y}`, detail: `Format 2002-2009 : année ${m0[1]}, semaine ${m0[2]}` };
      }
      return { ok: false, detail: "Format non reconnu (avant 2002 : codes alphabétiques, voir étiquette)." };
    },
  },
  rheem: {
    label: "Rheem / Ruud",
    format: "Lettre + WWYY (ex. W050912345 = semaine 05, 2009)",
    decode: (s) => {
      const m = s.match(/^[A-Z]{1,2}(\d{2})(\d{2})/);
      if (!m) return { ok: false, detail: "Format : lettre(s) + 4 chiffres." };
      const w = +m[1], y = yy(+m[2]);
      return { ok: true, year: y, date: `${weekStr(w)}, ${y}`, detail: `Semaine ${m[1]}, année ${m[2]}` };
    },
  },
  mitsubishi: {
    label: "Mitsubishi Electric",
    format: "1er chiffre = dernier chiffre de l'année, 2e = mois (1-9, X=oct, Y=nov, Z=déc)",
    decode: (s) => {
      const m = s.match(/^(\d)([1-9XYZ])/);
      if (!m) return { ok: false, detail: "Format : chiffre + mois (1-9/X/Y/Z)." };
      const d = +m[1];
      const mo = "123456789XYZ".indexOf(m[2]) + 1;
      const base = new Date().getFullYear();
      let y = base - ((base - d) % 10 + 10) % 10;
      const alt = y - 10;
      return { ok: true, year: y, date: `${MONTHS[mo - 1]} ${y} (ou ${alt})`, detail: "Le code ne contient que le dernier chiffre de l'année — confirmer avec la série du modèle." };
    },
  },
  lg: {
    label: "LG",
    format: "1er chiffre = dernier chiffre de l'année, 2-3 = mois (ex. 905KA… = mai 2019/2009)",
    decode: (s) => {
      const m = s.match(/^(\d)(\d{2})/);
      if (!m || +m[2] < 1 || +m[2] > 12) return { ok: false, detail: "Format : 1 chiffre année + 2 chiffres mois." };
      const d = +m[1];
      const base = new Date().getFullYear();
      const y = base - ((base - d) % 10 + 10) % 10;
      return { ok: true, year: y, date: `${MONTHS[+m[2] - 1]} ${y} (ou ${y - 10})`, detail: "Dernier chiffre de l'année seulement." };
    },
  },
  samsung: {
    label: "Samsung",
    format: "N° de 15 caractères : 8e = année (lettre), 9e = mois (1-9, A-C)",
    decode: (s) => {
      if (s.length < 9) return { ok: false, detail: "Numéro trop court (15 caractères attendus)." };
      const years: Record<string, number> = { R: 2021, T: 2022, W: 2023, X: 2024, Y: 2025, Z: 2010, B: 2011, C: 2012, D: 2013, F: 2014, G: 2015, H: 2016, J: 2017, K: 2018, M: 2019, N: 2020 };
      const yc = s[7], mc = s[8];
      const y = years[yc];
      const mo = "123456789ABC".indexOf(mc) + 1;
      if (!y || mo < 1) return { ok: false, detail: `Caractères 8-9 « ${yc}${mc} » non reconnus.` };
      return { ok: true, year: y, date: `${MONTHS[mo - 1]} ${y}`, detail: "Table des lettres Samsung — approximative, confirmer sur l'étiquette." };
    },
  },
  york: {
    label: "York / Coleman / Luxaire",
    format: "Depuis 2004 : 2e lettre = mois, 3e-4e = année (codes alphabétiques). La date est souvent imprimée sur la plaque (MFG DATE).",
    decode: () => ({ ok: false, detail: "Le format York varie selon l'usine : consulter la plaque signalétique (« Mfg Date ») ou le guide de nomenclature York." }),
  },
};

export const SERIAL_TIPS: Record<string, string> = {
  daikin: "Muraux Daikin : la date de fabrication est imprimée sur la plaque signalétique (MFG). Centraux Daikin : format YYMM (comme Goodman).",
  fujitsu: "Fujitsu : la date figure sur la plaque signalétique ; le n° de série n'encode pas la date de façon fiable.",
  gree: "Gree / Tosot / C&H : code-barres de 20+ caractères ; la date de production est souvent imprimée sur l'étiquette (Date).",
  midea: "Midea / Senville : code-barres de 22 caractères ; positions 13-16 contiennent généralement AAMM, à valider.",
  senville: "Plateforme Midea : code-barres de 22 caractères ; positions 13-16 contiennent généralement AAMM, à valider.",
  toshiba: "Toshiba-Carrier : voir la date sur la plaque signalétique.",
  panasonic: "Panasonic : les 2 premiers chiffres indiquent souvent l'année et le mois (ex. 7 = 2017, 08 = août) — à valider.",
  napoleon: "Napoleon : date indiquée sur la plaque signalétique.",
};

export function decodeSerial(decoderId: string, serial: string): SerialResult {
  const d = SERIAL_DECODERS[decoderId];
  const s = serial.trim().toUpperCase().replace(/\s/g, "");
  if (!d) return { ok: false, detail: "Aucun décodeur automatique pour cette marque." };
  if (!s) return { ok: false, detail: "Entrez un numéro de série." };
  return d.decode(s);
}
