export type RefInfo = {
  id: string;
  name: string;
  color: string;
  type: string;
  safety: string;
  gwp: number;
  glide: string;
  oil: string;
  cylinder: string;
  notes: string;
  /** Nature de la courbe fournie. Les mélanges zéotropes exigent bulle ET rosée. */
  tableBasis: "pure" | "near-pure" | "bubble-only";
  /** Ces valeurs historiques sont indicatives et ne remplacent pas une source fabricant. */
  dataQuality: "approximate";
  /** Pression de saturation absolue (kPa) à -40…60 °C par pas de 10 °C */
  table: number[];
};

const TEMPS_C = [-40, -30, -20, -10, 0, 10, 20, 30, 40, 50, 60];

export const REFS: RefInfo[] = [
  {
    id: "R22", name: "R-22 (HCFC-22)", color: "#8D7B68", type: "HCFC pur", safety: "A1", gwp: 1810, glide: "0 °C",
    oil: "Minérale (MO) / alkylbenzène", cylinder: "Vert pâle",
    notes: "Réfrigérant HCFC soumis à des restrictions réglementaires. Vérifier les règles canadiennes et provinciales en vigueur avant toute intervention.",
    tableBasis: "pure", dataQuality: "approximate",
    table: [105, 164, 245, 355, 498, 681, 910, 1192, 1534, 1943, 2427],
  },
  {
    id: "R410A", name: "R-410A (HFC)", color: "#E1467A", type: "Mélange quasi-azéotrope HFC", safety: "A1", gwp: 2088, glide: "< 0.2 °C",
    oil: "POE", cylinder: "Rose",
    notes: "Mélange quasi-azéotropique. Charger selon la procédure du fabricant, généralement en phase liquide. Vérifier les exigences réglementaires applicables.",
    tableBasis: "near-pure", dataQuality: "approximate",
    table: [175, 271, 400, 573, 799, 1086, 1445, 1885, 2417, 3054, 3808],
  },
  {
    id: "R32", name: "R-32 (HFC-32)", color: "#2BA8E0", type: "HFC pur", safety: "A2L (légèrement inflammable)", gwp: 675, glide: "0 °C",
    oil: "POE / PVE", cylinder: "Bleu clair à bande rouge",
    notes: "Classe A2L : appliquer les procédures, limites de charge, ventilation et outillage homologué prescrits par le fabricant et les normes applicables.",
    tableBasis: "pure", dataQuality: "approximate",
    table: [177, 273, 406, 582, 813, 1107, 1474, 1928, 2478, 3139, 3926],
  },
  {
    id: "R454B", name: "R-454B (Opteon XL41)", color: "#2E9E5B", type: "Mélange HFO/HFC (R32/R1234yf)", safety: "A2L (légèrement inflammable)", gwp: 466, glide: "≈ 1 °C",
    oil: "POE", cylinder: "Gris à bande rouge",
    notes: "Mélange zéotropique A2L. La courbe disponible est uniquement au point de bulle; la courbe de rosée manque. Ne pas utiliser cette table seule pour calculer la surchauffe. Charger et intervenir selon le manuel fabricant.",
    tableBasis: "bubble-only", dataQuality: "approximate",
    table: [163, 254, 376, 538, 752, 1023, 1362, 1778, 2282, 2886, 3605],
  },
];

export const REF_TEMP_MIN_C = TEMPS_C[0];
export const REF_TEMP_MAX_C = TEMPS_C[TEMPS_C.length - 1];

/** Retourne undefined pour un identifiant inconnu : aucun réfrigérant de repli silencieux. */
export const refById = (id: string): RefInfo | undefined => REFS.find((r) => r.id === id);

const ATM_KPA = 101.325;
const PSI_PER_KPA = 0.1450377;

/**
 * Pression absolue interpolée dans la table interne.
 * Hors plage ou entrée invalide => NaN (aucune extrapolation dangereuse).
 * L'interpolation est indicative et n'est pas une équation d'état certifiée.
 */
export function satPressureKpaAbs(refId: string, tC: number): number {
  const r = refById(refId);
  if (!r || !Number.isFinite(tC) || tC < REF_TEMP_MIN_C || tC > REF_TEMP_MAX_C) return NaN;
  if (r.table.length !== TEMPS_C.length || r.table.some((p) => !Number.isFinite(p) || p <= 0)) return NaN;
  if (tC === REF_TEMP_MIN_C) return r.table[0];
  if (tC === REF_TEMP_MAX_C) return r.table[r.table.length - 1];
  for (let n = 1; n < r.table.length; n++) {
    if (r.table[n] <= r.table[n - 1]) return NaN;
  }
  let i = TEMPS_C.findIndex((t) => t >= tC) - 1;
  if (i < 0) i = 0;
  if (i >= TEMPS_C.length - 1) i = TEMPS_C.length - 2;
  const T = tC + 273.15;
  const T1 = TEMPS_C[i] + 273.15;
  const T2 = TEMPS_C[i + 1] + 273.15;
  const l1 = Math.log(r.table[i]);
  const l2 = Math.log(r.table[i + 1]);
  const f = (1 / T - 1 / T1) / (1 / T2 - 1 / T1);
  return Math.exp(l1 + f * (l2 - l1));
}

/** Température inverse, uniquement dans la plage de pression tabulée. */
export function satTempC(refId: string, pKpaAbs: number): number {
  const r = refById(refId);
  if (!r || !Number.isFinite(pKpaAbs) || pKpaAbs <= 0) return NaN;
  const minP = r.table[0];
  const maxP = r.table[r.table.length - 1];
  const tolerance = Math.max(maxP, 1) * 1e-12;
  if (!Number.isFinite(minP) || !Number.isFinite(maxP) || pKpaAbs < minP - tolerance || pKpaAbs > maxP + tolerance) return NaN;
  if (Math.abs(pKpaAbs - minP) <= tolerance) return REF_TEMP_MIN_C;
  if (Math.abs(pKpaAbs - maxP) <= tolerance) return REF_TEMP_MAX_C;
  let lo = REF_TEMP_MIN_C;
  let hi = REF_TEMP_MAX_C;
  for (let k = 0; k < 56; k++) {
    const mid = (lo + hi) / 2;
    const p = satPressureKpaAbs(refId, mid);
    if (!Number.isFinite(p)) return NaN;
    if (p < pKpaAbs) lo = mid;
    else hi = mid;
  }
  return (lo + hi) / 2;
}

export const psigToKpaAbs = (psig: number) => Number.isFinite(psig) ? psig / PSI_PER_KPA + ATM_KPA : NaN;
export const kpaAbsToPsig = (kpa: number) => Number.isFinite(kpa) ? (kpa - ATM_KPA) * PSI_PER_KPA : NaN;
export const cToF = (c: number) => (c * 9) / 5 + 32;
export const fToC = (f: number) => ((f - 32) * 5) / 9;
