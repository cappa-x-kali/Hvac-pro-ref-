import type { Model, SystemType } from "./types";

export type Part = {
  name: string;
  /** Rôle / description courte */
  desc: string;
  /** Valeurs typiques (indicatives) */
  spec?: string;
  /** Méthode de test terrain */
  test?: string;
  /** Mots-clés (anglais) pour la recherche de la pièce */
  q: string;
};

export type PartGroup = { title: string; icon: string; parts: Part[] };

const MURAL: PartGroup[] = [
  {
    title: "Électronique",
    icon: "hardware-chip-outline",
    parts: [
      { name: "Carte principale intérieure (PCB)", desc: "Gère ventilateur, volets, sondes et communication avec l'extérieur.", spec: "Fusible typ. 3,15 A / 250 V", test: "Vérifier 230 V entre 1-2 au bornier, fusible, et la tension de communication sur 3 (fluctuante).", q: "indoor PCB main control board" },
      { name: "Carte extérieure / module onduleur (IPM)", desc: "Redresse le 230 V en bus DC (~310–380 V DC) et pilote le compresseur inverter.", spec: "Bus DC 310–380 V DC · fusible 15–25 A", test: "DANGER : condensateurs chargés. Attendre 5–10 min, mesurer < 30 V DC avant de toucher. Tester l'IPM en mode diode (U-V-W vers P et N).", q: "outdoor PCB inverter board IPM" },
      { name: "Carte d'affichage / récepteur IR", desc: "Affichage des températures/codes et réception de la télécommande.", test: "Pointer la télécommande avec une caméra de cellulaire : la LED IR doit clignoter.", q: "display board receiver" },
      { name: "Télécommande / thermostat mural", desc: "Commande sans fil ou filaire (contrôleur câblé, kit Wi-Fi).", q: "remote controller" },
    ],
  },
  {
    title: "Moteurs",
    icon: "sync-outline",
    parts: [
      { name: "Moteur ventilateur intérieur", desc: "Moteur DC sans balai (ou PG sur anciens modèles) du ventilateur tangentiel.", spec: "DC : 310 V / 15 V / signal Vsp 0–6,5 V / FG", test: "Vérifier l'alimentation 310 V DC et 15 V DC au connecteur ; la tension Vsp doit monter à la mise en marche.", q: "indoor fan motor" },
      { name: "Moteur ventilateur extérieur", desc: "Moteur DC (ou PSC sur anciens modèles) de l'hélice du condenseur.", spec: "DC 310 V ou AC 230 V + condensateur 1,5–3 µF", test: "Tourner l'hélice à la main (roulements). Moteur AC : mesurer les enroulements et le condensateur.", q: "outdoor fan motor" },
      { name: "Moteur de volet (swing)", desc: "Moteur pas-à-pas des volets horizontaux / verticaux.", spec: "12 V DC · ~200–400 Ω par phase", q: "swing motor louver stepper" },
    ],
  },
  {
    title: "Circuit frigorifique",
    icon: "snow-outline",
    parts: [
      { name: "Compresseur rotatif inverter", desc: "Compresseur DC à vitesse variable, 3 bornes U-V-W.", spec: "Résistance U-V ≈ V-W ≈ U-W (0,5–3 Ω)", test: "Les 3 enroulements doivent être égaux ; isolement vers la masse > 1 MΩ (mégohmmètre 500 V).", q: "inverter rotary compressor" },
      { name: "Détendeur électronique (EEV) + bobine", desc: "Règle le débit de réfrigérant. Bobine pas-à-pas 12 V.", spec: "≈ 40–50 Ω commun → chaque phase", test: "Mesurer la bobine ; à la mise sous tension on entend le « clic » de réinitialisation.", q: "electronic expansion valve EEV coil" },
      { name: "Vanne 4 voies + bobine", desc: "Inverse le cycle (chauffage / climatisation).", spec: "Bobine 230 V AC ≈ 1–2 kΩ", test: "230 V sur la bobine en mode chauffage (la plupart des marques). Écouter le basculement.", q: "4 way reversing valve coil" },
      { name: "Vannes de service", desc: "Vannes liquide / gaz avec port Schrader 5/16\" (R410A/R32).", q: "service valve" },
    ],
  },
  {
    title: "Sondes (thermistances)",
    icon: "thermometer-outline",
    parts: [
      { name: "Sonde ambiante intérieure", desc: "Mesure l'air de retour.", spec: "10 ou 15 kΩ à 25 °C (selon marque)", test: "Comparer à la table de résistance ci-dessous à la température mesurée.", q: "room temperature sensor thermistor" },
      { name: "Sonde serpentin intérieur", desc: "Protection antigel / anti-air-froid en chauffage.", spec: "10 ou 20 kΩ à 25 °C", q: "indoor coil sensor thermistor" },
      { name: "Sonde ambiante extérieure", desc: "Logique de dégivrage et limites de fonctionnement.", spec: "10–15 kΩ à 25 °C", q: "outdoor ambient sensor thermistor" },
      { name: "Sonde serpentin extérieur / dégivrage", desc: "Déclenche et termine le dégivrage.", spec: "10–20 kΩ à 25 °C", q: "outdoor coil defrost sensor" },
      { name: "Sonde de refoulement compresseur", desc: "Protection surchauffe du refoulement.", spec: "50 kΩ à 25 °C (typ.)", q: "discharge temperature sensor" },
    ],
  },
  {
    title: "Électrique & accessoires",
    icon: "flash-outline",
    parts: [
      { name: "Réactance (PFC)", desc: "Inductance de correction du facteur de puissance.", spec: "< 1 Ω", q: "reactor PFC inductor" },
      { name: "Résistance de bac / carter", desc: "Évite la glace dans le bac (modèles grand froid).", spec: "230 V · 40–150 W", q: "base pan heater" },
      { name: "Pompe à condensats", desc: "Si l'évacuation par gravité est impossible.", q: "condensate pump mini split" },
      { name: "Filtres", desc: "Filtres à mailles + filtres optionnels (charbon, ionisant).", q: "filter" },
    ],
  },
];

const CENTRAL: PartGroup[] = [
  {
    title: "Unité extérieure",
    icon: "cube-outline",
    parts: [
      { name: "Contacteur", desc: "Alimente compresseur et ventilateur quand Y reçoit 24 V.", spec: "Bobine 24 V AC · 30–40 A · 1 ou 2 pôles", test: "Bobine 10–20 Ω. Avec 24 V présent, chute de tension à travers les contacts < 1 V.", q: "contactor 24V" },
      { name: "Condensateur double", desc: "Démarrage/marche du compresseur (HERM) et du ventilateur (FAN).", spec: "ex. 35/5 µF · 370/440 V", test: "Mesurer µF après décharge : tolérance ±6 %. Bombé = à remplacer.", q: "dual run capacitor" },
      { name: "Compresseur scroll", desc: "Compresseur 1 ou 2 étages (bornes C-S-R).", spec: "C-S + C-R ≈ S-R", test: "Mesurer C-R, C-S, S-R ; isolement > 1 MΩ. Surchauffe interne : attendre le réarmement.", q: "scroll compressor" },
      { name: "Moteur ventilateur condenseur", desc: "Moteur PSC 1/4–1/3 HP ou ECM.", spec: "825–1100 tr/min · 208-230 V", q: "condenser fan motor" },
      { name: "Carte de dégivrage", desc: "Gère les cycles de dégivrage (30/60/90 min) et la vanne d'inversion.", test: "Ponter les broches TEST pour forcer un dégivrage.", q: "defrost control board" },
      { name: "Sonde / thermostat de dégivrage", desc: "Ferme sous ~0 °C au serpentin, ouvre à ~20 °C.", q: "defrost sensor thermostat" },
      { name: "Vanne d'inversion + bobine 24 V", desc: "Bobine O (refroidissement) ou B (chauffage) selon la marque.", spec: "Bobine 24 V AC", q: "reversing valve solenoid 24V" },
      { name: "Pressostats HP / BP", desc: "Protection haute et basse pression.", spec: "HP ouvre ~650 psig (R410A)", q: "high pressure switch low pressure switch" },
      { name: "Filtre déshydrateur bi-flow", desc: "À remplacer à chaque ouverture du circuit.", q: "bi-flow filter drier" },
      { name: "Résistance de carter", desc: "Évite la migration du réfrigérant dans l'huile au froid.", q: "crankcase heater" },
      { name: "Kit de démarrage (hard start)", desc: "Aide les compresseurs qui démarrent difficilement.", q: "hard start kit" },
    ],
  },
  {
    title: "Unité intérieure (air handler / fournaise)",
    icon: "home-outline",
    parts: [
      { name: "Moteur de soufflante", desc: "PSC, ECM à couple constant (X13) ou ECM variable.", spec: "120 V ou 240 V · 1/3–1 HP", test: "X13 : 120/240 V permanent + signal 24 V sur une prise de vitesse.", q: "blower motor ECM" },
      { name: "Transformateur 24 V", desc: "Alimente la commande 24 V (R-C).", spec: "120 ou 240 V → 24 V · 40–75 VA", test: "24–28 V AC entre R et C. Fusible 3 A de la carte.", q: "transformer 24V 40VA" },
      { name: "Carte de contrôle", desc: "Carte de la fournaise ou de l'air handler (codes DEL).", q: "control board furnace air handler" },
      { name: "Éléments chauffants + séquenceurs", desc: "Chauffage d'appoint / d'urgence (W2/E).", spec: "5, 10, 15, 20 kW · 240 V", test: "≈ 10–12 Ω par élément de 5 kW. Vérifier les limites thermiques.", q: "heat strip electric heater kit sequencer" },
      { name: "TXV / piston", desc: "Organe de détente de l'évaporateur.", q: "TXV expansion valve" },
      { name: "Allumeur / capteur de flamme (fournaise)", desc: "Allumeur à surface chaude et tige de détection de flamme.", spec: "Allumeur 40–90 Ω · flamme > 1 µA DC", q: "hot surface igniter flame sensor" },
      { name: "Pressostat d'air / limite", desc: "Sécurités du tirage et de surchauffe.", q: "pressure switch limit switch" },
      { name: "Thermostat", desc: "Thermostat thermopompe (O/B, Aux/E, 2 étages).", q: "heat pump thermostat" },
    ],
  },
];

export const partsFor = (type: SystemType): PartGroup[] => (type === "central" ? CENTRAL : MURAL);

/** Table de résistance d'une thermistance CTN (modèle bêta, indicatif). */
export const THERMISTOR_TEMPS = [-20, -10, 0, 10, 20, 25, 30, 40, 50, 60];
export const thermistorKOhm = (r25: number, tC: number, beta = 3950) => r25 * Math.exp(beta * (1 / (tC + 273.15) - 1 / 298.15));

export const partSearchUrl = (brand: string, m: Pick<Model, "indoor" | "outdoor">, q: string) =>
  `https://www.google.com/search?q=${encodeURIComponent(`${brand} ${(m.outdoor || m.indoor).replace(/\*/g, "")} ${q}`)}`;

/** Bornier d'interconnexion selon la marque (mural) */
export const terminalLabels = (brandId: string): [string, string, string] => {
  if (brandId === "mitsubishi") return ["S1", "S2", "S3"];
  if (brandId === "lg") return ["1(L)", "2(N)", "3"];
  return ["1", "2", "3"];
};

export const terminalNote = (brandId: string): string | undefined =>
  ({
    mitsubishi: "Mitsubishi : S1-S2 = 230 V vers l'intérieur, S3 = communication (≈ 12–24 V DC fluctuant). Ne jamais inverser S2/S3.",
    samsung: "Samsung (récents) : L-N alimentent l'intérieur et F1-F2 forment le bus de communication (non polarisé).",
    daikin: "Daikin : 1-2 = 230 V, 3 = signal. Respecter l'ordre 1-2-3 sans épissure.",
    fujitsu: "Fujitsu / General : 1-2 = 230 V, 3 = signal (tension de communication ≈ 0–60 V fluctuant).",
    general: "Fujitsu / General : 1-2 = 230 V, 3 = signal (tension de communication ≈ 0–60 V fluctuant).",
    lg: "LG : 1(L)-2(N) = 230 V, 3 = communication.",
  } as Record<string, string>)[brandId];
