// Unités extérieures multizones (thermopompes murales multi-têtes), 18k à 60k BTU.
// Sources : fiches techniques / submittals des fabricants (Mitsubishi, Fujitsu, LG, Daikin, Gree,
// Samsung, Carrier, Panasonic, Senville, Cooper&Hunter, Toshiba). Années approximatives.
// SEER/HSPF : valeurs max. publiées (combinaison non gainable) — vérifier la combinaison réelle (AHRI).
import type { Model, Refrigerant } from "./types";

type Row = {
  b: string; // marque
  s: string; // série
  m: string; // n° unité extérieure
  btu: number;
  z: string; // zones
  r: Refrigerant;
  y: [number, number?];
  seer?: string;
  hspf?: string;
  min?: string;
  heads?: string;
  hh?: boolean; // grand froid
};

const MITSU_HEADS = "MSZ-GL, MSZ-FS/FH, MSZ-FX/GX (NL), SEZ, SLZ, MFZ, SVZ (selon modèle)";
const MITSU_BB = "jusqu'à 8 têtes via boîtier(s) de dérivation PAC-MKA";

const ROWS: Row[] = [
  // ───────── Mitsubishi MXZ-C (R410A)
  { b: "mitsubishi", s: "MXZ-C multizone", m: "MXZ-2C20NA", btu: 20000, z: "2 zones", r: "R410A", y: [2012, 2016], seer: "jusqu'à 20", hspf: "jusqu'à 11", min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-C multizone", m: "MXZ-3C24NA", btu: 24000, z: "2 à 3 zones", r: "R410A", y: [2012, 2016], seer: "jusqu'à 21", hspf: "jusqu'à 11", min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-C multizone", m: "MXZ-3C30NA", btu: 30000, z: "2 à 3 zones", r: "R410A", y: [2012, 2016], seer: "jusqu'à 20", min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-C multizone", m: "MXZ-4C36NA", btu: 36000, z: "2 à 4 zones", r: "R410A", y: [2012, 2016], seer: "jusqu'à 20", hspf: "jusqu'à 11.3", min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-C multizone", m: "MXZ-5C42NA", btu: 42000, z: "2 à 5 zones", r: "R410A", y: [2013, 2016], seer: "jusqu'à 20", min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-C multizone", m: "MXZ-8C48NA", btu: 48000, z: MITSU_BB, r: "R410A", y: [2013, 2018], seer: "jusqu'à 18", min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-C multizone (gén. 2–4)", m: "MXZ-2C20NA2/3/4", btu: 20000, z: "2 zones", r: "R410A", y: [2017, 2024], seer: "jusqu'à 20", min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-C multizone (gén. 2–4)", m: "MXZ-3C24NA2/3/4", btu: 24000, z: "2 à 3 zones", r: "R410A", y: [2017, 2024], seer: "jusqu'à 21", min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-C multizone (gén. 2–4)", m: "MXZ-3C30NA2/3/4", btu: 30000, z: "2 à 3 zones", r: "R410A", y: [2017, 2024], min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-C multizone (gén. 2–4)", m: "MXZ-4C36NA2/3/4", btu: 36000, z: "2 à 4 zones", r: "R410A", y: [2017, 2024], seer: "jusqu'à 20", hspf: "jusqu'à 11.3", min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-C multizone (gén. 2–4)", m: "MXZ-5C42NA2/3/4", btu: 42000, z: "2 à 5 zones", r: "R410A", y: [2017, 2024], min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-C multizone (gén. 2–4)", m: "MXZ-8C48NA2", btu: 48000, z: MITSU_BB, r: "R410A", y: [2017, 2020], min: "-15 °C", heads: MITSU_HEADS },
  // Hyper-Heat H2i (R410A)
  { b: "mitsubishi", s: "MXZ-C Hyper-Heat H2i", m: "MXZ-2C20NAHZ", btu: 20000, z: "2 zones", r: "R410A", y: [2014, 2024], min: "-25 °C", heads: MITSU_HEADS, hh: true },
  { b: "mitsubishi", s: "MXZ-C Hyper-Heat H2i", m: "MXZ-3C24NAHZ", btu: 24000, z: "2 à 3 zones", r: "R410A", y: [2014, 2024], min: "-25 °C", heads: MITSU_HEADS, hh: true },
  { b: "mitsubishi", s: "MXZ-C Hyper-Heat H2i", m: "MXZ-3C30NAHZ", btu: 30000, z: "2 à 3 zones", r: "R410A", y: [2016, 2024], min: "-25 °C", heads: MITSU_HEADS, hh: true },
  // Smart Multi (R410A, boîtiers de dérivation)
  { b: "mitsubishi", s: "MXZ-SM Smart Multi", m: "MXZ-SM36NAM", btu: 36000, z: MITSU_BB, r: "R410A", y: [2019, 2024], seer: "jusqu'à 20", min: "-15 °C", heads: MITSU_HEADS + " + P-Series / CITY MULTI" },
  { b: "mitsubishi", s: "MXZ-SM Smart Multi", m: "MXZ-SM48NAM", btu: 48000, z: MITSU_BB, r: "R410A", y: [2019, 2024], min: "-15 °C", heads: MITSU_HEADS + " + P-Series / CITY MULTI" },
  { b: "mitsubishi", s: "MXZ-SM Smart Multi", m: "MXZ-SM60NAM", btu: 60000, z: MITSU_BB, r: "R410A", y: [2019, 2024], min: "-15 °C", heads: MITSU_HEADS + " + P-Series / CITY MULTI" },
  { b: "mitsubishi", s: "MXZ-SM Smart Multi Hyper-Heat", m: "MXZ-SM36NAMHZ", btu: 36000, z: MITSU_BB, r: "R410A", y: [2019, 2024], seer: "jusqu'à 20", min: "-30 °C", heads: MITSU_HEADS, hh: true },
  { b: "mitsubishi", s: "MXZ-SM Smart Multi Hyper-Heat", m: "MXZ-SM42NAMHZ", btu: 42000, z: MITSU_BB, r: "R410A", y: [2019, 2024], seer: "22", hspf: "12", min: "-30 °C", heads: MITSU_HEADS, hh: true },
  { b: "mitsubishi", s: "MXZ-SM Smart Multi Hyper-Heat", m: "MXZ-SM48NAMHZ", btu: 48000, z: MITSU_BB, r: "R410A", y: [2019, 2024], min: "-30 °C", heads: MITSU_HEADS, hh: true },
  // MXZ-D / SM-NL (R454B)
  { b: "mitsubishi", s: "MXZ-D (A2L)", m: "MXZ-2D20NL", btu: 20000, z: "2 zones", r: "R454B", y: [2025], min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-D (A2L)", m: "MXZ-3D24NL", btu: 24000, z: "2 à 3 zones", r: "R454B", y: [2025], min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-D (A2L)", m: "MXZ-4D30NL", btu: 30000, z: "2 à 4 zones", r: "R454B", y: [2025], min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-D (A2L)", m: "MXZ-5D36NL", btu: 36000, z: "2 à 5 zones", r: "R454B", y: [2025], min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-D (A2L)", m: "MXZ-5D42NL", btu: 42000, z: "2 à 5 zones", r: "R454B", y: [2025], seer: "SEER2 19.3", min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-D Hyper-Heat H2i (A2L)", m: "MXZ-2D20NLHZ", btu: 20000, z: "2 zones", r: "R454B", y: [2025], min: "-30 °C", heads: MITSU_HEADS, hh: true },
  { b: "mitsubishi", s: "MXZ-D Hyper-Heat H2i (A2L)", m: "MXZ-3D24NLHZ", btu: 24000, z: "2 à 3 zones", r: "R454B", y: [2025], min: "-30 °C", heads: MITSU_HEADS, hh: true },
  { b: "mitsubishi", s: "MXZ-D Hyper-Heat H2i (A2L)", m: "MXZ-3D30NLHZ", btu: 30000, z: "2 à 3 zones", r: "R454B", y: [2025], min: "-30 °C", heads: MITSU_HEADS, hh: true },
  { b: "mitsubishi", s: "MXZ-SM-NL Smart Multi (A2L)", m: "MXZ-SM36NL", btu: 36000, z: MITSU_BB, r: "R454B", y: [2025], min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-SM-NL Smart Multi (A2L)", m: "MXZ-SM48NL", btu: 48000, z: MITSU_BB, r: "R454B", y: [2025], min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-SM-NL Smart Multi (A2L)", m: "MXZ-SM60NL", btu: 60000, z: MITSU_BB, r: "R454B", y: [2025], min: "-15 °C", heads: MITSU_HEADS },
  { b: "mitsubishi", s: "MXZ-SM-NL Hyper-Heat (A2L)", m: "MXZ-SM36NLHZ", btu: 36000, z: MITSU_BB, r: "R454B", y: [2025], min: "-30 °C", heads: MITSU_HEADS, hh: true },
  { b: "mitsubishi", s: "MXZ-SM-NL Hyper-Heat (A2L)", m: "MXZ-SM42NLHZ", btu: 42000, z: MITSU_BB, r: "R454B", y: [2025], min: "-30 °C", heads: MITSU_HEADS, hh: true },
  { b: "mitsubishi", s: "MXZ-SM-NL Hyper-Heat (A2L)", m: "MXZ-SM48NLHZ", btu: 48000, z: MITSU_BB, r: "R454B", y: [2025], min: "-30 °C", heads: MITSU_HEADS, hh: true },

  // ───────── Fujitsu (R410A)
  { b: "fujitsu", s: "RLXFZ multizone", m: "AOU18RLXFZ", btu: 18000, z: "2 zones (14–21k connectés)", r: "R410A", y: [2014, 2024], min: "-15 °C", heads: "ASU-RLS3, ASUG-LZAS, AGU, AUU, ARU (multi)" },
  { b: "fujitsu", s: "RLXFZ multizone", m: "AOU24RLXFZ", btu: 24000, z: "2 à 3 zones (14–27k)", r: "R410A", y: [2014, 2024], min: "-15 °C", heads: "ASU-RLS3, ASUG-LZAS, AGU, AUU, ARU (multi)" },
  { b: "fujitsu", s: "RLXFZ multizone", m: "AOU36RLXFZ1", btu: 36000, z: "3 à 4 zones (27–39k)", r: "R410A", y: [2015, 2024], seer: "16–18", min: "-15 °C", heads: "ASU-RLS3, ASUG-LZAS, AGU, AUU, ARU (multi)" },
  { b: "fujitsu", s: "RLXFZ multizone", m: "AOU45RLXFZ", btu: 45000, z: "2 à 5 zones (34–54k)", r: "R410A", y: [2017, 2024], min: "-15 °C", heads: "ASU-RLS3, ASUG-LZAS, AGU, AUU, ARU (multi)" },
  { b: "fujitsu", s: "RLXFZ1 multizone (boîtiers)", m: "AOU48RLXFZ1", btu: 48000, z: "jusqu'à 8 zones via boîtiers de dérivation UTP-PU", r: "R410A", y: [2015, 2024], min: "-15 °C", heads: "Muraux, cassettes, gainables Fujitsu multi" },
  { b: "fujitsu", s: "RLXFZH Hyper-Heat multizone", m: "AOU18RLXFZH", btu: 18000, z: "2 zones (14–21k)", r: "R410A", y: [2017, 2024], min: "-26 °C", heads: "ASU-RLS3H, ASUG-LZAS, AGU, ARU (multi)", hh: true },
  { b: "fujitsu", s: "RLXFZH Hyper-Heat multizone", m: "AOU24RLXFZH", btu: 24000, z: "2 à 3 zones (14–27k)", r: "R410A", y: [2017, 2024], min: "-26 °C", heads: "ASU-RLS3H, ASUG-LZAS, AGU, ARU (multi)", hh: true },
  { b: "fujitsu", s: "RLXFZH Hyper-Heat multizone", m: "AOU36RLXFZH", btu: 36000, z: "2 à 4 zones (27–39k)", r: "R410A", y: [2017, 2024], min: "-26 °C", heads: "ASU-RLS3H, ASUG-LZAS, AGU, ARU (multi)", hh: true },

  // ───────── LG
  { b: "lg", s: "Multi F (1re gén.)", m: "LMU180HV", btu: 18000, z: "2 zones", r: "R410A", y: [2012, 2016], min: "-15 °C", heads: "LMN (Multi F), Art Cool, cassettes, gainables" },
  { b: "lg", s: "Multi F (1re gén.)", m: "LMU240HV", btu: 24000, z: "2 à 3 zones", r: "R410A", y: [2012, 2016], min: "-15 °C", heads: "LMN (Multi F), Art Cool, cassettes, gainables" },
  { b: "lg", s: "Multi F", m: "LMU18CHV", btu: 18000, z: "2 zones", r: "R410A", y: [2016, 2024], hspf: "9.7", min: "-15 °C", heads: "LMN, LAN Art Cool, LMCN cassette, LMDN gainable" },
  { b: "lg", s: "Multi F", m: "LMU24CHV", btu: 24000, z: "2 à 3 zones", r: "R410A", y: [2016, 2024], min: "-15 °C", heads: "LMN, LAN Art Cool, LMCN cassette, LMDN gainable" },
  { b: "lg", s: "Multi F", m: "LMU30CHV", btu: 30000, z: "2 à 4 zones", r: "R410A", y: [2016, 2024], min: "-15 °C", heads: "LMN, LAN Art Cool, LMCN cassette, LMDN gainable" },
  { b: "lg", s: "Multi F", m: "LMU36CHV", btu: 36000, z: "2 à 4 zones", r: "R410A", y: [2016, 2024], min: "-15 °C", heads: "LMN, LAN Art Cool, LMCN cassette, LMDN gainable" },
  { b: "lg", s: "Multi F MAX", m: "LMU480HV", btu: 48000, z: "jusqu'à 8 zones (boîtier PMBD)", r: "R410A", y: [2013, 2024], min: "-15 °C", heads: "LMN, LAN Art Cool, cassettes, gainables, consoles" },
  { b: "lg", s: "Multi F MAX", m: "LMU540HV", btu: 54000, z: "jusqu'à 8 zones (boîtier PMBD)", r: "R410A", y: [2013, 2024], min: "-15 °C", heads: "LMN, LAN Art Cool, cassettes, gainables, consoles" },
  { b: "lg", s: "Multi F MAX", m: "LMU600HV", btu: 60000, z: "jusqu'à 8 zones (boîtier PMBD)", r: "R410A", y: [2013, 2024], min: "-15 °C", heads: "LMN, LAN Art Cool, cassettes, gainables, consoles" },
  { b: "lg", s: "Multi F (R32)", m: "KUMXB181A", btu: 18000, z: "2 zones", r: "R32", y: [2025], seer: "SEER2 22.5", min: "-20 °C", heads: "Têtes LG R32 (KNMKB…, KNMAB…)" },
  { b: "lg", s: "Multi F (R32)", m: "KUMXB241A", btu: 24000, z: "2 à 3 zones", r: "R32", y: [2025], seer: "SEER2 22.5", min: "-20 °C", heads: "Têtes LG R32 (KNMKB…, KNMAB…)" },
  { b: "lg", s: "Multi F (R32)", m: "KUMXB361A", btu: 36000, z: "2 à 4 zones", r: "R32", y: [2025], seer: "SEER2 21.5", min: "-20 °C", heads: "Têtes LG R32 (KNMKB…, KNMAB…)" },
  { b: "lg", s: "Multi F MAX (R32)", m: "KUMXB481A", btu: 48000, z: "jusqu'à 8 zones (boîtier de dérivation)", r: "R32", y: [2025], min: "-20 °C", heads: "Têtes LG R32 (KNMKB…, KNMAB…)" },

  // ───────── Daikin
  { b: "daikin", s: "MXS multizone", m: "2MXS18NMVJU", btu: 18000, z: "2 zones", r: "R410A", y: [2015, 2023], seer: "18.9", hspf: "10.7", min: "-15 °C", heads: "FTXS, CTXS, FDMQ, FFQ (multi)" },
  { b: "daikin", s: "MXS multizone", m: "3MXS24RMVJU", btu: 24000, z: "2 à 3 zones", r: "R410A", y: [2015, 2023], seer: "18", hspf: "12.5", min: "-15 °C", heads: "FTXS, CTXS, FDMQ, FFQ (multi)" },
  { b: "daikin", s: "MXS multizone", m: "4MXS36RMVJU", btu: 36000, z: "2 à 4 zones", r: "R410A", y: [2015, 2023], seer: "17.7", hspf: "12.2", min: "-15 °C", heads: "FTXS, CTXS, FDMQ, FFQ (multi)" },
  { b: "daikin", s: "MXS multizone", m: "5MXS48TVJU", btu: 48000, z: "2 à 5 zones", r: "R410A", y: [2017, 2023], seer: "20.2", hspf: "11.1", min: "-15 °C", heads: "FTXS, CTXS, FDMQ, FFQ (multi)" },
  { b: "daikin", s: "Aurora MXL multizone", m: "2MXL18QMVJU", btu: 18000, z: "2 zones", r: "R410A", y: [2017, 2023], seer: "jusqu'à 21.7", hspf: "jusqu'à 12.5", min: "-25 °C", heads: "FTXS (LVJU / NVJU), CTXS, FDMQ", hh: true },
  { b: "daikin", s: "Aurora MXL multizone", m: "3MXL24RMVJU", btu: 24000, z: "2 à 3 zones", r: "R410A", y: [2017, 2023], seer: "jusqu'à 21.7", hspf: "jusqu'à 12.5", min: "-25 °C", heads: "FTXS (LVJU / NVJU), CTXS, FDMQ", hh: true },
  { b: "daikin", s: "Aurora MXL multizone", m: "4MXL36TVJU", btu: 36000, z: "2 à 4 zones", r: "R410A", y: [2017, 2023], seer: "jusqu'à 21.7", hspf: "jusqu'à 12.5", min: "-25 °C", heads: "FTXS (LVJU / NVJU), CTXS, FDMQ", hh: true },
  { b: "daikin", s: "MXS multizone (R32)", m: "2MXS18WMVJU9", btu: 18000, z: "2 zones", r: "R32", y: [2024], seer: "SEER2 jusqu'à 20.6", hspf: "HSPF2 jusqu'à 14.9", min: "-15 °C", heads: "FTXS…WVJU9, CTXS, FDMQ (R32)" },
  { b: "daikin", s: "MXS multizone (R32)", m: "3MXS24WMVJU9", btu: 24000, z: "2 à 3 zones", r: "R32", y: [2024], seer: "SEER2 18", min: "-15 °C", heads: "FTXS…WVJU9, CTXS, FDMQ (R32)" },
  { b: "daikin", s: "MXS multizone (R32)", m: "5MXS48WVJU9", btu: 48000, z: "2 à 5 zones", r: "R32", y: [2024], min: "-15 °C", heads: "FTXS…WVJU9, CTXS, FDMQ (R32)" },
  { b: "daikin", s: "Aurora MXL multizone (R32)", m: "2MXL18WMVJU9", btu: 18000, z: "2 zones", r: "R32", y: [2024], seer: "SEER2 jusqu'à 20", hspf: "HSPF2 jusqu'à 9.7", min: "-25 °C", heads: "FTXS / Aurora (R32)", hh: true },
  { b: "daikin", s: "Aurora MXL multizone (R32)", m: "3MXL24WMVJU9", btu: 24000, z: "2 à 3 zones", r: "R32", y: [2024], seer: "SEER2 jusqu'à 20", hspf: "HSPF2 jusqu'à 9.7", min: "-25 °C", heads: "FTXS / Aurora (R32)", hh: true },
  { b: "daikin", s: "Aurora MXL multizone (R32)", m: "4MXL36WVJU9", btu: 36000, z: "2 à 4 zones", r: "R32", y: [2024], seer: "SEER2 jusqu'à 20", hspf: "HSPF2 jusqu'à 9.7", min: "-25 °C", heads: "FTXS / Aurora (R32)", hh: true },
  { b: "daikin", s: "Aurora MXT multizone (R32)", m: "4MXT36AVJU9", btu: 36000, z: "2 à 4 zones", r: "R32", y: [2025], min: "-30 °C", heads: "Aurora (R32)", hh: true },
  { b: "daikin", s: "MXM multizone (R32)", m: "4MXM36AVJU9", btu: 36000, z: "2 à 4 zones", r: "R32", y: [2024], seer: "SEER2 20", hspf: "HSPF2 9.5", min: "-15 °C", heads: "Têtes MXM / FTXM (R32)" },

  // ───────── Gree
  { b: "gree", s: "Multi21+", m: "MULTI18HP230V1CO", btu: 18000, z: "2 zones", r: "R410A", y: [2017, 2023], seer: "jusqu'à 22", hspf: "jusqu'à 11.5", min: "-21 °C", heads: "Têtes Gree multi R410A (GWH…, Vireo/Livo multi)" },
  { b: "gree", s: "Multi21+", m: "MULTI24HP230V1CO", btu: 24000, z: "2 à 3 zones", r: "R410A", y: [2017, 2023], seer: "jusqu'à 22", hspf: "jusqu'à 11.5", min: "-21 °C", heads: "Têtes Gree multi R410A (GWH…, Vireo/Livo multi)" },
  { b: "gree", s: "Multi21+", m: "MULTI30HP230V1CO", btu: 30000, z: "2 à 4 zones", r: "R410A", y: [2017, 2023], seer: "jusqu'à 22", hspf: "jusqu'à 11.5", min: "-21 °C", heads: "Têtes Gree multi R410A (GWH…, Vireo/Livo multi)" },
  { b: "gree", s: "Multi21+", m: "MULTI36HP230V1CO", btu: 36000, z: "2 à 5 zones", r: "R410A", y: [2017, 2023], seer: "jusqu'à 22", hspf: "jusqu'à 11.5", min: "-21 °C", heads: "Têtes Gree multi R410A (GWH…, Vireo/Livo multi)" },
  { b: "gree", s: "Multi21+", m: "MULTI42HP230V1CO", btu: 42000, z: "2 à 5 zones", r: "R410A", y: [2017, 2023], seer: "jusqu'à 22", hspf: "jusqu'à 11.5", min: "-21 °C", heads: "Têtes Gree multi R410A (GWH…, Vireo/Livo multi)" },
  { b: "gree", s: "Multi21+", m: "MULTI48HP230V1CO", btu: 48000, z: "2 à 5 zones", r: "R410A", y: [2017, 2023], seer: "jusqu'à 22", hspf: "jusqu'à 11.5", min: "-21 °C", heads: "Têtes Gree multi R410A (GWH…, Vireo/Livo multi)" },
  { b: "gree", s: "Multi R32", m: "MUL18HP230V1R32AO", btu: 18000, z: "2 zones", r: "R32", y: [2023], seer: "SEER2 jusqu'à 21", hspf: "HSPF2 jusqu'à 10", min: "-30 °C", heads: "Têtes Gree R32 (CON, FLR, DUC, CAS, OWC, murales R32)" },
  { b: "gree", s: "Multi R32", m: "MUL24HP230V1R32AO", btu: 24000, z: "2 à 3 zones", r: "R32", y: [2023], seer: "SEER2 jusqu'à 21", hspf: "HSPF2 jusqu'à 10", min: "-30 °C", heads: "Têtes Gree R32 (CON, FLR, DUC, CAS, OWC, murales R32)" },
  { b: "gree", s: "Multi R32", m: "MUL30HP230V1R32AO", btu: 30000, z: "2 à 4 zones", r: "R32", y: [2023], seer: "SEER2 21", hspf: "HSPF2 10", min: "-30 °C", heads: "Têtes Gree R32 (CON, FLR, DUC, CAS, OWC, murales R32)" },
  { b: "gree", s: "Multi R32", m: "MUL36HP230V1R32AO", btu: 36000, z: "2 à 5 zones", r: "R32", y: [2023], seer: "SEER2 jusqu'à 21", hspf: "HSPF2 jusqu'à 10", min: "-30 °C", heads: "Têtes Gree R32 (CON, FLR, DUC, CAS, OWC, murales R32)" },
  { b: "gree", s: "Multi R32", m: "MUL42HP230V1R32AO", btu: 42000, z: "2 à 5 zones", r: "R32", y: [2023], seer: "SEER2 jusqu'à 21", hspf: "HSPF2 jusqu'à 10", min: "-30 °C", heads: "Têtes Gree R32 (CON, FLR, DUC, CAS, OWC, murales R32)" },
  { b: "gree", s: "Multi R32", m: "MUL48HP230V1R32AO", btu: 48000, z: "2 à 5 zones", r: "R32", y: [2023], seer: "SEER2 jusqu'à 21", hspf: "HSPF2 jusqu'à 10", min: "-30 °C", heads: "Têtes Gree R32 (CON, FLR, DUC, CAS, OWC, murales R32)" },

  // ───────── Samsung FJM
  { b: "samsung", s: "FJM Free Joint Multi", m: "AJ020TXJ2CH/AA", btu: 20000, z: "2 zones", r: "R410A", y: [2018, 2024], min: "-15 °C", heads: "Têtes FJM (AR…, AJ…JNA, cassettes, gainables)" },
  { b: "samsung", s: "FJM Free Joint Multi", m: "AJ024TXJ3CH/AA", btu: 24000, z: "2 à 3 zones", r: "R410A", y: [2018, 2024], min: "-15 °C", heads: "Têtes FJM (AR…, AJ…JNA, cassettes, gainables)" },
  { b: "samsung", s: "FJM Free Joint Multi", m: "AJ036TXJ4CH/AA", btu: 36000, z: "2 à 4 zones", r: "R410A", y: [2018, 2024], min: "-15 °C", heads: "Têtes FJM (AR…, AJ…JNA, cassettes, gainables)" },
  { b: "samsung", s: "FJM Free Joint Multi", m: "AJ048TXJ5CH/AA", btu: 48000, z: "2 à 5 zones", r: "R410A", y: [2018, 2024], min: "-15 °C", heads: "Têtes FJM (AR…, AJ…JNA, cassettes, gainables)" },
  { b: "samsung", s: "FJM Standard (R32)", m: "AJ020DXJ2CG/AA", btu: 20000, z: "2 zones", r: "R32", y: [2025], min: "-15 °C", heads: "Têtes FJM R32" },
  { b: "samsung", s: "FJM Standard (R32)", m: "AJ024DXJ3CG/AA", btu: 24000, z: "2 à 3 zones", r: "R32", y: [2025], min: "-15 °C", heads: "Têtes FJM R32" },
  { b: "samsung", s: "FJM Standard (R32)", m: "AJ036DXJ4CG/AA", btu: 36000, z: "2 à 4 zones", r: "R32", y: [2025], min: "-15 °C", heads: "Têtes FJM R32" },
  { b: "samsung", s: "FJM Standard (R32)", m: "AJ048DXJ5CG/AA", btu: 48000, z: "2 à 5 zones", r: "R32", y: [2025], min: "-15 °C", heads: "Têtes FJM R32" },

  // ───────── Carrier
  { b: "carrier", s: "38MGR multizone", m: "38MGRQ18B--3", btu: 18000, z: "2 zones", r: "R410A", y: [2016, 2023], seer: "22.5", hspf: "10.3", min: "-30 °C", heads: "40MAQ, 40MBC (cassette), 40MBD (gainable), 40MBF (console)" },
  { b: "carrier", s: "38MGR multizone", m: "38MGRQ24C--3", btu: 24000, z: "2 à 3 zones", r: "R410A", y: [2016, 2023], seer: "23.0", hspf: "10.3", min: "-30 °C", heads: "40MAQ, 40MBC (cassette), 40MBD (gainable), 40MBF (console)" },
  { b: "carrier", s: "38MGR multizone", m: "38MGRQ30D--3", btu: 30000, z: "2 à 4 zones", r: "R410A", y: [2016, 2023], seer: "23.8", hspf: "10.0", min: "-30 °C", heads: "40MAQ, 40MBC (cassette), 40MBD (gainable), 40MBF (console)" },
  { b: "carrier", s: "38MGR multizone", m: "38MGRQ36D--3", btu: 36000, z: "2 à 4 zones", r: "R410A", y: [2016, 2023], seer: "21.5", hspf: "10.5", min: "-30 °C", heads: "40MAQ, 40MBC (cassette), 40MBD (gainable), 40MBF (console)" },
  { b: "carrier", s: "38MGR multizone", m: "38MGRQ48E--3", btu: 48000, z: "2 à 5 zones", r: "R410A", y: [2016, 2023], seer: "22.4", hspf: "10.2", min: "-30 °C", heads: "40MAQ, 40MBC (cassette), 40MBD (gainable), 40MBF (console)" },

  // ───────── Panasonic
  { b: "panasonic", s: "Multi E (R410A)", m: "CU-2E18SBU-5", btu: 18000, z: "2 zones", r: "R410A", y: [2016, 2023], min: "-15 °C", heads: "CS-E…RKUAW, CS-MKE… (multi)" },
  { b: "panasonic", s: "Multi Z (R32)", m: "CU-2Z18ABUC", btu: 18000, z: "2 zones", r: "R32", y: [2024], seer: "SEER2 jusqu'à 22.5", min: "-26 °C", heads: "CS-MXZ…AKUA (murales), consoles, gainables R32", hh: true },
  { b: "panasonic", s: "Multi Z (R32)", m: "CU-3Z22ABUC", btu: 22000, z: "2 à 3 zones", r: "R32", y: [2024], min: "-26 °C", heads: "CS-MXZ…AKUA (murales), consoles, gainables R32", hh: true },
  { b: "panasonic", s: "Multi Z (R32)", m: "CU-5Z36BBUC", btu: 36000, z: "2 à 5 zones", r: "R32", y: [2024], min: "-21 °C", heads: "CS-MXZ…AKUA (murales), consoles, gainables R32" },

  // ───────── Toshiba
  { b: "toshiba", s: "RAS Multi (U2AVG)", m: "RAS-2M18U2AVG-UL", btu: 18000, z: "2 zones", r: "R410A", y: [2016, 2023], min: "-15 °C", heads: "RAS-…N3KV2, cassettes, gainables Toshiba multi" },
  { b: "toshiba", s: "RAS Multi (U2AVG)", m: "RAS-3M26U2AVG-UL", btu: 26000, z: "2 à 3 zones", r: "R410A", y: [2016, 2023], min: "-15 °C", heads: "RAS-…N3KV2, cassettes, gainables Toshiba multi" },
  { b: "toshiba", s: "RAS Multi (U2AVG)", m: "RAS-4M27U2AVG-UL", btu: 27000, z: "2 à 4 zones", r: "R410A", y: [2016, 2023], min: "-15 °C", heads: "RAS-…N3KV2, cassettes, gainables Toshiba multi" },
  { b: "toshiba", s: "RAS Multi (U2AVG)", m: "RAS-5M34U2AVG-UL", btu: 34000, z: "2 à 5 zones", r: "R410A", y: [2016, 2023], min: "-15 °C", heads: "RAS-…N3KV2, cassettes, gainables Toshiba multi" },

  // ───────── Senville (Midea)
  { b: "senville", s: "SENA multizone", m: "SENA/18HF/MOZ", btu: 18000, z: "2 zones", r: "R410A", y: [2019, 2024], seer: "22.5", hspf: "10.3", min: "-30 °C", heads: "SENA/…HF/IZ (murales multi), cassettes, gainables" },
  { b: "senville", s: "SENA multizone", m: "SENA/30HF/MOZ", btu: 28000, z: "2 à 4 zones", r: "R410A", y: [2019, 2024], seer: "23", hspf: "10.3", min: "-30 °C", heads: "SENA/…HF/IZ (murales multi), cassettes, gainables" },
  { b: "senville", s: "SENA multizone", m: "SENA/36HF/MOZ", btu: 36000, z: "2 à 5 zones", r: "R410A", y: [2019, 2024], seer: "22.5", hspf: "10.2", min: "-30 °C", heads: "SENA/…HF/IZ (murales multi), cassettes, gainables" },
  { b: "senville", s: "SENA multizone", m: "SENA/48HF/MOZ", btu: 48000, z: "2 à 5 zones", r: "R410A", y: [2019, 2024], seer: "22.4", hspf: "10.2", min: "-30 °C", heads: "SENA/…HF/IZ (murales multi), cassettes, gainables" },
  { b: "senville", s: "AURA multizone", m: "SENA-18HF/MOA", btu: 18000, z: "2 zones", r: "R410A", y: [2022], seer: "SEER2 jusqu'à 25", min: "-30 °C", heads: "Têtes AURA multi", hh: true },
  { b: "senville", s: "AURA multizone", m: "SENA-36HF/MOA", btu: 36000, z: "2 à 5 zones", r: "R410A", y: [2022], min: "-30 °C", heads: "Têtes AURA multi", hh: true },

  // ───────── Cooper&Hunter
  { b: "cooperhunter", s: "Multi Zone", m: "CH-18MSPH-230VO", btu: 18000, z: "2 zones", r: "R410A", y: [2019], seer: "jusqu'à 23", min: "-25 °C", heads: "Olivia / Sophia multi, cassettes, gainables C&H" },
  { b: "cooperhunter", s: "Multi Zone", m: "CH-28MSPH-230VO", btu: 28000, z: "2 à 4 zones", r: "R410A", y: [2019], seer: "jusqu'à 23", min: "-25 °C", heads: "Olivia / Sophia multi, cassettes, gainables C&H" },
  { b: "cooperhunter", s: "Multi Zone", m: "CH-36MSPH-230VO", btu: 36000, z: "2 à 5 zones", r: "R410A", y: [2019], seer: "jusqu'à 23", min: "-25 °C", heads: "Olivia / Sophia multi, cassettes, gainables C&H" },
  { b: "cooperhunter", s: "Multi Zone", m: "CH-48MSPH-230VO", btu: 48000, z: "2 à 5 zones", r: "R410A", y: [2019], seer: "jusqu'à 23", min: "-25 °C", heads: "Olivia / Sophia multi, cassettes, gainables C&H" },
];

export const MULTIZONE: Model[] = ROWS.map((r) => ({
  id: `${r.b}:${r.m}`,
  brandId: r.b,
  type: "mural",
  series: r.s,
  indoor: r.m,
  btu: r.btu,
  refrigerant: r.r,
  yearFrom: r.y[0],
  yearTo: r.y[1],
  seer: r.seer,
  hspf: r.hspf,
  voltage: "208-230 V / 1 ph",
  minHeat: r.min,
  kind: r.hh ? "Thermopompe multizone grand froid" : "Thermopompe multizone",
  zones: r.z,
  heads: r.heads,
  approx: true,
}));
