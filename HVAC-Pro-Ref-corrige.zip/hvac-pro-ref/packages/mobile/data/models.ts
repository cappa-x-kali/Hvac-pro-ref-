import type { Model, Refrigerant, SystemType } from "./types";
import { QC_ROWS } from "./catalog-qc";
import { MULTIZONE } from "./multizone";

type SeriesDef = {
  brandId: string;
  type: SystemType;
  series: string;
  indoor: string; // {c} = code de capacité
  outdoor?: string;
  caps: string[];
  refrigerant: Refrigerant;
  yearFrom: number;
  yearTo?: number;
  seer?: string;
  hspf?: string;
  voltage?: string;
  minHeat?: string;
  kind?: string;
};

const W = "mural" as const;
const C = "central" as const;
const MURAL = ["09", "12", "15", "18", "24"];
const MURAL4 = ["09", "12", "18", "24"];
const CENTRAL = ["18", "24", "30", "36", "42", "48", "60"];

const SERIES: SeriesDef[] = [
  // ───────── Mitsubishi
  { brandId: "mitsubishi", type: W, series: "MS-A (R22)", indoor: "MS-A{c}WA", outdoor: "MU-A{c}WA", caps: ["09", "12", "15", "17"], refrigerant: "R22", yearFrom: 2000, yearTo: 2009, seer: "13–16", kind: "Climatiseur seul" },
  { brandId: "mitsubishi", type: W, series: "MSZ-GE", indoor: "MSZ-GE{c}NA", outdoor: "MUZ-GE{c}NA", caps: MURAL, refrigerant: "R410A", yearFrom: 2010, yearTo: 2016, seer: "20–26", hspf: "10", minHeat: "-15 °C", kind: "Thermopompe" },
  { brandId: "mitsubishi", type: W, series: "MSZ-FH Hyper-Heat", indoor: "MSZ-FH{c}NA", outdoor: "MUZ-FH{c}NAH", caps: ["09", "12", "15", "18"], refrigerant: "R410A", yearFrom: 2013, yearTo: 2018, seer: "20–30.5", hspf: "10–13.5", minHeat: "-25 °C", kind: "Thermopompe grand froid" },
  { brandId: "mitsubishi", type: W, series: "MSZ-FS Hyper-Heat", indoor: "MSZ-FS{c}NA", outdoor: "MUZ-FS{c}NAH", caps: ["09", "12", "15", "18"], refrigerant: "R410A", yearFrom: 2017, yearTo: 2024, seer: "21–33.1", hspf: "10–14", minHeat: "-25 °C", kind: "Thermopompe grand froid" },
  { brandId: "mitsubishi", type: W, series: "MSZ-GL", indoor: "MSZ-GL{c}NA", outdoor: "MUZ-GL{c}NA", caps: MURAL, refrigerant: "R410A", yearFrom: 2016, yearTo: 2024, seer: "20.5–24.6", hspf: "10–12", minHeat: "-15 °C", kind: "Thermopompe" },
  { brandId: "mitsubishi", type: W, series: "MSZ-GX (A2L)", indoor: "MSZ-GX{c}NL", outdoor: "MUZ-GX{c}NL", caps: MURAL, refrigerant: "R454B", yearFrom: 2025, seer: "SEER2 jusqu'à 30", minHeat: "-20 °C", kind: "Thermopompe" },
  { brandId: "mitsubishi", type: W, series: "MSZ-FX H2i (A2L)", indoor: "MSZ-FX{c}NL", outdoor: "MUZ-FX{c}NLHZ", caps: ["09", "12", "15", "18"], refrigerant: "R454B", yearFrom: 2025, minHeat: "-30 °C", kind: "Thermopompe grand froid" },
  { brandId: "mitsubishi", type: W, series: "MSZ-HX (A2L)", indoor: "MSZ-HX{c}NL", outdoor: "MUZ-HX{c}NL", caps: MURAL, refrigerant: "R454B", yearFrom: 2025, kind: "Thermopompe" },
  // ───────── Daikin
  { brandId: "daikin", type: W, series: "FTXS LV", indoor: "FTXS{c}LVJU", outdoor: "RXS{c}LVJU", caps: MURAL, refrigerant: "R410A", yearFrom: 2009, yearTo: 2019, seer: "18–26", minHeat: "-15 °C", kind: "Thermopompe" },
  { brandId: "daikin", type: W, series: "19 Series FTX", indoor: "FTX{c}NMVJU", outdoor: "RX{c}NMVJU", caps: MURAL4, refrigerant: "R410A", yearFrom: 2016, yearTo: 2023, seer: "17–19", kind: "Thermopompe" },
  { brandId: "daikin", type: W, series: "Emura FTXG", indoor: "FTXG{c}HVJU", outdoor: "RXG{c}HVJU", caps: ["09", "12", "15"], refrigerant: "R410A", yearFrom: 2013, yearTo: 2019, seer: "20–24.5", kind: "Thermopompe design" },
  { brandId: "daikin", type: W, series: "Entra (R32)", indoor: "FTXC{c}AXVJU", outdoor: "RXC{c}AXVJU", caps: MURAL4, refrigerant: "R32", yearFrom: 2022, seer: "SEER2 18–20", kind: "Thermopompe" },
  { brandId: "daikin", type: W, series: "Aurora (R32)", indoor: "FTXV{c}AVJU9", outdoor: "RXT{c}AVJU9", caps: ["09", "12", "15", "18", "24"], refrigerant: "R32", yearFrom: 2023, seer: "SEER2 19.5–21", minHeat: "-30 °C", kind: "Thermopompe grand froid" },
  // ───────── Fujitsu
  { brandId: "fujitsu", type: W, series: "RLS2 Halcyon", indoor: "ASU{c}RLS2", outdoor: "AOU{c}RLS2", caps: ["9", "12", "15"], refrigerant: "R410A", yearFrom: 2010, yearTo: 2013, seer: "23–26", kind: "Thermopompe" },
  { brandId: "fujitsu", type: W, series: "RLS3H XLTH", indoor: "ASU{c}RLS3H", outdoor: "AOU{c}RLS3H", caps: ["9", "12", "15"], refrigerant: "R410A", yearFrom: 2014, yearTo: 2020, seer: "25–33", hspf: "12–14.2", minHeat: "-26 °C", kind: "Thermopompe grand froid" },
  { brandId: "fujitsu", type: W, series: "RLF1 Halcyon", indoor: "ASU{c}RLF1", outdoor: "AOU{c}RLF1", caps: ["9", "12", "18", "24"], refrigerant: "R410A", yearFrom: 2014, yearTo: 2021, seer: "20–25", minHeat: "-15 °C", kind: "Thermopompe" },
  { brandId: "fujitsu", type: W, series: "LZAS1 XLTH", indoor: "ASUG{c}LZAS1", outdoor: "AOUG{c}LZAH1", caps: ["09", "12", "15"], refrigerant: "R410A", yearFrom: 2019, yearTo: 2024, seer: "25–33", minHeat: "-26 °C", kind: "Thermopompe grand froid" },
  { brandId: "fujitsu", type: W, series: "LPAS1 Entry", indoor: "ASUH{c}LPAS", outdoor: "AOUH{c}LPAS1", caps: ["09", "12", "18", "24"], refrigerant: "R410A", yearFrom: 2020, seer: "SEER2 20", kind: "Thermopompe" },
  { brandId: "fujitsu", type: W, series: "Airstage KPAS1 (R32)", indoor: "ASUH{c}KPAS1", outdoor: "AOUH{c}KPAS1", caps: ["09", "12", "18", "24"], refrigerant: "R32", yearFrom: 2024, seer: "SEER2 jusqu'à 26", hspf: "HSPF2 10.8", kind: "Thermopompe" },
  // ───────── LG
  { brandId: "lg", type: W, series: "Mega Inverter", indoor: "LSN{c}0HSV5", outdoor: "LSU{c}0HSV5", caps: MURAL4, refrigerant: "R410A", yearFrom: 2016, yearTo: 2023, seer: "20–22", minHeat: "-15 °C", kind: "Thermopompe" },
  { brandId: "lg", type: W, series: "Value Line 115V", indoor: "LSN{c}0HXV", outdoor: "LSU{c}0HXV", caps: ["09", "12"], refrigerant: "R410A", yearFrom: 2018, yearTo: 2023, seer: "17", voltage: "115 V", kind: "Thermopompe" },
  { brandId: "lg", type: W, series: "Art Cool Premier", indoor: "LAN{c}0HSV5", outdoor: "LAU{c}0HSV5", caps: MURAL4, refrigerant: "R410A", yearFrom: 2016, yearTo: 2023, seer: "20–22", kind: "Thermopompe design" },
  // ───────── Samsung
  { brandId: "samsung", type: W, series: "WindFree 2.0", indoor: "AR{c}TSFABWKNCV", outdoor: "AR{c}TSFABWKXCV", caps: MURAL4, refrigerant: "R410A", yearFrom: 2020, seer: "20–25", minHeat: "-25 °C", kind: "Thermopompe" },
  // ───────── Gree
  { brandId: "gree", type: W, series: "Livo", indoor: "LIV{c}HP230V1AH", outdoor: "LIV{c}HP230V1AO", caps: MURAL4, refrigerant: "R410A", yearFrom: 2017, yearTo: 2023, seer: "16–22", minHeat: "-15 °C", kind: "Thermopompe" },
  { brandId: "gree", type: W, series: "Vireo", indoor: "VIR{c}HP230V1AH", outdoor: "VIR{c}HP230V1AO", caps: MURAL4, refrigerant: "R410A", yearFrom: 2017, yearTo: 2023, seer: "18–21", minHeat: "-22 °C", kind: "Thermopompe" },
  { brandId: "gree", type: W, series: "Sapphire", indoor: "SAP{c}HP230V1AH", outdoor: "SAP{c}HP230V1AO", caps: MURAL4, refrigerant: "R410A", yearFrom: 2019, yearTo: 2024, seer: "jusqu'à 38", hspf: "jusqu'à 15", minHeat: "-30 °C", kind: "Thermopompe grand froid" },
  { brandId: "gree", type: W, series: "Sapphire R32", indoor: "SAP{c}HP230V1R32AH", outdoor: "SAP{c}HP230V1R32AO", caps: MURAL4, refrigerant: "R32", yearFrom: 2024, seer: "SEER2 jusqu'à 27.5", minHeat: "-30 °C", kind: "Thermopompe grand froid" },
  { brandId: "gree", type: W, series: "Livo R32", indoor: "LIV{c}HP230V1R32AH", outdoor: "LIV{c}HP230V1R32AO", caps: ["05", "07", "09", "12", "18", "24", "30", "36"], refrigerant: "R32", yearFrom: 2023, seer: "SEER2 jusqu'à 22", minHeat: "-15 °C", kind: "Thermopompe" },
  { brandId: "gree", type: W, series: "Livo R32 (115 V)", indoor: "LIV{c}HP115V1R32AH", outdoor: "LIV{c}HP115V1R32AO", caps: ["09", "12"], refrigerant: "R32", yearFrom: 2023, voltage: "115 V / 1 ph", minHeat: "-15 °C", kind: "Thermopompe" },
  { brandId: "gree", type: W, series: "Livo Gen3", indoor: "LIVV{c}HP230V1AH", outdoor: "LIVV{c}HP230V1AO", caps: ["09", "12", "18", "24", "30", "36"], refrigerant: "R410A", yearFrom: 2020, yearTo: 2023, seer: "16–22", minHeat: "-15 °C", kind: "Thermopompe" },
  { brandId: "gree", type: W, series: "Livo Gen3 (115 V)", indoor: "LIVV{c}HP115V1AH", outdoor: "LIVV{c}HP115V1AO", caps: ["09", "12"], refrigerant: "R410A", yearFrom: 2020, yearTo: 2023, voltage: "115 V / 1 ph", kind: "Thermopompe" },
  { brandId: "gree", type: W, series: "Livo+", indoor: "LIVS{c}HP230V1BH", outdoor: "LIVS{c}HP230V1BO", caps: ["09", "12", "18", "24"], refrigerant: "R410A", yearFrom: 2021, yearTo: 2023, minHeat: "-22 °C", kind: "Thermopompe" },
  { brandId: "gree", type: W, series: "Vireo R32", indoor: "VIR{c}HP230V1R32AH", outdoor: "VIR{c}HP230V1R32AO", caps: MURAL4, refrigerant: "R32", yearFrom: 2023, minHeat: "-25 °C", kind: "Thermopompe" },
  { brandId: "gree", type: W, series: "Vireo R32 (115 V)", indoor: "VIR{c}HP115V1R32AH", outdoor: "VIR{c}HP115V1R32AO", caps: ["09", "12"], refrigerant: "R32", yearFrom: 2023, voltage: "115 V / 1 ph", kind: "Thermopompe" },
  { brandId: "gree", type: W, series: "Vireo+ Ultra", indoor: "VIRU{c}HP230V1AH", outdoor: "VIRU{c}HP230V1AO", caps: ["30", "36"], refrigerant: "R410A", yearFrom: 2021, yearTo: 2023, minHeat: "-25 °C", kind: "Thermopompe" },
  { brandId: "gree", type: W, series: "Envo R32", indoor: "ENV{c}HP230V1R32AH", outdoor: "ENV{c}HP230V1R32AO", caps: MURAL4, refrigerant: "R32", yearFrom: 2023, kind: "Thermopompe" },
  { brandId: "gree", type: W, series: "Crown", indoor: "CROWN{c}HP230V1BH", outdoor: "CROWN{c}HP230V1BO", caps: MURAL4, refrigerant: "R410A", yearFrom: 2018, yearTo: 2022, seer: "jusqu'à 30", minHeat: "-30 °C", kind: "Thermopompe grand froid" },
  { brandId: "gree", type: W, series: "Rio (115 V)", indoor: "RIO{c}HP115V1AH", outdoor: "RIO{c}HP115V1AO", caps: ["09", "12"], refrigerant: "R410A", yearFrom: 2014, yearTo: 2019, voltage: "115 V / 1 ph", kind: "Thermopompe" },
  { brandId: "gree", type: W, series: "Multi R32 — Console", indoor: "CON{c}HP230V1R32AH", caps: ["09", "12", "18"], refrigerant: "R32", yearFrom: 2023, kind: "Tête multizone (console)" },
  { brandId: "gree", type: W, series: "Multi R32 — Plafonnier/plancher", indoor: "FLR{c}HP230V1R32AH", caps: ["09", "12", "18", "24", "30", "36"], refrigerant: "R32", yearFrom: 2023, kind: "Tête multizone (plancher/plafond)" },
  { brandId: "gree", type: W, series: "Multi R32 — Gainable", indoor: "DUC{c}HP230V1R32AH", caps: ["09", "12", "18", "24", "30", "36"], refrigerant: "R32", yearFrom: 2023, kind: "Tête multizone (gainable)" },
  { brandId: "gree", type: W, series: "Multi R32 — Cassette 4 voies", indoor: "CAS{c}HP230V1R32AH", caps: ["09", "12", "18", "24", "30", "36"], refrigerant: "R32", yearFrom: 2023, kind: "Tête multizone (cassette)" },
  { brandId: "gree", type: W, series: "Multi R32 — Cassette 1 voie", indoor: "OWC{c}HP230V1R32AH", caps: ["09", "12", "18", "20"], refrigerant: "R32", yearFrom: 2023, kind: "Tête multizone (cassette)" },
  // ───────── Midea / Senville
  { brandId: "midea", type: W, series: "Premier / Oasis", indoor: "MSA**U-{c}HRFN1", outdoor: "MOX***-{c}HFN1", caps: MURAL4, refrigerant: "R410A", yearFrom: 2016, yearTo: 2023, seer: "17–20", kind: "Thermopompe" },
  { brandId: "midea", type: W, series: "EVOX / All Easy Pro (R32)", indoor: "MSA**U-{c}HRFN8", outdoor: "MOX***-{c}HFN8", caps: MURAL4, refrigerant: "R32", yearFrom: 2023, kind: "Thermopompe" },
  { brandId: "senville", type: W, series: "LETO", indoor: "SENL-{c}CD-ILL", outdoor: "SENL-{c}CD-OL", caps: MURAL4, refrigerant: "R410A", yearFrom: 2018, seer: "17–21.5", minHeat: "-15 °C", kind: "Thermopompe" },
  { brandId: "senville", type: W, series: "AURA", indoor: "SENA-{c}HF/IQ", outdoor: "SENA-{c}HF/OQ", caps: ["09", "12", "18", "24"], refrigerant: "R410A", yearFrom: 2020, seer: "jusqu'à 28", minHeat: "-30 °C", kind: "Thermopompe grand froid" },
  // ───────── Carrier / Bryant / Toshiba
  { brandId: "carrier", type: W, series: "Performance 40MAQ", indoor: "40MAQB{c}B--3", outdoor: "38MAQB{c}R--3", caps: MURAL4, refrigerant: "R410A", yearFrom: 2016, yearTo: 2023, seer: "17–22", minHeat: "-15 °C", kind: "Thermopompe" },
  { brandId: "bryant", type: W, series: "Preferred 619PEQ", indoor: "619PEQ{c}***", outdoor: "538PEQ{c}***", caps: MURAL4, refrigerant: "R410A", yearFrom: 2016, yearTo: 2023, seer: "17–22", kind: "Thermopompe" },
  { brandId: "toshiba", type: W, series: "RAS-LKV", indoor: "RAS-{c}LKV-UL", outdoor: "RAS-{c}LAV-UL", caps: ["09", "12", "15", "18"], refrigerant: "R410A", yearFrom: 2008, yearTo: 2015, seer: "16–21", kind: "Thermopompe" },
  { brandId: "toshiba", type: W, series: "RAS-EKV", indoor: "RAS-{c}EKV-UL", outdoor: "RAS-{c}EAV-UL", caps: MURAL, refrigerant: "R410A", yearFrom: 2016, seer: "jusqu'à 23", kind: "Thermopompe" },
  // ───────── Panasonic
  { brandId: "panasonic", type: W, series: "XE Whispercool", indoor: "CS-XE{c}PKUA", outdoor: "CU-XE{c}PKUA", caps: ["9", "12"], refrigerant: "R410A", yearFrom: 2012, yearTo: 2017, seer: "22–26", kind: "Thermopompe" },
  { brandId: "panasonic", type: W, series: "ClimaPure XE", indoor: "CS-XE{c}WKUAW", outdoor: "CU-XE{c}WKUA", caps: ["9", "12", "15", "18", "24"], refrigerant: "R410A", yearFrom: 2018, seer: "jusqu'à 30", minHeat: "-26 °C", kind: "Thermopompe grand froid" },
  // ───────── Bosch / C&H / Hitachi
  { brandId: "bosch", type: W, series: "Climate 5000", indoor: "BMS500-AAS0{c}-1AWXW", outdoor: "BMS500-AAU0{c}-1CSXXA", caps: MURAL4, refrigerant: "R410A", yearFrom: 2018, seer: "17–21", kind: "Thermopompe" },
  { brandId: "cooperhunter", type: W, series: "Sophia", indoor: "CH-S{c}FTXAM2S-W", outdoor: "CH-S{c}FTXAM2S-O", caps: MURAL4, refrigerant: "R410A", yearFrom: 2019, seer: "jusqu'à 23", minHeat: "-30 °C", kind: "Thermopompe" },
  { brandId: "hitachi", type: W, series: "airHome (mural)", indoor: "RAK-{c}***", outdoor: "RAC-{c}***", caps: MURAL4, refrigerant: "R410A", yearFrom: 2015, kind: "Thermopompe" },

  // ═════════ CENTRAUX
  { brandId: "carrier", type: C, series: "38TKB (R22)", indoor: "38TKB0{c}", caps: CENTRAL, refrigerant: "R22", yearFrom: 1995, yearTo: 2009, seer: "10–13", kind: "Climatiseur central" },
  { brandId: "carrier", type: C, series: "Comfort 24ACC6", indoor: "24ACC6{c}A***", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2017, yearTo: 2024, seer: "16", kind: "Climatiseur central" },
  { brandId: "carrier", type: C, series: "Performance 25HCC5", indoor: "25HCC5{c}A***", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2013, yearTo: 2021, seer: "15–16", hspf: "9", kind: "Thermopompe centrale" },
  { brandId: "carrier", type: C, series: "Infinity 25VNA0 Greenspeed", indoor: "25VNA0{c}A***", caps: ["24", "36", "48", "60"], refrigerant: "R410A", yearFrom: 2013, yearTo: 2024, seer: "jusqu'à 20.5", hspf: "13", kind: "Thermopompe centrale variable" },
  { brandId: "bryant", type: C, series: "Legacy 113ANA", indoor: "113ANA0{c}***", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2014, yearTo: 2021, seer: "13–14", kind: "Climatiseur central" },
  { brandId: "bryant", type: C, series: "Evolution 288BNV", indoor: "288BNV0{c}***", caps: ["24", "36", "48", "60"], refrigerant: "R410A", yearFrom: 2014, yearTo: 2024, seer: "jusqu'à 19", kind: "Thermopompe centrale variable" },
  { brandId: "bryant", type: C, series: "598B (R22)", indoor: "598B0{c}***", caps: CENTRAL, refrigerant: "R22", yearFrom: 1998, yearTo: 2009, seer: "10–13", kind: "Climatiseur central" },
  { brandId: "lennox", type: C, series: "10ACB (R22)", indoor: "10ACB{c}", caps: CENTRAL, refrigerant: "R22", yearFrom: 1996, yearTo: 2009, seer: "10–12", kind: "Climatiseur central" },
  { brandId: "lennox", type: C, series: "13ACX", indoor: "13ACX-0{c}-230", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2007, yearTo: 2016, seer: "13", kind: "Climatiseur central" },
  { brandId: "lennox", type: C, series: "XC21", indoor: "XC21-0{c}-230", caps: ["24", "36", "48", "60"], refrigerant: "R410A", yearFrom: 2008, yearTo: 2019, seer: "jusqu'à 21", kind: "Climatiseur central 2 étages" },
  { brandId: "lennox", type: C, series: "XP25", indoor: "XP25-0{c}-230", caps: ["24", "36", "48", "60"], refrigerant: "R410A", yearFrom: 2015, seer: "jusqu'à 23.5", hspf: "10.2", kind: "Thermopompe centrale variable" },
  { brandId: "trane", type: C, series: "XB13 (R22)", indoor: "2TTB30{c}", caps: CENTRAL, refrigerant: "R22", yearFrom: 2004, yearTo: 2009, seer: "13", kind: "Climatiseur central" },
  { brandId: "trane", type: C, series: "XR13", indoor: "4TTR30{c}", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2008, yearTo: 2016, seer: "13", kind: "Climatiseur central" },
  { brandId: "trane", type: C, series: "XL16i", indoor: "4TTX60{c}", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2010, yearTo: 2019, seer: "16–17", kind: "Climatiseur central 2 étages" },
  { brandId: "trane", type: C, series: "XV20i", indoor: "4TWV00{c}", caps: ["24", "36", "48", "60"], refrigerant: "R410A", yearFrom: 2014, seer: "jusqu'à 20", hspf: "10", kind: "Thermopompe centrale variable" },
  { brandId: "americanstandard", type: C, series: "Silver 14", indoor: "4A7A40{c}", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2013, yearTo: 2022, seer: "14", kind: "Climatiseur central" },
  { brandId: "americanstandard", type: C, series: "Silver 14 HP", indoor: "4A6H40{c}", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2013, yearTo: 2022, seer: "14", hspf: "8.2", kind: "Thermopompe centrale" },
  { brandId: "goodman", type: C, series: "CKL (R22)", indoor: "CKL{c}-1", caps: CENTRAL, refrigerant: "R22", yearFrom: 1995, yearTo: 2006, seer: "10", kind: "Climatiseur central" },
  { brandId: "goodman", type: C, series: "GSX13", indoor: "GSX130{c}1", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2010, yearTo: 2018, seer: "13", kind: "Climatiseur central" },
  { brandId: "goodman", type: C, series: "GSZ14", indoor: "GSZ140{c}1", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2012, yearTo: 2022, seer: "14", hspf: "8.2", kind: "Thermopompe centrale" },
  { brandId: "amana", type: C, series: "ASX14", indoor: "ASX140{c}1", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2012, yearTo: 2022, seer: "14", kind: "Climatiseur central" },
  { brandId: "amana", type: C, series: "ASZ16", indoor: "ASZ160{c}1", caps: ["24", "36", "48", "60"], refrigerant: "R410A", yearFrom: 2012, yearTo: 2022, seer: "16", hspf: "9", kind: "Thermopompe centrale" },
  { brandId: "daikin", type: C, series: "DX16SA", indoor: "DX16SA0{c}1", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2014, yearTo: 2022, seer: "16", kind: "Climatiseur central" },
  { brandId: "daikin", type: C, series: "DZ16SA", indoor: "DZ16SA0{c}1", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2014, yearTo: 2022, seer: "16", hspf: "9", kind: "Thermopompe centrale" },
  { brandId: "rheem", type: C, series: "RAKA (R22)", indoor: "RAKA-0{c}JAZ", caps: CENTRAL, refrigerant: "R22", yearFrom: 1998, yearTo: 2009, seer: "10–13", kind: "Climatiseur central" },
  { brandId: "rheem", type: C, series: "RA13 Classic", indoor: "RA13{c}AJ1NA", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2010, yearTo: 2018, seer: "13", kind: "Climatiseur central" },
  { brandId: "rheem", type: C, series: "RP14 Classic HP", indoor: "RP14{c}AJ1NA", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2010, yearTo: 2020, seer: "14", hspf: "8.2", kind: "Thermopompe centrale" },
  { brandId: "ruud", type: C, series: "UA13 Achiever", indoor: "UA13{c}AJ1NA", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2010, yearTo: 2018, seer: "13", kind: "Climatiseur central" },
  { brandId: "ruud", type: C, series: "UP14 Achiever HP", indoor: "UP14{c}AJ1NA", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2010, yearTo: 2020, seer: "14", kind: "Thermopompe centrale" },
  { brandId: "york", type: C, series: "LX TCGD", indoor: "TCGD{c}S41S*", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2012, yearTo: 2020, seer: "13", kind: "Climatiseur central" },
  { brandId: "york", type: C, series: "LX YCE", indoor: "YCE{c}B21S", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2010, yearTo: 2018, seer: "13–14", kind: "Climatiseur central" },
  { brandId: "keeprite", type: C, series: "N4A3 (13 SEER)", indoor: "N4A3{c}A**", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2010, yearTo: 2020, seer: "13", kind: "Climatiseur central" },
  { brandId: "keeprite", type: C, series: "N4H4 HP", indoor: "N4H4{c}A**", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2010, yearTo: 2020, seer: "14", kind: "Thermopompe centrale" },
  { brandId: "tempstar", type: C, series: "N4A3 (13 SEER)", indoor: "N4A3{c}A**", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2010, yearTo: 2020, seer: "13", kind: "Climatiseur central" },
  { brandId: "tempstar", type: C, series: "N4H4 HP", indoor: "N4H4{c}A**", caps: CENTRAL, refrigerant: "R410A", yearFrom: 2010, yearTo: 2020, seer: "14", kind: "Thermopompe centrale" },
  { brandId: "mitsubishi", type: C, series: "Zuba-Central (P-Series)", indoor: "PVA-A{c}AA7", outdoor: "PUZ-HA{c}NHA5", caps: ["24", "30", "36", "42"], refrigerant: "R410A", yearFrom: 2016, minHeat: "-30 °C", kind: "Thermopompe centrale grand froid" },
  { brandId: "gree", type: C, series: "Flexx Eco R32", indoor: "FXE{c}HP230V1R32AH", outdoor: "FXE{c}HP230V1R32AO", caps: ["24", "30", "36", "48", "60"], refrigerant: "R32", yearFrom: 2023, kind: "Thermopompe centrale inverter" },
  { brandId: "gree", type: C, series: "Flexx Ultra R32", indoor: "FXU{c}HP230V1R32AH", outdoor: "FXU{c}HP230V1R32AO", caps: ["12", "18", "24", "36", "48", "60"], refrigerant: "R32", yearFrom: 2023, minHeat: "-30 °C", kind: "Thermopompe centrale grand froid" },
  { brandId: "gree", type: C, series: "Multi R32 — Unité extérieure", indoor: "MUL{c}HP230V1R32AO", caps: ["18", "24", "30", "36", "42", "48"], refrigerant: "R32", yearFrom: 2023, kind: "Unité extérieure multizone" },
  { brandId: "gree", type: C, series: "Flexx", indoor: "FLEXX{c}HP230V1AH", outdoor: "FLEXX{c}HP230V1AO", caps: ["24", "36", "48", "60"], refrigerant: "R410A", yearFrom: 2020, seer: "jusqu'à 20", kind: "Thermopompe centrale inverter" },
  { brandId: "bosch", type: C, series: "IDS 2.0", indoor: "BOVA-{c}HDN1-M20G", caps: ["24", "36", "48", "60"], refrigerant: "R410A", yearFrom: 2019, seer: "jusqu'à 20", kind: "Thermopompe centrale inverter" },
];

function expand(): Model[] {
  const out: Model[] = [];
  for (const s of SERIES) {
    for (const c of s.caps) {
      const btu = parseInt(c, 10) * 1000;
      const indoor = s.indoor.replace("{c}", c);
      out.push({
        id: `${s.brandId}:${indoor}`,
        brandId: s.brandId,
        type: s.type,
        series: s.series,
        indoor,
        outdoor: s.outdoor?.replace("{c}", c),
        btu,
        refrigerant: s.refrigerant,
        yearFrom: s.yearFrom,
        yearTo: s.yearTo,
        seer: s.seer,
        hspf: s.hspf,
        voltage: s.voltage ?? (btu <= 12000 && s.type === "mural" ? "115 V ou 208-230 V" : "208-230 V / 1 ph"),
        minHeat: s.minHeat,
        kind: s.kind,
      });
    }
  }
  return out;
}


/** Catalogue Québec (marchands / fabricants, 2018-2025) — années approximatives. */
function fromQc(existing: Set<string>): Model[] {
  const out: Model[] = [];
  for (const [brandId, t, series, main, ind, btu0, refrigerant, seer, hspf, minHeat, v115, yearFrom, yearTo] of QC_ROWS) {
    const type: SystemType = t === "c" ? "central" : "mural";
    const indoor = ind || main;
    const id = `${brandId}:${indoor}`;
    const k1 = id.toUpperCase();
    const k2 = `${brandId}:${main}`.toUpperCase();
    if (existing.has(k1) || existing.has(k2)) continue;
    existing.add(k1);
    existing.add(k2);
    // Les numéros Gree Comfort encodent la capacité (ex. FLEXX36… = 36 000 BTU)
    const cap = /^(?:LIVV?|LIVS|VIRU?|SAP|ENV|FLEX[XE]|FX[EU]|CROWN|RIO|UMAT)(\d{2})HP/.exec(main);
    const btu = cap ? parseInt(cap[1], 10) * 1000 : btu0;
    out.push({
      id,
      brandId,
      type,
      series,
      indoor,
      outdoor: ind && ind !== main ? main : undefined,
      btu,
      refrigerant,
      yearFrom,
      yearTo: yearTo || undefined,
      seer: seer || undefined,
      hspf: hspf || undefined,
      voltage: v115 ? "115 V / 1 ph" : "208-230 V / 1 ph",
      minHeat: minHeat || undefined,
      kind: type === "central" ? "Thermopompe centrale" : "Thermopompe",
      approx: true,
    });
  }
  return out;
}

function build(): Model[] {
  const base = expand();
  const seen = new Set(base.map((m) => m.id.toUpperCase()));
  for (const m of base) if (m.outdoor) seen.add(`${m.brandId}:${m.outdoor}`.toUpperCase());
  const multi = MULTIZONE.filter((m) => !seen.has(m.id.toUpperCase()));
  return [...base, ...fromQc(seen), ...multi];
}

export const MODELS: Model[] = build();
export const modelById = (id?: string) => MODELS.find((m) => m.id === id);

export const BTU_OPTIONS: Record<SystemType, number[]> = {
  mural: [5000, 7000, 9000, 12000, 15000, 18000, 24000, 30000, 36000, 42000, 48000, 60000],
  central: [18000, 24000, 30000, 36000, 42000, 48000, 60000],
};

/** Format nominal le plus proche (ex. 20k → 18k, 45k → 48k) pour les filtres BTU. */
export function btuBucket(type: SystemType, btu: number): number {
  const opts = BTU_OPTIONS[type];
  let best = opts[0];
  for (const o of opts) if (Math.abs(o - btu) <= Math.abs(best - btu)) best = o;
  return best;
}

export const REFRIGERANTS = ["R22", "R410A", "R32", "R454B"] as const;
