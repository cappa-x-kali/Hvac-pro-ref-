export type SystemType = "mural" | "central";
export type Refrigerant = "R22" | "R410A" | "R32" | "R454B";

export type Brand = {
  id: string;
  name: string;
  color: string;
  origin: string;
  types: SystemType[];
  /** Plateforme / fabricant d'origine quand c'est notoire */
  oem?: string;
  /** Portails officiels de documentation */
  links: { label: string; url: string }[];
  /** Jeux de codes d'erreur applicables */
  codeSets: { mural?: string[]; central?: string[] };
  /** Id du décodeur de numéro de série */
  serial?: string;
};

export type Model = {
  id: string;
  brandId: string;
  type: SystemType;
  series: string;
  indoor: string;
  outdoor?: string;
  btu: number;
  refrigerant: Refrigerant;
  yearFrom: number;
  yearTo?: number;
  seer?: string;
  hspf?: string;
  voltage: string;
  minHeat?: string;
  kind?: string;
  custom?: boolean;
  /** Multizone : nombre de zones / ports */
  zones?: string;
  /** Multizone : têtes intérieures compatibles */
  heads?: string;
  /** Fiche issue du catalogue marchand : années / specs approximatives */
  approx?: boolean;
};

export type ErrorCode = {
  code: string;
  title: string;
  causes: string;
  fix: string;
};

export type CodeSet = {
  id: string;
  name: string;
  type: SystemType;
  note?: string;
  codes: ErrorCode[];
};
