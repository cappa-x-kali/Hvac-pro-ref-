import { MURAL_SETS } from "./errors-mural";
import { CENTRAL_SETS } from "./errors-central";
import { BRANDS } from "./brands";
import type { CodeSet, ErrorCode, SystemType } from "./types";

export const CODE_SETS: CodeSet[] = [...MURAL_SETS, ...CENTRAL_SETS];
export const codeSetById = (id: string) => CODE_SETS.find((s) => s.id === id);

export function setsForBrand(brandId: string, type?: SystemType): CodeSet[] {
  const b = BRANDS.find((x) => x.id === brandId);
  if (!b) return [];
  const ids = type ? b.codeSets[type] ?? [] : [...(b.codeSets.mural ?? []), ...(b.codeSets.central ?? [])];
  return [...new Set(ids)].map(codeSetById).filter(Boolean) as CodeSet[];
}

export type CodeHit = { set: CodeSet; code: ErrorCode; brands: string[] };

const norm = (s: string) => s.toLowerCase().replace(/[\s.\-–]/g, "").replace("clignotements", "clign").replace("flash", "clign");

export function searchCodes(q: string, brandIds?: string[]): CodeHit[] {
  const n = norm(q);
  const out: CodeHit[] = [];
  for (const set of CODE_SETS) {
    const brands = BRANDS.filter((b) => [...(b.codeSets.mural ?? []), ...(b.codeSets.central ?? [])].includes(set.id)).map((b) => b.id);
    if (brandIds && brandIds.length && !brands.some((b) => brandIds.includes(b))) continue;
    for (const code of set.codes) {
      if (!n) { out.push({ set, code, brands }); continue; }
      const c = norm(code.code);
      const exact = c === n || c.split("/").includes(n) || c.startsWith(n);
      const text = norm(code.title + code.causes).includes(n);
      if (exact || (n.length > 3 && text)) out.push({ set, code, brands });
    }
  }
  return out;
}
