import type { Brand } from "./types";
import { MODELS } from "./models";

const g = (q: string) => `https://www.google.com/search?q=${encodeURIComponent(q)}`;

export const BRANDS: Brand[] = [
  {
    id: "mitsubishi", name: "Mitsubishi Electric", color: "#E60012", origin: "Japon",
    types: ["mural", "central"], serial: "mitsubishi",
    links: [
      { label: "Mitsubishi Tech Info Canada (manuels)", url: "https://www.mitsubishitechinfo.ca" },
      { label: "MyLinkDrive (documentation US)", url: "https://www.mylinkdrive.com" },
      { label: "Mitsubishi Electric Canada", url: "https://www.mitsubishielectric.ca" },
    ],
    codeSets: { mural: ["mitsubishi", "mitsubishi-blink"], central: ["mitsubishi"] },
  },
  {
    id: "daikin", name: "Daikin", color: "#0097E0", origin: "Japon",
    types: ["mural", "central"], serial: "goodman",
    links: [
      { label: "Daikin Comfort — documentation", url: "https://daikincomfort.com" },
      { label: "Daikin AC (ductless)", url: "https://www.daikinac.com" },
    ],
    codeSets: { mural: ["daikin"], central: ["goodman-furnace", "copeland"] },
  },
  {
    id: "fujitsu", name: "Fujitsu", color: "#C8102E", origin: "Japon",
    types: ["mural"],
    links: [
      { label: "Fujitsu General Canada", url: "https://www.fujitsu-general.com/ca/" },
      { label: "Airstage (documentation technique)", url: "https://www.airstagehvac.com" },
    ],
    codeSets: { mural: ["fujitsu"] },
  },
  {
    id: "lg", name: "LG", color: "#A50034", origin: "Corée du Sud",
    types: ["mural"], serial: "lg",
    links: [
      { label: "LG HVAC — ressources", url: "https://lghvac.com" },
      { label: "Support LG Canada", url: "https://www.lg.com/ca_en/support/" },
    ],
    codeSets: { mural: ["lg"] },
  },
  {
    id: "samsung", name: "Samsung", color: "#1428A0", origin: "Corée du Sud",
    types: ["mural"], serial: "samsung",
    links: [
      { label: "Samsung HVAC", url: "https://www.samsunghvac.com" },
      { label: "Support Samsung Canada", url: "https://www.samsung.com/ca/support/" },
    ],
    codeSets: { mural: ["samsung"] },
  },
  {
    id: "gree", name: "Gree", color: "#0067B1", origin: "Chine",
    types: ["mural", "central"],
    links: [
      { label: "Gree Comfort — manuels", url: "https://www.greecomfort.com" },
    ],
    codeSets: { mural: ["gree"], central: ["gree"] },
  },
  {
    id: "midea", name: "Midea", color: "#0072CE", origin: "Chine",
    types: ["mural"],
    links: [{ label: "Midea Canada", url: "https://www.midea.com/ca" }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "senville", name: "Senville", color: "#00A3E0", origin: "Canada (plateforme Midea)", oem: "Midea",
    types: ["mural"],
    links: [
      { label: "Senville — manuels", url: "https://senville.com" },
      { label: "Centre d'aide Senville", url: "https://help.senville.com" },
    ],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "carrier", name: "Carrier", color: "#1891F6", origin: "États-Unis",
    types: ["mural", "central"], serial: "carrier", oem: "Midea (muraux Performance)",
    links: [
      { label: "Carrier Canada", url: "https://www.carrier.com/residential/en/ca/" },
      { label: "Carrier — documents techniques", url: g("site:shareddocs.com carrier installation instructions") },
    ],
    codeSets: { mural: ["midea"], central: ["carrier-furnace", "copeland"] },
  },
  {
    id: "bryant", name: "Bryant", color: "#D52B1E", origin: "États-Unis (groupe Carrier)",
    types: ["mural", "central"], serial: "carrier",
    links: [{ label: "Bryant", url: "https://www.bryant.com" }],
    codeSets: { mural: ["midea"], central: ["carrier-furnace", "copeland"] },
  },
  {
    id: "toshiba", name: "Toshiba-Carrier", color: "#E50012", origin: "Japon",
    types: ["mural"],
    links: [
      { label: "Toshiba-Carrier (Carrier Canada)", url: "https://www.carrier.com/residential/en/ca/products/ductless-mini-splits/" },
    ],
    codeSets: { mural: ["toshiba"] },
  },
  {
    id: "panasonic", name: "Panasonic", color: "#0041C0", origin: "Japon",
    types: ["mural"],
    links: [{ label: "Panasonic Canada — HVAC", url: "https://na.panasonic.ca/indoor-air-quality/hvac/mini-split" }],
    codeSets: { mural: ["panasonic"] },
  },
  {
    id: "hitachi", name: "Hitachi", color: "#E60027", origin: "Japon (JCI-Hitachi)",
    types: ["mural"],
    links: [{ label: "Hitachi Air Conditioning", url: "https://www.hitachiaircon.com" }],
    codeSets: { mural: ["hitachi"] },
  },
  {
    id: "bosch", name: "Bosch", color: "#EA0016", origin: "Allemagne", oem: "Midea (Climate 5000)",
    types: ["mural", "central"],
    links: [{ label: "Bosch Home Comfort Canada", url: "https://www.bosch-homecomfort.com/ca/" }],
    codeSets: { mural: ["midea"], central: ["copeland", "furnace-generic"] },
  },
  {
    id: "cooperhunter", name: "Cooper & Hunter", color: "#2E7D32", origin: "É.-U. (plateforme Gree)", oem: "Gree",
    types: ["mural"],
    links: [{ label: "Cooper & Hunter", url: "https://www.cooperandhunter.us" }],
    codeSets: { mural: ["gree"] },
  },
  {
    id: "tosot", name: "Tosot", color: "#00897B", origin: "Marque Gree", oem: "Gree",
    types: ["mural"],
    links: [{ label: "Rechercher manuels Tosot", url: g("Tosot mini split owner's manual pdf") }],
    codeSets: { mural: ["gree"] },
  },
  {
    id: "lennox", name: "Lennox", color: "#E31837", origin: "États-Unis",
    types: ["central"], serial: "lennox",
    links: [
      { label: "Lennox", url: "https://www.lennox.com" },
      { label: "Lennox PROs — documentation", url: "https://www.lennoxpros.com" },
    ],
    codeSets: { central: ["lennox", "copeland"] },
  },
  {
    id: "trane", name: "Trane", color: "#D71920", origin: "États-Unis",
    types: ["central"], serial: "trane",
    links: [{ label: "Trane résidentiel", url: "https://www.trane.com/residential/en/" }],
    codeSets: { central: ["trane-furnace", "copeland"] },
  },
  {
    id: "americanstandard", name: "American Standard", color: "#003F7D", origin: "États-Unis (Trane)",
    types: ["central"], serial: "trane",
    links: [{ label: "American Standard Air", url: "https://www.americanstandardair.com" }],
    codeSets: { central: ["trane-furnace", "copeland"] },
  },
  {
    id: "goodman", name: "Goodman", color: "#00539B", origin: "États-Unis (Daikin)",
    types: ["central"], serial: "goodman",
    links: [{ label: "Goodman — documentation", url: "https://www.goodmanmfg.com" }],
    codeSets: { central: ["goodman-furnace", "copeland"] },
  },
  {
    id: "amana", name: "Amana", color: "#C8102E", origin: "États-Unis (Daikin)",
    types: ["central"], serial: "goodman",
    links: [{ label: "Amana HAC", url: "https://www.amana-hac.com" }],
    codeSets: { central: ["goodman-furnace", "copeland"] },
  },
  {
    id: "rheem", name: "Rheem", color: "#E03C31", origin: "États-Unis",
    types: ["central"], serial: "rheem",
    links: [{ label: "Rheem", url: "https://www.rheem.com" }],
    codeSets: { central: ["rheem-furnace", "copeland"] },
  },
  {
    id: "ruud", name: "Ruud", color: "#004B87", origin: "États-Unis (Rheem)",
    types: ["central"], serial: "rheem",
    links: [{ label: "Ruud", url: "https://www.ruud.com" }],
    codeSets: { central: ["rheem-furnace", "copeland"] },
  },
  {
    id: "york", name: "York", color: "#005EB8", origin: "États-Unis (JCI)",
    types: ["central"], serial: "york",
    links: [{ label: "York", url: "https://www.york.com" }],
    codeSets: { central: ["york-furnace", "copeland"] },
  },
  {
    id: "keeprite", name: "KeepRite", color: "#00843D", origin: "Canada (ICP / Carrier)",
    types: ["central"], serial: "icp",
    links: [{ label: "Rechercher documentation KeepRite", url: g("KeepRite installation instructions pdf") }],
    codeSets: { central: ["furnace-generic", "copeland"] },
  },
  {
    id: "tempstar", name: "Tempstar", color: "#E87722", origin: "ICP / Carrier",
    types: ["central"], serial: "icp",
    links: [{ label: "Tempstar", url: "https://www.tempstar.com" }],
    codeSets: { central: ["furnace-generic", "copeland"] },
  },
  {
    id: "napoleon", name: "Napoleon", color: "#B71C1C", origin: "Canada",
    types: ["central"],
    links: [{ label: "Napoleon — chauffage et climatisation", url: "https://www.napoleon.com" }],
    codeSets: { central: ["furnace-generic", "copeland"] },
  },
  {
    id: "arcoaire", name: "Arcoaire", color: "#1565C0", origin: "ICP / Carrier (É.-U.)",
    types: ["mural"],
    links: [{ label: "Site officiel Arcoaire", url: "https://www.arcoaire.com" }, { label: "Manuels Arcoaire (recherche PDF)", url: g("Arcoaire thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "durastar", name: "DuraStar", color: "#E65100", origin: "É.-U. (plateforme Midea/Gree selon série)",
    types: ["mural"],
    links: [{ label: "Site officiel DuraStar", url: "https://www.durastarhvac.com" }, { label: "Manuels DuraStar (recherche PDF)", url: g("DuraStar thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "general", name: "General (Airstage)", color: "#C8102E", origin: "Japon — Fujitsu General",
    types: ["mural"],
    links: [{ label: "Site officiel General (Airstage)", url: "https://www.fujitsu-general.com/ca/" }, { label: "Manuels General (Airstage) (recherche PDF)", url: g("General (Airstage) thermopompe manuel installation pdf") }],
    codeSets: { mural: ["fujitsu"] },
  },
  {
    id: "elios", name: "Elios", color: "#00838F", origin: "Québec (distribution)",
    types: ["mural"],
    links: [{ label: "Manuels Elios (recherche PDF)", url: g("Elios thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "zephyr", name: "Zephyr", color: "#5E35B1", origin: "Canada (distribution)",
    types: ["mural"],
    links: [{ label: "Manuels Zephyr (recherche PDF)", url: g("Zephyr thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "sharp", name: "Sharp", color: "#D32F2F", origin: "Japon",
    types: ["mural"],
    links: [{ label: "Site officiel Sharp", url: "https://www.sharpusa.com" }, { label: "Manuels Sharp (recherche PDF)", url: g("Sharp thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "directair", name: "Direct Air", color: "#0277BD", origin: "Québec (distribution)",
    types: ["mural"],
    links: [{ label: "Manuels Direct Air (recherche PDF)", url: g("Direct Air thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "forestair", name: "ForestAir", color: "#2E7D32", origin: "Québec (distribution)",
    types: ["mural"],
    links: [{ label: "Manuels ForestAir (recherche PDF)", url: g("ForestAir thermopompe manuel installation pdf") }],
    codeSets: { mural: ["gree"] },
  },
  {
    id: "canair", name: "Canair", color: "#C62828", origin: "Canada (distribution)",
    types: ["mural"],
    links: [{ label: "Manuels Canair (recherche PDF)", url: g("Canair thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "kinghome", name: "Kinghome", color: "#283593", origin: "Plateforme Gree",
    types: ["mural"],
    links: [{ label: "Manuels Kinghome (recherche PDF)", url: g("Kinghome thermopompe manuel installation pdf") }],
    codeSets: { mural: ["gree"] },
  },
  {
    id: "acd", name: "ACD", color: "#455A64", origin: "Canada (distribution)",
    types: ["mural"],
    links: [{ label: "Manuels ACD (recherche PDF)", url: g("ACD thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "comfortmaker", name: "Comfortmaker", color: "#F57C00", origin: "ICP / Carrier",
    types: ["mural"],
    links: [{ label: "Site officiel Comfortmaker", url: "https://www.comfortmaker.com" }, { label: "Manuels Comfortmaker (recherche PDF)", url: g("Comfortmaker thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "ameristar", name: "Ameristar", color: "#1E88E5", origin: "Trane Technologies",
    types: ["mural"],
    links: [{ label: "Site officiel Ameristar", url: "https://www.ameristarhvac.com" }, { label: "Manuels Ameristar (recherche PDF)", url: g("Ameristar thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "haxxair", name: "Haxxair", color: "#6A1B9A", origin: "Canada (distribution)",
    types: ["mural"],
    links: [{ label: "Manuels Haxxair (recherche PDF)", url: g("Haxxair thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "willis", name: "Willis", color: "#00695C", origin: "Canada (distribution)",
    types: ["mural"],
    links: [{ label: "Manuels Willis (recherche PDF)", url: g("Willis thermopompe manuel installation pdf") }],
    codeSets: { mural: ["gree"] },
  },
  {
    id: "conforto", name: "Conforto", color: "#8D6E63", origin: "Québec (distribution)",
    types: ["mural"],
    links: [{ label: "Manuels Conforto (recherche PDF)", url: g("Conforto thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "generallux", name: "Generallux (Manuflow)", color: "#37474F", origin: "Québec — Manuflow",
    types: ["mural"],
    links: [{ label: "Manuels Generallux (Manuflow) (recherche PDF)", url: g("Generallux (Manuflow) thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "novair", name: "Novair", color: "#0097A7", origin: "Canada (distribution)",
    types: ["mural"],
    links: [{ label: "Manuels Novair (recherche PDF)", url: g("Novair thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "airtempo", name: "AirTempo", color: "#7CB342", origin: "Canada (distribution)",
    types: ["mural"],
    links: [{ label: "Manuels AirTempo (recherche PDF)", url: g("AirTempo thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "concerto", name: "Concerto (TTI)", color: "#AD1457", origin: "Canada — TTI",
    types: ["mural"],
    links: [{ label: "Manuels Concerto (TTI) (recherche PDF)", url: g("Concerto (TTI) thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "tcl", name: "TCL", color: "#E53935", origin: "Chine",
    types: ["mural"],
    links: [{ label: "Site officiel TCL", url: "https://www.tcl.com/ca" }, { label: "Manuels TCL (recherche PDF)", url: g("TCL thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
  {
    id: "windair", name: "Windair", color: "#039BE5", origin: "Canada (distribution)",
    types: ["mural"],
    links: [{ label: "Manuels Windair (recherche PDF)", url: g("Windair thermopompe manuel installation pdf") }],
    codeSets: { mural: ["midea"] },
  },
];

// Types (mural / central) déduits du catalogue réel de modèles
for (const b of BRANDS) {
  for (const m of MODELS) {
    if (m.brandId === b.id && !b.types.includes(m.type)) b.types.push(m.type);
  }
  if (b.types.includes("central") && !b.codeSets.central) b.codeSets.central = ["furnace-generic", "copeland"];
  if (b.types.includes("mural") && !b.codeSets.mural) b.codeSets.mural = ["midea"];
}

export const brandById = (id?: string) => BRANDS.find((b) => b.id === id);

export const manualSearchUrl = (brand: string, model: string, kind: "owner" | "install" | "service") => {
  const k = kind === "owner" ? "owner's manual" : kind === "install" ? "installation manual" : "service manual";
  return g(`${brand} ${model} ${k} filetype:pdf`);
};
