import type { CodeSet, ErrorCode } from "./types";

export type Severity = "info" | "faible" | "moyen" | "élevé" | "critique";

export type CodeCategory = {
  id: string;
  label: string;
  icon: string;
  severity: Severity;
  /** Ce que signifie cette famille de défauts */
  what: string;
  /** Effet sur l'appareil / le client */
  impact: string;
  steps: string[];
  values?: [string, string][];
  tools: string[];
  /** Pièces à vérifier (mots-clés FR affichés + requête EN) */
  parts: [string, string][];
  pitfalls: string[];
  safety?: string;
};

const INVERTER_SAFETY = "Couper l'alimentation et attendre 5–10 min : le bus DC de la carte extérieure (310–380 V DC) reste chargé. Mesurer < 30 V DC entre P et N avant de toucher.";
const HV_SAFETY = "Cadenasser le sectionneur, vérifier l'absence de tension et décharger les condensateurs avant toute intervention.";
const GAS_SAFETY = "Couper le gaz et l'électricité avant de démonter. Après réparation : test d'étanchéité au détecteur ou à l'eau savonneuse et mesure de CO.";

export const CATEGORIES: CodeCategory[] = [
  {
    id: "normal",
    label: "État normal / information",
    icon: "checkmark-circle-outline",
    severity: "info",
    what: "Ce n'est pas un défaut : le code indique un état de fonctionnement (sous tension, attente, aucun code en mémoire, mode de protection temporaire).",
    impact: "Aucun impact. L'appareil fonctionne ou attend une demande.",
    steps: [
      "Confirmer que la demande du thermostat / télécommande est bien active.",
      "Laisser passer les délais de protection (3 à 5 min anti-court-cycle).",
      "Consulter l'historique des codes de la carte pour voir d'anciens défauts.",
    ],
    tools: ["Multimètre", "Manuel d'installation"],
    parts: [],
    pitfalls: ["Remplacer une pièce alors que l'appareil est simplement en délai de protection ou en mode dégivrage."],
  },
  {
    id: "comm",
    label: "Communication",
    icon: "swap-horizontal-outline",
    severity: "élevé",
    what: "Les cartes intérieure et extérieure (ou la télécommande / le thermostat communicant) ne s'échangent plus de données. L'appareil se met en arrêt de sécurité.",
    impact: "Arrêt complet du chauffage / de la climatisation tant que le lien n'est pas rétabli.",
    steps: [
      "Couper l'alimentation 2–3 min (réinitialisation) et remettre sous tension.",
      "Vérifier le serrage des bornes 1-2-3 / S1-S2-S3 aux deux unités ; chercher épissures, fils oxydés, dommages d'animaux.",
      "Confirmer l'ordre des conducteurs : la ligne 1 de l'extérieur va sur 1 de l'intérieur, etc.",
      "Mesurer 230 V AC entre 1 et 2 (ou S1-S2) à l'intérieur.",
      "Mesurer le signal entre 2 et 3 (ou S2-S3) : tension DC qui fluctue = communication présente.",
      "Vérifier la continuité de chaque conducteur (alimentation coupée, fils débranchés aux deux bouts).",
      "Vérifier la mise à la terre des deux unités ; éloigner le câble des sources de bruit (variateurs, câbles HT).",
      "Si le câblage est bon : vérifier la DEL de la carte extérieure ; pas de DEL = alimentation / fusible / carte extérieure.",
    ],
    values: [
      ["1–2 (S1–S2)", "208–240 V AC"],
      ["2–3 (S2–S3)", "DC fluctuant ≈ 0–60 V (selon marque)"],
      ["Isolement conducteur–terre", "> 1 MΩ"],
    ],
    tools: ["Multimètre", "Mégohmmètre", "Tournevis dynamométrique"],
    parts: [["Câble d'interconnexion 14/4", "14/4 mini split interconnect wire"], ["Carte intérieure", "indoor PCB"], ["Carte extérieure", "outdoor PCB"], ["Fusible de carte", "PCB fuse"]],
    pitfalls: [
      "Câble avec épissure ou boîte de jonction non prévue par le fabricant.",
      "Câble téléphonique / mauvais calibre utilisé pour l'interconnexion.",
      "Multizone : câble d'une zone raccordé sur la tuyauterie d'une autre zone.",
      "Remplacer la carte avant d'avoir vérifié le serrage des bornes.",
    ],
    safety: INVERTER_SAFETY,
  },
  {
    id: "flame",
    label: "Allumage / flamme",
    icon: "flame-outline",
    severity: "élevé",
    what: "La fournaise n'arrive pas à allumer ou ne détecte pas correctement la flamme (ou la détecte alors qu'il ne devrait pas y en avoir).",
    impact: "Pas de chauffage au gaz ; verrouillage après plusieurs essais (souvent 1 h).",
    steps: [
      "Confirmer l'alimentation en gaz (robinet ouvert, pression d'entrée).",
      "Observer la séquence : inducteur → pressostat → allumeur rouge → ouverture de la vanne → flamme.",
      "Allumeur à surface chaude : mesurer la résistance à froid.",
      "Nettoyer la tige de détection de flamme (laine d'acier fine / papier émeri fin) et vérifier sa mise à la terre.",
      "Mesurer le courant de flamme en µA DC en série avec la tige.",
      "Vérifier la polarité L/N et la mise à la terre de la fournaise (essentiel pour la détection de flamme).",
      "Vérifier la tension 24 V aux bornes de la vanne pendant l'essai d'allumage.",
    ],
    values: [
      ["Courant de flamme", "> 1 µA DC (typ. 2–6 µA)"],
      ["Allumeur silicium nitrure", "≈ 10–20 Ω"],
      ["Allumeur carbure de silicium", "≈ 40–90 Ω"],
      ["Pression gaz naturel (entrée)", "5–7 po CE"],
    ],
    tools: ["Multimètre avec µA DC", "Manomètre", "Détecteur de fuite de gaz", "Analyseur de combustion"],
    parts: [["Allumeur", "hot surface igniter"], ["Capteur de flamme", "flame sensor"], ["Vanne de gaz", "gas valve furnace"], ["Carte de contrôle", "furnace control board"]],
    pitfalls: ["Polarité L/N inversée ou neutre-terre flottant.", "Remplacer la carte alors que la tige de flamme est simplement encrassée."],
    safety: GAS_SAFETY,
  },
  {
    id: "draft",
    label: "Pressostat / tirage / inducteur",
    icon: "speedometer-outline",
    severity: "élevé",
    what: "Le pressostat d'air ne confirme pas le tirage de l'inducteur (ou reste fermé alors qu'il devrait être ouvert).",
    impact: "La fournaise ne démarre pas la séquence d'allumage.",
    steps: [
      "Vérifier que l'inducteur démarre et tourne librement (roulements, bruit).",
      "Inspecter le tube du pressostat : fissure, eau, obstruction.",
      "Vérifier l'évacuation : terminaison bloquée par glace / neige / nid, pente des tuyaux PVC.",
      "Vérifier le siphon du condensat et le drain de la fournaise (eau dans le boîtier de l'inducteur).",
      "Mesurer la dépression au manomètre et comparer à la valeur inscrite sur le pressostat.",
      "Vérifier la continuité du pressostat : fermé avec l'inducteur en marche, ouvert à l'arrêt.",
    ],
    values: [["Dépression", "Voir l'étiquette du pressostat (ex. -0,55 po CE)"]],
    tools: ["Manomètre différentiel", "Multimètre", "Lampe de poche / miroir"],
    parts: [["Pressostat d'air", "furnace pressure switch"], ["Inducteur", "inducer motor"], ["Siphon de condensat", "condensate trap furnace"]],
    pitfalls: ["Terminaisons PVC obstruées par la neige en hiver au Québec.", "Ponter le pressostat pour « tester » : danger de CO."],
    safety: GAS_SAFETY,
  },
  {
    id: "limit",
    label: "Limite / rollout / surchauffe fournaise",
    icon: "thermometer-outline",
    severity: "critique",
    what: "Un dispositif de sécurité thermique s'est ouvert : surchauffe de l'échangeur (limite) ou flamme hors du brûleur (rollout).",
    impact: "Arrêt du brûleur ; un rollout doit être investigué avant tout réarmement.",
    steps: [
      "Vérifier le filtre à air, les grilles de retour et les registres (débit d'air).",
      "Vérifier le fonctionnement et la vitesse de la soufflante en chauffage.",
      "Mesurer la hausse de température (ΔT) et comparer à la plage de la plaque signalétique.",
      "Rollout : inspecter l'échangeur (fissures), le brûleur, l'évacuation bloquée avant de réarmer.",
      "Vérifier la continuité des limites à froid.",
    ],
    values: [["Hausse de température (ΔT)", "Voir la plaque (ex. 35–65 °F)"]],
    tools: ["Thermomètres", "Multimètre", "Analyseur de combustion", "Caméra d'inspection"],
    parts: [["Limite haute", "furnace limit switch"], ["Interrupteur rollout", "rollout switch"], ["Moteur soufflante", "blower motor"]],
    pitfalls: ["Réarmer un rollout à répétition sans trouver la cause (échangeur fissuré, CO)."],
    safety: GAS_SAFETY,
  },
  {
    id: "sensor",
    label: "Sonde / thermistance",
    icon: "thermometer-outline",
    severity: "moyen",
    what: "La carte lit une valeur impossible sur une sonde : circuit ouvert (fil coupé, connecteur) ou court-circuit (sonde endommagée).",
    impact: "Fonctionnement arrêté ou en mode dégradé selon la sonde concernée.",
    steps: [
      "Identifier la sonde concernée (manuel de service) et son connecteur sur la carte.",
      "Débrancher le connecteur et inspecter les broches (corrosion, broche reculée).",
      "Mesurer la résistance de la sonde et la comparer à la table selon la température réelle (onglet Pièces du modèle).",
      "Plier / chauffer légèrement le fil pendant la mesure pour détecter une coupure intermittente.",
      "Vérifier que la sonde est bien fixée sur le tuyau (pâte thermique, isolation).",
      "Si la sonde est bonne : mesurer la tension au connecteur sur la carte (typ. 5 V DC en circuit ouvert).",
    ],
    values: [
      ["Sonde ambiante / serpentin", "10–20 kΩ à 25 °C (selon marque)"],
      ["Sonde de refoulement", "≈ 50 kΩ à 25 °C"],
      ["Tension à vide carte", "≈ 5 V DC"],
    ],
    tools: ["Multimètre", "Thermomètre de contact", "Table de thermistances"],
    parts: [["Thermistance", "thermistor sensor"], ["Carte de contrôle", "control board"]],
    pitfalls: ["Comparer la résistance à 25 °C alors que la sonde est à -10 °C dehors.", "Sonde décollée du tuyau : valeur plausible mais fausse."],
  },
  {
    id: "hp",
    label: "Haute pression / surchauffe",
    icon: "trending-up-outline",
    severity: "élevé",
    what: "Pression ou température de refoulement trop élevée : le système ne rejette pas assez de chaleur ou est surchargé.",
    impact: "Arrêt de protection du compresseur ; risque d'usure prématurée si répété.",
    steps: [
      "Vérifier que les vannes de service sont complètement ouvertes.",
      "Climatisation : nettoyer le condenseur extérieur, vérifier le ventilateur extérieur.",
      "Chauffage : nettoyer le filtre et le serpentin intérieur, vérifier le ventilateur intérieur.",
      "Mesurer pressions et températures ; calculer sous-refroidissement et surchauffe (outil P/T).",
      "Rechercher une surcharge de réfrigérant ou des incondensables (sous-refroidissement élevé).",
      "Vérifier le détendeur (EEV / TXV) et la sonde de refoulement.",
      "Vérifier le pressostat HP (continuité) s'il est présent.",
    ],
    values: [
      ["Pressostat HP R410A / R32 / R454B", "Ouvre ≈ 600–650 psig"],
      ["Refoulement compresseur", "< 105–115 °C (selon fabricant)"],
    ],
    tools: ["Manifold / jauges numériques", "Pinces thermométriques", "Balance de charge", "Outil P/T de l'app"],
    parts: [["Moteur ventilateur", "fan motor"], ["Détendeur électronique", "EEV expansion valve"], ["Sonde de refoulement", "discharge sensor"], ["Pressostat HP", "high pressure switch"]],
    pitfalls: ["Ajouter du réfrigérant sans peser la charge.", "Ventilateur intérieur à basse vitesse en chauffage (filtre bouché)."],
    safety: INVERTER_SAFETY,
  },
  {
    id: "lp",
    label: "Basse pression / manque de réfrigérant",
    icon: "trending-down-outline",
    severity: "élevé",
    what: "Pression d'aspiration trop basse ou détection de manque de réfrigérant : fuite, restriction ou débit d'air insuffisant à l'évaporateur.",
    impact: "Capacité réduite, givrage, puis arrêt de protection.",
    steps: [
      "Vérifier filtres et débit d'air à l'évaporateur.",
      "Mesurer pressions, surchauffe et sous-refroidissement.",
      "Surchauffe élevée + sous-refroidissement bas = manque de charge → chercher la fuite.",
      "Inspecter les raccords évasés (flare) en premier : détecteur électronique ou bulles.",
      "Test d'azote sous pression, vide < 500 microns, recharge à la balance.",
      "Surchauffe élevée + sous-refroidissement élevé = restriction (EEV bloqué, filtre, tuyau pincé).",
    ],
    values: [["Vide avant recharge", "< 500 microns, maintien 10 min"], ["Test d'étanchéité azote", "Voir manuel (souvent 550 psig max)"]],
    tools: ["Manifold", "Détecteur de fuites", "Azote + régulateur", "Pompe à vide + jauge microns", "Balance"],
    parts: [["Raccords flare", "flare nut"], ["Détendeur électronique", "EEV"], ["Filtre déshydrateur", "filter drier"], ["Pressostat BP", "low pressure switch"]],
    pitfalls: ["Recharger sans trouver la fuite.", "Raccords flare non serrés au couple ou sans huile."],
  },
  {
    id: "compressor",
    label: "Compresseur / onduleur (IPM)",
    icon: "cog-outline",
    severity: "critique",
    what: "Défaut dans l'entraînement du compresseur : surintensité, perte de synchronisation, module de puissance (IPM) ou enroulement du compresseur.",
    impact: "Compresseur arrêté ; verrouillage après plusieurs essais.",
    steps: [
      "Lire les codes de la carte extérieure et l'historique (DEL ou afficheur).",
      "Vérifier la tension d'alimentation sous charge (chute de tension).",
      "Alimentation coupée et bus déchargé : débrancher U-V-W et mesurer les enroulements du compresseur.",
      "Mesurer l'isolement de chaque borne vers la masse au mégohmmètre.",
      "Tester l'IPM en mode diode (U, V, W vers P et N) : valeurs semblables sur les trois phases.",
      "Rebrancher, démarrer en mode test : un compresseur qui force peut indiquer un problème mécanique ou une surcharge.",
      "Central : vérifier condensateur, contacteur, et C-R / C-S / S-R du compresseur.",
    ],
    values: [
      ["Enroulements inverter U-V / V-W / U-W", "Égaux, ≈ 0,5–3 Ω"],
      ["Isolement vers masse", "> 1 MΩ (idéalement > 20 MΩ)"],
      ["Scroll monophasé", "C-R + C-S = S-R"],
    ],
    tools: ["Multimètre", "Mégohmmètre 500 V", "Pince ampèremétrique", "Testeur de condensateur"],
    parts: [["Compresseur", "compressor"], ["Carte onduleur / IPM", "inverter board IPM"], ["Condensateur double", "dual run capacitor"], ["Contacteur", "contactor"], ["Réactance PFC", "reactor"]],
    pitfalls: ["Remplacer le compresseur alors que c'est l'IPM (ou l'inverse).", "Travailler sur la carte sans décharger le bus DC."],
    safety: INVERTER_SAFETY,
  },
  {
    id: "fan",
    label: "Moteur de ventilateur / soufflante",
    icon: "sync-outline",
    severity: "moyen",
    what: "La carte ne reçoit pas le signal de vitesse du moteur (DC) ou détecte un blocage / une surintensité du ventilateur.",
    impact: "Arrêt de l'appareil pour protéger le serpentin et le compresseur.",
    steps: [
      "Tourner l'hélice / la roue à la main : doit être libre (glace, débris, roulements).",
      "Moteur DC : mesurer au connecteur 310 V DC, 15 V DC, signal de vitesse Vsp et retour FG.",
      "Moteur PSC : mesurer les enroulements et le condensateur de marche.",
      "Moteur ECM / X13 : 120/240 V permanent + signal 24 V sur une prise de vitesse.",
      "Vérifier le connecteur sur la carte (broches brûlées / oxydées).",
    ],
    values: [["DC intérieur", "310 V DC · 15 V DC · Vsp 0–6,5 V"], ["Condensateur PSC", "± 6 % de la valeur nominale"]],
    tools: ["Multimètre", "Testeur de condensateur", "Tachymètre"],
    parts: [["Moteur ventilateur", "fan motor"], ["Condensateur moteur", "fan capacitor"], ["Carte de contrôle", "control board"]],
    pitfalls: ["Glace dans la base extérieure qui bloque l'hélice en hiver (résistance de bac absente).", "Remplacer la carte alors que le moteur DC est en court-circuit (il la détruira de nouveau)."],
    safety: INVERTER_SAFETY,
  },
  {
    id: "power",
    label: "Alimentation / tension",
    icon: "flash-outline",
    severity: "moyen",
    what: "Tension d'alimentation hors plage, perte de phase, fusible ouvert ou anomalie du bus DC / transformateur 24 V.",
    impact: "Arrêt ou fonctionnement instable ; risque pour les cartes.",
    steps: [
      "Mesurer la tension au sectionneur, à vide puis sous charge.",
      "Vérifier le serrage des bornes au panneau, sectionneur et unités (points chauds).",
      "Vérifier les fusibles de carte et le transformateur 24 V (R-C).",
      "Rechercher un court-circuit sur le 24 V (fil de thermostat pincé, bobine en court).",
      "Inverter : mesurer le bus DC et l'état de la réactance / PFC.",
    ],
    values: [["Plage 230 V", "≈ 197–253 V AC"], ["24 V (R–C)", "24–28 V AC"], ["Bus DC", "≈ 310–380 V DC"]],
    tools: ["Multimètre", "Pince ampèremétrique", "Caméra thermique"],
    parts: [["Fusible", "fuse"], ["Transformateur 24 V", "24V transformer"], ["Réactance", "reactor"], ["Carte", "control board"]],
    pitfalls: ["Mesurer la tension uniquement à vide.", "Remplacer le fusible 3 A sans chercher le court-circuit 24 V."],
    safety: HV_SAFETY,
  },
  {
    id: "drain",
    label: "Drain / condensat",
    icon: "water-outline",
    severity: "faible",
    what: "Le flotteur ou le capteur de niveau détecte un bac de condensat plein.",
    impact: "Arrêt en climatisation pour éviter un dégât d'eau.",
    steps: [
      "Vider et nettoyer le bac et le tuyau de drain (algues, bouchon).",
      "Vérifier la pente du drain et l'absence de contre-pente / boucle.",
      "Tester la pompe à condensat (versement d'eau) et son alimentation.",
      "Vérifier le flotteur et son connecteur.",
    ],
    tools: ["Aspirateur eau-poussière", "Pastilles anti-algues", "Multimètre"],
    parts: [["Pompe à condensat", "condensate pump"], ["Flotteur", "float switch"]],
    pitfalls: ["Drain qui gèle à l'extérieur en hiver (sortie sous la neige)."],
  },
  {
    id: "frost",
    label: "Protection gel / dégivrage",
    icon: "snow-outline",
    severity: "moyen",
    what: "Le serpentin est trop froid (risque de gel) ou le cycle de dégivrage ne se fait / ne se termine pas correctement.",
    impact: "Arrêt temporaire, perte de capacité ou accumulation de glace à l'extérieur.",
    steps: [
      "Vérifier le débit d'air : filtre, serpentin, vitesse du ventilateur.",
      "Vérifier la charge de réfrigérant (surchauffe / sous-refroidissement).",
      "Contrôler la sonde de serpentin / de dégivrage.",
      "Central : forcer un dégivrage (broches TEST) et vérifier la vanne d'inversion et le ventilateur.",
      "Vérifier que l'unité extérieure est surélevée et que l'eau de dégivrage s'évacue.",
    ],
    tools: ["Thermomètre de contact", "Manifold", "Multimètre"],
    parts: [["Sonde de serpentin", "coil sensor"], ["Carte de dégivrage", "defrost board"], ["Vanne d'inversion", "reversing valve"], ["Résistance de bac", "base pan heater"]],
    pitfalls: ["Unité posée au sol sans support : la glace s'accumule sous le serpentin."],
  },
  {
    id: "valve",
    label: "Détendeur / vanne 4 voies",
    icon: "git-compare-outline",
    severity: "moyen",
    what: "Défaut du détendeur électronique (EEV/LEV) ou de la vanne d'inversion : débit de réfrigérant ou mode (chaud / froid) incorrect.",
    impact: "Mauvaise capacité, pressions anormales ou mauvais mode.",
    steps: [
      "Écouter le « clic » de réinitialisation de l'EEV à la mise sous tension.",
      "Mesurer la bobine de l'EEV (commun → chaque phase).",
      "Vanne 4 voies : vérifier la tension sur la bobine dans le mode concerné et la température des tuyaux.",
      "Comparer pressions et températures à un fonctionnement normal.",
    ],
    values: [["Bobine EEV 12 V", "≈ 40–50 Ω par phase"], ["Bobine vanne 4 voies 230 V", "≈ 1–2 kΩ"]],
    tools: ["Multimètre", "Aimant de test EEV", "Manifold"],
    parts: [["Détendeur électronique + bobine", "EEV coil"], ["Vanne 4 voies + bobine", "reversing valve coil"]],
    pitfalls: ["Confondre une vanne 4 voies bloquée et un manque de réfrigérant."],
  },
  {
    id: "board",
    label: "Carte électronique / mémoire",
    icon: "hardware-chip-outline",
    severity: "moyen",
    what: "La carte détecte une erreur interne (EEPROM, configuration, circuit de détection) ou un circuit externe qu'elle ne peut pas lire.",
    impact: "Arrêt ; parfois résolu par une réinitialisation.",
    steps: [
      "Couper l'alimentation 3–5 min puis remettre sous tension.",
      "Vérifier les cavaliers / interrupteurs DIP et le modèle configuré.",
      "Inspecter la carte : composants brûlés, traces d'eau, insectes, connecteurs.",
      "Vérifier les tensions d'alimentation de la carte avant de la remplacer.",
      "Commander la carte avec le numéro exact imprimé sur la carte (pas seulement le modèle).",
    ],
    tools: ["Multimètre", "Lampe / loupe", "Manuel de service"],
    parts: [["Carte de contrôle", "control board PCB"], ["EEPROM", "EEPROM chip"]],
    pitfalls: ["Une carte neuve détruite par la même cause (moteur ou bobine en court-circuit)."],
    safety: INVERTER_SAFETY,
  },
  {
    id: "cycle",
    label: "Cycles / temps de fonctionnement",
    icon: "time-outline",
    severity: "faible",
    what: "Le module de diagnostic note des cycles anormaux : marche très longue (capacité insuffisante) ou cycles courts.",
    impact: "Confort réduit, usure et consommation accrues.",
    steps: [
      "Vérifier l'emplacement et les réglages du thermostat (différentiel, cycles/h).",
      "Vérifier la charge de réfrigérant et le débit d'air.",
      "Vérifier le dimensionnement (BTU vs charge du bâtiment).",
      "Rechercher des déclenchements de pressostats intermittents.",
    ],
    tools: ["Manifold", "Thermomètres", "Calcul de charge"],
    parts: [["Thermostat", "thermostat"], ["Pressostat", "pressure switch"]],
    pitfalls: ["Thermostat près d'une source de chaleur ou d'un retour d'air."],
  },
];

const GENERIC: CodeCategory = {
  id: "general",
  label: "Défaut général",
  icon: "construct-outline",
  severity: "moyen",
  what: "Défaut détecté par l'autodiagnostic de l'appareil. Suivez la procédure du fabricant ci-dessous.",
  impact: "Selon le défaut : arrêt complet ou fonctionnement dégradé.",
  steps: [
    "Noter le code exact, le mode (chaud / froid) et les conditions (température extérieure, moment).",
    "Couper l'alimentation 3–5 min puis redémarrer pour voir si le code revient.",
    "Vérifier alimentation, câblage, filtres et débit d'air.",
    "Consulter le manuel de service du modèle exact pour la procédure détaillée.",
  ],
  tools: ["Multimètre", "Manifold", "Manuel de service"],
  parts: [],
  pitfalls: ["Remplacer une pièce sans avoir confirmé la mesure."],
};

const has = (s: string, r: RegExp) => r.test(s);

export function categorize(code: ErrorCode, set: CodeSet): CodeCategory {
  const byTitle = match(code.title.toLowerCase(), code, set);
  return byTitle ?? match(`${code.title} ${code.causes}`.toLowerCase(), code, set) ?? GENERIC;
}

function match(s: string, code: ErrorCode, set: CodeSet): CodeCategory | undefined {
  const furnace = set.id.includes("furnace") || /fournaise/i.test(set.name);
  const pick = (id: string) => CATEGORIES.find((c) => c.id === id) ?? GENERIC;
  if (furnaceLimit(s, set)) return pick("limit");
  if (has(code.title.toLowerCase(), /(?<![a-zé])normal(?!e)|aucun code|sous tension|en attente|veille|nettoyage|anti-air froid|hors plage|trop basse|basse température ambiante|pump-down|manual auto|test de fonctionnement/)) return pick("normal");
  if (has(s, /communication|transmission|réception|transmis|signal série|signal de fonctionnement/)) return pick("comm");
  if (has(s, /flamme|allum|vanne de gaz|ignit/)) return pick("flame");
  if (furnace && has(s, /pressostat|inducteur|tirage|évacuation/) && !has(s, /haute pression|basse pression \(unité/)) return pick("draft");
  if (furnace && has(s, /limite|rollout|toc/)) return pick("limit");
  if (has(s, /sonde|thermistance|capteur(?! de flamme)|th\d/)) return pick("sensor");
  if (has(s, /drain|flotteur|condensat|débordement/)) return pick("drain");
  if (has(s, /gel|givr|dégivr|antigel/)) return pick("frost");
  if (has(s, /haute pression|pression anormale|protection pression|surchauffe|ailette|refoulement|surcharge|63h|température.*élevée/)) return pick("hp");
  if (has(s, /basse pression|manque de réfrigérant|fuite|charge insuffisante/)) return pick("lp");
  if (has(s, /compresseur|ipm|onduleur|rotor|enroulement|circuit (de )?(marche|démarrage)|circuit ouvert|synchron|surintensité|courant|contacteur/)) return pick("compressor");
  if (has(s, /ventilateur|moteur|soufflante/)) return pick("fan");
  if (has(s, /tension|alimentation|polarité|mise à la terre|fusible|bus dc|pfc|phase/)) return pick("power");
  if (has(s, /détendeur|(?<![a-zé])(eev|lev)(?![a-zé])|vanne 4|inversion|4 voies/)) return pick("valve");
  if (has(s, /cycles|fonctionnement long|temps de fonctionnement/)) return pick("cycle");
  if (has(s, /carte|eeprom|mémoire|interne|pcb|configuration|cavalier|combinaison|compatib|nombre d.unités|conflit de mode|défaut unité/)) return pick("board");
  return undefined;
}

const furnaceLimit = (s: string, set: CodeSet) =>
  (set.id.includes("furnace") || /fournaise/i.test(set.name)) && /limite|rollout/.test(s) && !/flamme (absente|faible)|allumage/.test(s);

export const SEVERITY_LABEL: Record<Severity, string> = {
  info: "Information",
  faible: "Faible",
  moyen: "Moyen",
  élevé: "Élevé",
  critique: "Critique",
};

export const splitList = (s: string) =>
  s
    .split(/\s*[,;]\s*|\s+\/\s+/)
    .map((x) => x.trim())
    .filter(Boolean)
    .map((x) => x.charAt(0).toUpperCase() + x.slice(1));

export const splitSteps = (s: string) =>
  s
    .split(/(?<=[.!])\s+|\s*;\s*|,\s+(?=[a-zéèêàâîôûç]+(?:er|ir|re)\b)/i)
    .map((x) => x.replace(/\.$/, "").trim())
    .filter(Boolean)
    .map((x) => x.charAt(0).toUpperCase() + x.slice(1));

export const codeKey = (setId: string, code: string) => encodeURIComponent(`${setId}|${code}`);
export const codeTag = (code: string) => `code-${code.toLowerCase().replace(/[^a-z0-9]+/g, "")}`;
