/**
 * Encodeurs IR pour climatiseurs.
 * Les télécommandes de clim. sont « à état » : chaque touche renvoie une trame complète
 * (marche, mode, consigne, ventilation). On encode donc l'état, pas une touche.
 * Timings et structures de trames : portage TypeScript de la bibliothèque open source
 * IRremoteESP8266 (crankyoldgit, licence LGPL-2.1). Encodeurs en bêta : à valider sur l'appareil.
 */

export type AcMode = "auto" | "cool" | "dry" | "fan" | "heat";
export type AcFan = "auto" | "low" | "med" | "high";
export type AcState = { power: boolean; mode: AcMode; temp: number; fan: AcFan; swing: boolean };
export type AcAction = "state" | "swing" | "off";

export type IrFrame = { frequency: number; pattern: number[]; hex: string };

export type IrProtocol = {
  id: string;
  name: string;
  status: "ok" | "beta" | "soon";
  minTemp: number;
  maxTemp: number;
  encode?: (s: AcState, action: AcAction) => IrFrame;
  note: string;
};

/* ───────── COOLIX (24 bits, famille Midea / clones) ───────── */
const CX = { hdrMark: 4692, hdrSpace: 4416, bitMark: 552, one: 1656, zero: 552, gap: 5244, freq: 38000 };
const CX_TEMP = [0b0000, 0b0001, 0b0011, 0b0010, 0b0110, 0b0111, 0b0101, 0b0100, 0b1100, 0b1101, 0b1001, 0b1000, 0b1010, 0b1011]; // 17→30 °C
const CX_MODE: Record<AcMode, number> = { cool: 0b00, dry: 0b01, fan: 0b01, auto: 0b10, heat: 0b11 };
const CX_FAN: Record<AcFan, number> = { auto: 0b101, low: 0b100, med: 0b010, high: 0b001 };
const CX_OFF = 0xb27be0;
const CX_SWING = 0xb26be0;

export function coolixValue(s: AcState, action: AcAction): number {
  if (action === "off" || !s.power) return CX_OFF;
  if (action === "swing") return CX_SWING;
  const t = Math.min(30, Math.max(17, Math.round(s.temp)));
  const tempCode = s.mode === "fan" ? 0b1110 : CX_TEMP[t - 17];
  // En auto et déshumidification, la vitesse est imposée par l'appareil (code 0b000).
  const fan = s.mode === "auto" || s.mode === "dry" ? 0b000 : CX_FAN[s.fan];
  const sensor = 0b11111;
  return (0xb2 << 16) | (fan << 13) | (sensor << 8) | (tempCode << 4) | (CX_MODE[s.mode] << 2);
}

function coolixPattern(v: number): number[] {
  const p: number[] = [];
  const bits = (byte: number) => {
    for (let i = 7; i >= 0; i--) p.push(CX.bitMark, (byte >> i) & 1 ? CX.one : CX.zero);
  };
  for (let r = 0; r < 2; r++) {
    p.push(CX.hdrMark, CX.hdrSpace);
    for (let b = 2; b >= 0; b--) {
      const byte = (v >> (b * 8)) & 0xff;
      bits(byte);
      bits(~byte & 0xff);
    }
    p.push(CX.bitMark, CX.gap);
  }
  return p;
}

const coolix = (s: AcState, a: AcAction): IrFrame => {
  const v = coolixValue(s, a);
  return { frequency: CX.freq, pattern: coolixPattern(v), hex: "0x" + v.toString(16).toUpperCase().padStart(6, "0") };
};

/* ───────── Outils communs ───────── */
type Timing = { hdrMark: number; hdrSpace: number; bitMark: number; one: number; zero: number; footMark: number; gap: number };

/** Constructeur de motif marque/espace (µs). Fusionne les espaces consécutifs. */
class Pulses {
  p: number[] = [];
  mark(us: number) {
    if (us <= 0) return;
    if (this.p.length % 2 === 1) this.p[this.p.length - 1] += us;
    else this.p.push(us);
  }
  space(us: number) {
    if (us <= 0) return;
    if (this.p.length === 0) return; // un motif commence toujours par une marque
    if (this.p.length % 2 === 0) this.p[this.p.length - 1] += us;
    else this.p.push(us);
  }
  bits(value: number, n: number, t: Timing, msb: boolean) {
    for (let i = 0; i < n; i++) {
      const bit = msb ? (value / 2 ** (n - 1 - i)) % 2 >= 1 : (value >> i) & 1;
      this.mark(t.bitMark);
      this.space(bit ? t.one : t.zero);
    }
  }
  /** Équivalent de IRsend::sendGeneric (octets). */
  bytes(data: number[], t: Timing, msb: boolean, header = true, footer = true) {
    if (header) { this.mark(t.hdrMark); this.space(t.hdrSpace); }
    for (const b of data) this.bits(b & 0xff, 8, t, msb);
    if (footer) { this.mark(t.footMark); this.space(t.gap); }
  }
  done(): number[] {
    const out = this.p.slice();
    if (out.length % 2 === 0) out.pop(); // inutile de transmettre l'espace final
    return out;
  }
}

const sumBytes = (b: number[], from: number, to: number, init = 0) => {
  let s = init;
  for (let i = from; i < to; i++) s += b[i];
  return s & 0xff;
};
const popcount = (v: number) => { let n = 0; for (let x = v & 0xff; x; x >>= 1) n += x & 1; return n; };
const reverse8 = (v: number) => { let r = 0; for (let i = 0; i < 8; i++) r = (r << 1) | ((v >> i) & 1); return r; };
const clampT = (t: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, Math.round(t)));
const hexBytes = (b: number[]) => {
  const h = b.map((x) => (x & 0xff).toString(16).toUpperCase().padStart(2, "0")).join("");
  return h.length > 24 ? `0x${h.slice(0, 12)}…${h.slice(-6)} (${b.length} o)` : "0x" + h;
};
const frame = (freq: number, p: Pulses, hex: string): IrFrame => ({ frequency: freq, pattern: p.done(), hex });

/* ───────── Midea 48 bits ───────── */
const MD: Timing = { hdrMark: 4480, hdrSpace: 4480, bitMark: 560, one: 1680, zero: 560, footMark: 560, gap: 5600 };
const MD_MODE: Record<AcMode, number> = { cool: 0, dry: 1, auto: 2, heat: 3, fan: 4 };
const MD_FAN: Record<AcFan, number> = { auto: 0, low: 1, med: 2, high: 3 };
const MD_SWING = [0xa2, 0x01, 0xff, 0xff, 0xff, 0x7c];

/** Octets de la trame Midea, du plus significatif (en-tête 0xA1) au checksum. */
export function mideaBytes(s: AcState, a: AcAction): number[] {
  if (a === "swing") return MD_SWING.slice();
  const t = clampT(s.temp, 17, 30);
  const on = a !== "off" && s.power;
  const b5 = 0xa1;
  const b4 = (MD_MODE[s.mode] & 7) | ((s.mode === "auto" || s.mode === "dry" ? 0 : MD_FAN[s.fan]) << 3) | (on ? 0x80 : 0);
  const b3 = 0x40 | (t - 17);
  const b = [b5, b4, b3, 0xff, 0xff];
  return [...b, mideaChecksum(b)];
}
/** Checksum Midea : somme des octets inversés bit à bit, complément, ré-inversé. */
export function mideaChecksum(b5to1: number[]): number {
  let sum = 0;
  for (const x of b5to1) sum += reverse8(x);
  return reverse8((256 - (sum & 0xff)) & 0xff);
}
const midea48 = (s: AcState, a: AcAction): IrFrame => {
  const b = mideaBytes(s, a);
  const p = new Pulses();
  p.bytes(b, MD, true);
  p.bytes(b.map((x) => ~x & 0xff), MD, true, true, false);
  p.mark(MD.footMark); p.space(MD.gap);
  return frame(38000, p, hexBytes(b));
};

/* ───────── Gree (YAW1F / YBOF) ───────── */
const GR: Timing = { hdrMark: 9000, hdrSpace: 4500, bitMark: 620, one: 1600, zero: 540, footMark: 620, gap: 19980 };
const GR_MODE: Record<AcMode, number> = { auto: 0, cool: 1, dry: 2, fan: 3, heat: 4 };
const GR_FAN: Record<AcFan, number> = { auto: 0, low: 1, med: 2, high: 3 };

export function greeBytes(s: AcState, a: AcAction): number[] {
  const on = a !== "off" && s.power;
  const t = s.mode === "auto" ? 25 : clampT(s.temp, 16, 30);
  const fan = s.mode === "dry" ? 1 : GR_FAN[s.fan];
  const b = [0, 0, 0, 0, 0, 0, 0, 0];
  b[0] = GR_MODE[s.mode] | (on ? 0x08 : 0) | (fan << 4) | (s.swing ? 0x40 : 0);
  b[1] = (t - 16) & 0x0f;
  b[2] = 0x20 | (on ? 0x40 : 0); // Light + ModelA (YAW1F)
  b[3] = 0x50;
  b[4] = s.swing ? 0x01 : 0x00; // SwingV auto / dernière position
  b[5] = 0x20;
  b[6] = 0;
  let sum = 10;
  for (let i = 0; i < 4; i++) sum += b[i] & 0x0f;
  for (let i = 4; i < 7; i++) sum += b[i] >> 4;
  b[7] = (sum & 0x0f) << 4;
  return b;
}
const gree = (s: AcState, a: AcAction): IrFrame => {
  const b = greeBytes(s, a);
  const p = new Pulses();
  p.bytes(b.slice(0, 4), GR, false, true, false);
  p.bits(0b010, 3, GR, false);
  p.mark(GR.footMark); p.space(GR.gap);
  p.bytes(b.slice(4), GR, false, false, true);
  return frame(38000, p, hexBytes(b));
};

/* ───────── Mitsubishi Electric 144 bits ───────── */
const MI: Timing = { hdrMark: 3400, hdrSpace: 1750, bitMark: 450, one: 1300, zero: 420, footMark: 440, gap: 15500 };
const MI_MODE: Record<AcMode, number> = { auto: 0b100, cool: 0b011, dry: 0b010, heat: 0b001, fan: 0b111 };
const MI_B8: Record<AcMode, number> = { auto: 0x30, heat: 0x30, cool: 0x36, dry: 0x32, fan: 0x37 };
const MI_FAN: Record<AcFan, number> = { auto: 0, low: 1, med: 2, high: 3 };

export function mitsubishiBytes(s: AcState, a: AcAction): number[] {
  const on = a !== "off" && s.power;
  const b = [0x23, 0xcb, 0x26, 0x01, 0x00, 0x20, 0x08, 0x06, 0x30, 0x45, 0x67, 0, 0, 0, 0, 0, 0, 0];
  b[5] = on ? 0x20 : 0x00;
  b[6] = MI_MODE[s.mode] << 3;
  b[7] = (clampT(s.temp, 16, 31) - 16) & 0x0f;
  b[8] = MI_B8[s.mode];
  const fan = MI_FAN[s.fan];
  b[9] = (fan === 0 ? 0x80 : fan) | ((s.swing ? 7 : 0) << 3) | 0x40;
  b[17] = sumBytes(b, 0, 17);
  return b;
}
const mitsubishi = (s: AcState, a: AcAction): IrFrame => {
  const b = mitsubishiBytes(s, a);
  const p = new Pulses();
  for (let r = 0; r < 2; r++) p.bytes(b, MI, false);
  return frame(38000, p, hexBytes(b));
};

/* ───────── Daikin ARC (280 bits) ───────── */
const DK: Timing = { hdrMark: 3650, hdrSpace: 1623, bitMark: 428, one: 1280, zero: 428, footMark: 428, gap: 428 + 29000 };
const DK_MODE: Record<AcMode, number> = { auto: 0, dry: 2, cool: 3, heat: 4, fan: 6 };
const DK_FAN: Record<AcFan, number> = { auto: 0xa, low: 3, med: 5, high: 6 };

export function daikinBytes(s: AcState, a: AcAction): number[] {
  const on = a !== "off" && s.power;
  const b: number[] = Array.from({ length: 35 }, () => 0);
  b[0] = 0x11; b[1] = 0xda; b[2] = 0x27; b[4] = 0xc5;
  b[8] = 0x11; b[9] = 0xda; b[10] = 0x27; b[12] = 0x42;
  b[16] = 0x11; b[17] = 0xda; b[18] = 0x27;
  b[21] = (on ? 1 : 0) | 0x08 | (DK_MODE[s.mode] << 4);
  b[22] = s.mode === "dry" ? 0xc0 : s.mode === "fan" ? 25 * 2 : clampT(s.temp, 10, 32) * 2;
  b[24] = (s.swing ? 0x0f : 0) | (DK_FAN[s.fan] << 4);
  b[27] = 0x06; b[28] = 0x60; b[31] = 0xc0;
  b[7] = sumBytes(b, 0, 7);
  b[15] = sumBytes(b, 8, 15);
  b[34] = sumBytes(b, 16, 34);
  return b;
}
const daikin = (s: AcState, a: AcAction): IrFrame => {
  const b = daikinBytes(s, a);
  const p = new Pulses();
  p.bits(0, 5, DK, false);
  p.mark(DK.footMark); p.space(DK.gap);
  p.bytes(b.slice(0, 8), DK, false);
  p.bytes(b.slice(8, 16), DK, false);
  p.bytes(b.slice(16), DK, false);
  return frame(38000, p, hexBytes(b));
};

/* ───────── Fujitsu ARRAH2E ───────── */
const FJ: Timing = { hdrMark: 3324, hdrSpace: 1574, bitMark: 448, one: 1182, zero: 390, footMark: 448, gap: 8100 };
const FJ_MODE: Record<AcMode, number> = { auto: 0, cool: 1, dry: 2, fan: 3, heat: 4 };
const FJ_FAN: Record<AcFan, number> = { auto: 0, high: 1, med: 2, low: 3 };

export function fujitsuBytes(s: AcState, a: AcAction): number[] {
  const head = [0x14, 0x63, 0x00, 0x10, 0x10];
  if (a === "off" || !s.power) return [...head, 0x02, 0xfd];
  if (a === "swing") return [...head, 0x6d, 0x92];
  const b = [...head, 0xfe, 9, 0x30, 0, 0, 0, 0, 0, 0, 0x20, 0];
  b[8] = 1 | (((clampT(s.temp, 16, 30) - 16) * 4) << 2);
  b[9] = FJ_MODE[s.mode];
  b[10] = FJ_FAN[s.fan] | ((s.swing ? 1 : 0) << 4);
  b[15] = (0 - sumBytes(b, 7, 15)) & 0xff;
  return b;
}
const fujitsu = (s: AcState, a: AcAction): IrFrame => {
  const b = fujitsuBytes(s, a);
  const p = new Pulses();
  p.bytes(b, FJ, false);
  return frame(38000, p, hexBytes(b));
};

/* ───────── LG 28 bits (LG et LG2) ───────── */
const LG1: Timing = { hdrMark: 8500, hdrSpace: 4250, bitMark: 550, one: 1600, zero: 550, footMark: 550, gap: 39750 };
const LG2: Timing = { hdrMark: 3200, hdrSpace: 9900, bitMark: 480, one: 1600, zero: 550, footMark: 480, gap: 39750 };
const LG_MODE: Record<AcMode, number> = { cool: 0, dry: 1, fan: 2, auto: 3, heat: 4 };
const LG_FAN: Record<AcFan, number> = { low: 1, med: 2, high: 4, auto: 5 };

export function lgValue(s: AcState, a: AcAction): number {
  if (a === "off" || !s.power) return 0x88c0051;
  if (a === "swing") return s.swing ? 0x8813149 : 0x881315a;
  const t = clampT(s.temp, 16, 30) - 15;
  const v = (0x88 << 20) | (LG_MODE[s.mode] << 12) | (t << 8) | (LG_FAN[s.fan] << 4);
  let sum = 0;
  for (let i = 1; i <= 4; i++) sum += (v >> (i * 4)) & 0xf; // 4 quartets au-dessus du checksum
  return v | (sum & 0xf);
}
const lgEnc = (t: Timing) => (s: AcState, a: AcAction): IrFrame => {
  const v = lgValue(s, a);
  const p = new Pulses();
  p.mark(t.hdrMark); p.space(t.hdrSpace);
  p.bits(v, 28, t, true);
  p.mark(t.footMark); p.space(t.gap);
  return frame(38000, p, "0x" + v.toString(16).toUpperCase().padStart(7, "0"));
};

/* ───────── Samsung AC (112 / 168 bits) ───────── */
const SG: Timing = { hdrMark: 3086, hdrSpace: 8864, bitMark: 586, one: 1432, zero: 436, footMark: 586, gap: 2886 };
const SG_MODE: Record<AcMode, number> = { auto: 0, cool: 1, dry: 2, fan: 3, heat: 4 };
const SG_FAN: Record<AcFan, number> = { auto: 0, low: 2, med: 4, high: 5 };
const SG_ON = [0x02, 0x92, 0x0f, 0x00, 0x00, 0x00, 0xf0, 0x01, 0xd2, 0x0f, 0x00, 0x00, 0x00, 0x00, 0x01, 0xe2, 0xfe, 0x71, 0x80, 0x11, 0xf0];
const SG_OFF = [0x02, 0xb2, 0x0f, 0x00, 0x00, 0x00, 0xc0, 0x01, 0xd2, 0x0f, 0x00, 0x00, 0x00, 0x00, 0x01, 0x02, 0xff, 0x71, 0x80, 0x11, 0xc0];

const sgSectionSum = (b: number[], o: number) => {
  let sum = popcount(b[o]) + popcount(b[o + 1] & 0x0f) + popcount(b[o + 2] >> 4);
  for (let i = 3; i < 7; i++) sum += popcount(b[o + i]);
  return (sum ^ 0xff) & 0xff;
};
export function samsungBytes(s: AcState): number[] {
  const b = [0x02, 0x92, 0x0f, 0x00, 0x00, 0x00, 0xf0, 0x01, 0x02, 0xae, 0x71, 0x00, 0x15, 0xf0];
  b[9] = (b[9] & 0x8f) | ((s.swing ? 0b010 : 0b111) << 4);
  b[11] = (b[11] & 0x0f) | (((s.mode === "auto" ? 25 : clampT(s.temp, 16, 30)) - 16) << 4);
  const fan = s.mode === "auto" ? 6 : SG_FAN[s.fan];
  b[12] = (b[12] & 0x81) | (fan << 1) | (SG_MODE[s.mode] << 4);
  for (let o = 0; o < 14; o += 7) {
    const cs = sgSectionSum(b, o);
    b[o + 1] = (b[o + 1] & 0x0f) | ((cs & 0x0f) << 4);
    b[o + 2] = (b[o + 2] & 0xf0) | (cs >> 4);
  }
  return b;
}
const sgSend = (p: Pulses, b: number[]) => {
  p.mark(690); p.space(17844);
  for (let o = 0; o < b.length; o += 7) p.bytes(b.slice(o, o + 7), SG, false);
  p.space(100000 - SG.gap);
};
const samsung = (s: AcState, a: AcAction): IrFrame => {
  const p = new Pulses();
  if (a === "off" || !s.power) { sgSend(p, SG_OFF); return frame(38000, p, hexBytes(SG_OFF)); }
  const b = samsungBytes(s);
  sgSend(p, b);
  return frame(38000, p, hexBytes(b));
};
/** Trame étendue de mise en marche (envoyée avant l'état à l'allumage). */
const samsungOn = (s: AcState, a: AcAction): IrFrame => {
  if (a !== "state" || !s.power) return samsung(s, a);
  const p = new Pulses();
  sgSend(p, SG_ON);
  const b = samsungBytes(s);
  sgSend(p, b);
  return frame(38000, p, hexBytes(b));
};

/* ───────── Toshiba (72 bits) ───────── */
const TS: Timing = { hdrMark: 4400, hdrSpace: 4300, bitMark: 580, one: 1600, zero: 490, footMark: 580, gap: 7400 };
const TS_MODE: Record<AcMode, number> = { auto: 0, cool: 1, dry: 2, heat: 3, fan: 4 };
const TS_FAN: Record<AcFan, number> = { auto: 0, low: 2, med: 4, high: 6 };
const xorFix = (b: number[]) => { let x = 0; for (let i = 0; i < b.length - 1; i++) x ^= b[i]; b[b.length - 1] = x; return b; };

export function toshibaBytes(s: AcState, a: AcAction): number[] {
  if (a === "swing") {
    // Trame courte (56 bits) : bascule de l'oscillation, consigne au minimum.
    return xorFix([0xf2, 0x0d, 0x01, 0xfe, 0x21, s.swing ? 0x01 : 0x02, 0]);
  }
  const on = a !== "off" && s.power;
  const b = [0xf2, 0x0d, 0x03, 0xfc, 0x01, 0, 0, 0, 0];
  b[5] = (clampT(s.temp, 17, 30) - 17) << 4;
  b[6] = (on ? TS_MODE[s.mode] : 7) | (TS_FAN[s.fan] << 5);
  return xorFix(b);
}
const toshiba = (s: AcState, a: AcAction): IrFrame => {
  const b = toshibaBytes(s, a);
  const p = new Pulses();
  for (let r = 0; r < 2; r++) p.bytes(b, TS, true);
  return frame(38000, p, hexBytes(b));
};

/* ───────── Panasonic AC (216 bits) ───────── */
const PN: Timing = { hdrMark: 3456, hdrSpace: 1728, bitMark: 432, one: 1296, zero: 432, footMark: 432, gap: 10000 };
const PN_MODE: Record<AcMode, number> = { auto: 0, dry: 2, cool: 3, heat: 4, fan: 6 };
const PN_FAN: Record<AcFan, number> = { auto: 7, low: 1, med: 2, high: 3 };

export function panasonicBytes(s: AcState, a: AcAction): number[] {
  const b = [0x02, 0x20, 0xe0, 0x04, 0x00, 0x00, 0x00, 0x06, 0x02, 0x20, 0xe0, 0x04, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x0e, 0xe0, 0x00, 0x00, 0x81, 0x00, 0x00, 0x00];
  const on = a !== "off" && s.power;
  const t = s.mode === "fan" ? 27 : clampT(s.temp, 16, 30);
  b[13] = (PN_MODE[s.mode] << 4) | (on ? 1 : 0);
  b[14] = (t << 1) & 0x3e;
  b[16] = ((PN_FAN[s.fan] + 3) << 4) | (s.swing ? 0x0f : 0x03);
  b[26] = sumBytes(b, 0, 26, 0xf4);
  return b;
}
const panasonic = (s: AcState, a: AcAction): IrFrame => {
  const b = panasonicBytes(s, a);
  const p = new Pulses();
  p.bytes(b.slice(0, 8), PN, false);
  p.bytes(b.slice(8), { ...PN, gap: 100000 }, false);
  return frame(36700, p, hexBytes(b));
};

/* ───────── Haier (HSU-07HMC203, 72 bits) ───────── */
const HR: Timing = { hdrMark: 3000, hdrSpace: 4300, bitMark: 520, one: 1650, zero: 650, footMark: 520, gap: 150000 };
const HR_MODE: Record<AcMode, number> = { auto: 0, cool: 1, dry: 2, heat: 3, fan: 4 };
const HR_FAN: Record<AcFan, number> = { auto: 0, low: 3, med: 2, high: 1 };

export function haierBytes(s: AcState, a: AcAction): number[] {
  const on = a !== "off" && s.power;
  const cmd = !on ? 0b0000 : a === "swing" ? 0b1101 : 0b0001;
  const b = [0xa5, 0, 0, 0, 0, 0, 0, 0, 0];
  b[1] = cmd | ((clampT(s.temp, 16, 30) - 16) << 4);
  b[2] = 0x20 | ((s.swing ? 0b11 : 0b00) << 6);
  b[4] = 12; // OffHours par défaut
  b[5] = HR_FAN[s.fan] << 6;
  b[6] = HR_MODE[s.mode] << 5;
  b[8] = sumBytes(b, 0, 8);
  return b;
}
const haier = (s: AcState, a: AcAction): IrFrame => {
  const b = haierBytes(s, a);
  const p = new Pulses();
  p.mark(HR.hdrMark); p.space(HR.hdrMark);
  p.bytes(b, HR, true);
  return frame(38000, p, hexBytes(b));
};


export const PROTOCOLS: IrProtocol[] = [
  { id: "coolix", name: "COOLIX (Midea / clones)", status: "beta", minTemp: 17, maxTemp: 30, encode: coolix, note: "Protocole 24 bits des télécommandes Midea (anciennes séries), Senville, Kinghome, Comfort Aire, Beko, TCL et clones. Oscillation : trame bascule." },
  { id: "midea48", name: "Midea 48 bits (RG57/RG66)", status: "beta", minTemp: 17, maxTemp: 30, encode: midea48, note: "Télécommandes Midea, Senville, Carrier/Bryant (OEM Midea), Pioneer, Kaysun. Trame 48 bits envoyée puis répétée inversée. Oscillation : trame bascule." },
  { id: "gree", name: "Gree (YAW1F / YBOF)", status: "beta", minTemp: 16, maxTemp: 30, encode: gree, note: "Gree, Tosot, Cooper&Hunter, Lennox (OEM Gree), Sinclair. 64 bits en deux blocs. En auto, consigne imposée à 25 °C." },
  { id: "mitsubishi", name: "Mitsubishi Electric (144 bits)", status: "beta", minTemp: 16, maxTemp: 31, encode: mitsubishi, note: "Gammes M et P (MSZ, SLZ, PKA, MSY). Trame de 18 octets envoyée deux fois. Oscillation : volet en mode « swing »." },
  { id: "daikin", name: "Daikin ARC (280 bits)", status: "beta", minTemp: 10, maxTemp: 32, encode: daikin, note: "Télécommandes ARC433/ARC4xx. Trame 35 octets en 3 sections. Oscillation verticale intégrée à l'état." },
  { id: "fujitsu", name: "Fujitsu AR-RAH2E", status: "beta", minTemp: 16, maxTemp: 30, encode: fujitsu, note: "Fujitsu / General (AR-RAH2E, AR-REB, AR-RY). Arrêt et oscillation par codes courts dédiés." },
  { id: "lg", name: "LG (28 bits)", status: "beta", minTemp: 16, maxTemp: 30, encode: lgEnc(LG1), note: "LG Art Cool / Standard (AKB). Si l'unité ne réagit pas, essayez « LG2 »." },
  { id: "lg2", name: "LG2 (28 bits, en-tête court)", status: "beta", minTemp: 16, maxTemp: 30, encode: lgEnc(LG2), note: "Variante LG des télécommandes AKB récentes (en-tête 3,2 ms / 9,9 ms). Mêmes données que LG." },
  { id: "samsung", name: "Samsung AC (112 bits)", status: "beta", minTemp: 16, maxTemp: 30, encode: samsungOn, note: "Wind-Free et standard (ARH). À la mise en marche, la trame étendue « ON » est envoyée avant l'état." },
  { id: "toshiba", name: "Toshiba AC (72 bits)", status: "beta", minTemp: 17, maxTemp: 30, encode: toshiba, note: "Toshiba / Carrier (WH-TA, WC-L). Trame envoyée deux fois ; oscillation par trame courte." },
  { id: "panasonic", name: "Panasonic AC (216 bits)", status: "beta", minTemp: 16, maxTemp: 30, encode: panasonic, note: "Télécommandes A75C (modèles DKE/JKE/NKE). Porteuse 36,7 kHz. En ventilation, consigne fixée à 27 °C." },
  { id: "haier", name: "Haier (HSU, 72 bits)", status: "beta", minTemp: 16, maxTemp: 30, encode: haier, note: "Haier HSU / Daichi. Les modèles YR-W02 récents utilisent un autre protocole (Haier 176 bits), non pris en charge." },
];

export const protocolById = (id?: string) => PROTOCOLS.find((p) => p.id === id);

/** Marque → protocoles probables (le premier est suggéré). */
export const BRAND_PROTOCOLS: Record<string, string[]> = {
  mitsubishi: ["mitsubishi"],
  daikin: ["daikin"],
  fujitsu: ["fujitsu"],
  general: ["fujitsu"],
  lg: ["lg", "lg2"],
  samsung: ["samsung"],
  gree: ["gree"],
  tosot: ["gree"],
  cooperhunter: ["gree"],
  lennox: ["gree", "midea48"],
  midea: ["midea48", "coolix"],
  senville: ["midea48", "coolix"],
  carrier: ["midea48", "coolix"],
  bryant: ["midea48", "coolix"],
  kinghome: ["coolix", "midea48"],
  toshiba: ["toshiba", "midea48", "coolix"],
  panasonic: ["panasonic"],
  tcl: ["coolix", "midea48"],
  haier: ["haier"],
  sinclair: ["gree"],
  kaysun: ["midea48", "coolix"],
};

/** Applications officielles Wi-Fi / Bluetooth par marque (recherche Play Store). */
export const BRAND_APPS: Record<string, { app: string; link: "wifi" | "ble" | "both"; note?: string }[]> = {
  mitsubishi: [{ app: "Kumo Cloud", link: "wifi", note: "Adaptateur Wi-Fi PAC-USWHS002 / interface Kumo requis" }, { app: "MELCloud", link: "wifi", note: "Europe / international" }],
  daikin: [{ app: "Daikin Onecta", link: "wifi" }, { app: "Daikin One Home", link: "wifi", note: "Thermostats Daikin One" }],
  fujitsu: [{ app: "FGLair", link: "wifi", note: "Module Wi-Fi intégré ou adaptateur" }],
  general: [{ app: "FGLair", link: "wifi" }],
  lg: [{ app: "LG ThinQ", link: "wifi" }],
  samsung: [{ app: "SmartThings", link: "wifi" }],
  gree: [{ app: "Gree+", link: "wifi" }],
  tosot: [{ app: "Gree+", link: "wifi" }],
  cooperhunter: [{ app: "EWPE Smart", link: "wifi" }, { app: "Gree+", link: "wifi" }],
  midea: [{ app: "MSmartHome", link: "both", note: "Jumelage Bluetooth à la configuration sur certains modèles" }, { app: "NetHome Plus", link: "wifi" }],
  senville: [{ app: "MSmartHome", link: "both" }, { app: "NetHome Plus", link: "wifi" }],
  carrier: [{ app: "Carrier Home", link: "wifi" }, { app: "MSmartHome", link: "wifi", note: "Mini-splits OEM Midea" }],
  bryant: [{ app: "Bryant Home", link: "wifi" }],
  toshiba: [{ app: "Toshiba Home AC Control", link: "wifi" }],
  panasonic: [{ app: "Panasonic Comfort Cloud", link: "wifi" }],
  hitachi: [{ app: "airCloud Home", link: "wifi" }],
  bosch: [{ app: "Bosch HomeCom Easy", link: "wifi" }],
  lennox: [{ app: "Lennox", link: "wifi", note: "Thermostats S30 / S40" }],
  trane: [{ app: "Trane Home", link: "wifi" }],
  americanstandard: [{ app: "American Standard Home", link: "wifi" }],
  goodman: [{ app: "Daikin One Home", link: "wifi" }],
  amana: [{ app: "Daikin One Home", link: "wifi" }],
  rheem: [{ app: "Rheem EcoNet", link: "wifi" }],
  ruud: [{ app: "Rheem EcoNet", link: "wifi" }],
  tcl: [{ app: "TCL Home", link: "wifi" }],
  kinghome: [{ app: "Smart Life", link: "both" }],
  haier: [{ app: "hOn", link: "wifi" }, { app: "Haier Smart Air 2", link: "wifi" }],
  sinclair: [{ app: "Sinclair Smart", link: "wifi" }],
  kaysun: [{ app: "MSmartHome", link: "both" }],
};

export const playSearchUrl = (app: string) => `https://play.google.com/store/search?q=${encodeURIComponent(app)}&c=apps`;
