package expo.modules.irblaster

import android.content.Context
import android.hardware.ConsumerIrManager
import expo.modules.kotlin.exception.CodedException
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class IrBlasterModule : Module() {
  private val ir: ConsumerIrManager?
    get() = appContext.reactContext?.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager

  override fun definition() = ModuleDefinition {
    Name("IrBlaster")

    Function("hasEmitter") {
      ir?.hasIrEmitter() == true
    }

    Function("frequencies") {
      ir?.carrierFrequencies?.map { listOf(it.minFrequency, it.maxFrequency) } ?: emptyList<List<Int>>()
    }

    AsyncFunction("transmit") { frequency: Int, pattern: List<Int> ->
      val m = ir ?: throw CodedException("ERR_NO_IR", "Service IR indisponible", null)
      if (!m.hasIrEmitter()) throw CodedException("ERR_NO_EMITTER", "Aucun émetteur IR sur cet appareil", null)
      m.transmit(frequency, pattern.toIntArray())
    }
  }
}
