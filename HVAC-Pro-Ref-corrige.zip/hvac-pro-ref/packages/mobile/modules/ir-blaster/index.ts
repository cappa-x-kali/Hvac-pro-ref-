import { requireOptionalNativeModule } from "expo";

export type IrBlasterNative = {
  hasEmitter(): boolean;
  frequencies(): number[][];
  transmit(frequency: number, pattern: number[]): Promise<void>;
};

/** null sur le web, iOS, Expo Go ou tout build sans le module natif. */
export const IrBlaster = requireOptionalNativeModule<IrBlasterNative>("IrBlaster");
