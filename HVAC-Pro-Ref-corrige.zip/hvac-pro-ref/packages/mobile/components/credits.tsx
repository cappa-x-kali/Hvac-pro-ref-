import { View } from "react-native";
import { useColors } from "../hooks/use-colors";
import { Fonts } from "../constants/theme";
import { T } from "./ui";

/** Mention « Création et conception : Jean Marion » réutilisable en pied de page. */
export function CreditFooter({ extra }: { extra?: string }) {
  const c = useColors();
  return (
    <View style={{ alignItems: "center", gap: 3, paddingVertical: 22, marginTop: 6 }}>
      <View style={{ width: 36, height: 3, borderRadius: 2, backgroundColor: c.primary + "55", marginBottom: 8 }} />
      <T v="small" style={{ fontSize: 12, textAlign: "center" }}>
        Création et conception · <T v="small" color={c.foreground} style={{ fontSize: 12, fontFamily: Fonts.bodyBold }}>Jean Marion</T>
      </T>
      <T v="small" style={{ fontSize: 11, opacity: 0.75, textAlign: "center" }}>Crédits · Cappa-X Tools{extra ? ` · ${extra}` : ""}</T>
    </View>
  );
}
