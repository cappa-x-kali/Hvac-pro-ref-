import type { ComponentType } from "react";
import type { Ionicons } from "@expo/vector-icons";
import { ChargeTool, NitrogenTool, PTTool, RecoveryTool, RefsTool, SHSCTool, TargetSHTool, VacuumTool } from "./refrig";
import { CFMTool, CondensateTool, DeltaTTool, DuctTool, LoadTool, PsychroTool } from "./air";
import { AmpsTool, CapTool, GasTool, ImbalanceTool, OhmTool, WireTool } from "./elec";
import { ConvTool, EffTool } from "./misc";
import { BtuTool } from "./btu";
import { RemoteTool } from "./remote";

export type ToolDef = { id: string; title: string; desc: string; icon: keyof typeof Ionicons.glyphMap; cat: string; C: ComponentType };

export const TOOL_CATS = [
  { id: "ref", label: "Réfrigération" },
  { id: "air", label: "Charge & air" },
  { id: "elec", label: "Électricité" },
  { id: "gen", label: "Général & gaz" },
  { id: "ctl", label: "Contrôle" },
];

export const TOOLS: ToolDef[] = [
  { id: "pt", title: "Tableau P/T", desc: "Pression / saturation R22 · R410A · R32 · R454B", icon: "thermometer", cat: "ref", C: PTTool },
  { id: "shsc", title: "Surchauffe / sous-refroidissement", desc: "SH et SC depuis pressions et températures", icon: "speedometer", cat: "ref", C: SHSCTool },
  { id: "targetsh", title: "Surchauffe cible", desc: "Orifice fixe : BH intérieur + BS extérieur", icon: "locate", cat: "ref", C: TargetSHTool },
  { id: "charge", title: "Charge additionnelle", desc: "Ajout selon longueur de ligne", icon: "git-commit", cat: "ref", C: ChargeTool },
  { id: "vacuum", title: "Vide (microns)", desc: "Test de décroissance et diagnostic", icon: "arrow-down-circle", cat: "ref", C: VacuumTool },
  { id: "nitrogen", title: "Test à l'azote", desc: "Pression corrigée pour la température", icon: "flask", cat: "ref", C: NitrogenTool },
  { id: "recovery", title: "Récupération (80 %)", desc: "Poids max d'un cylindre", icon: "battery-half", cat: "ref", C: RecoveryTool },
  { id: "refs", title: "Fiches réfrigérants", desc: "PRP, huile, sécurité, couleur cylindre", icon: "information-circle", cat: "ref", C: RefsTool },
  { id: "btu", title: "Surface → BTU", desc: "Superficie pi²/m² → format de thermopompe", icon: "resize", cat: "air", C: BtuTool },
  { id: "load", title: "Charge BTU d'une pièce", desc: "Estimation clim. et chauffage (Québec)", icon: "cube", cat: "air", C: LoadTool },
  { id: "deltat", title: "Delta T", desc: "ΔT et capacité sensible", icon: "swap-vertical", cat: "air", C: DeltaTTool },
  { id: "cfm", title: "Débit d'air (CFM)", desc: "Par tonnage ou hausse de température", icon: "aperture", cat: "air", C: CFMTool },
  { id: "duct", title: "Dimensionnement conduits", desc: "Friction égale / vitesse, rond / rectangulaire", icon: "grid", cat: "air", C: DuctTool },
  { id: "psy", title: "Point de rosée / psychro", desc: "Rosée, bulbe humide, enthalpie", icon: "water", cat: "air", C: PsychroTool },
  { id: "condensate", title: "Condensat", desc: "Débit d'eau, drain et pompe", icon: "rainy", cat: "air", C: CondensateTool },
  { id: "ohm", title: "Loi d'Ohm", desc: "V · I · R · P", icon: "flash", cat: "elec", C: OhmTool },
  { id: "amps", title: "Ampérage", desc: "Mono / triphasé depuis W ou BTU", icon: "pulse", cat: "elec", C: AmpsTool },
  { id: "wire", title: "Fil & disjoncteur", desc: "MCA/MOCP, calibre, chute de tension", icon: "git-network", cat: "elec", C: WireTool },
  { id: "cap", title: "Condensateur µF", desc: "Vérification en marche", icon: "battery-charging", cat: "elec", C: CapTool },
  { id: "imbalance", title: "Déséquilibre triphasé", desc: "Tension et courant", icon: "stats-chart", cat: "elec", C: ImbalanceTool },
  { id: "conv", title: "Conversions", desc: "Temp., pression, puissance, débit…", icon: "repeat", cat: "gen", C: ConvTool },
  { id: "eff", title: "SEER / COP & coût", desc: "Efficacité et coût d'opération annuel", icon: "cash", cat: "gen", C: EffTool },
  { id: "gas", title: "Débit de gaz", desc: "Chronométrage du compteur", icon: "flame", cat: "gen", C: GasTool },
  { id: "remote", title: "Télécommande IR / Wi-Fi", desc: "Manette virtuelle par marque + apps officielles", icon: "game-controller", cat: "ctl", C: RemoteTool },
];

export const toolById = (id?: string) => TOOLS.find((t) => t.id === id);
