import { useState } from "react";
import { View } from "react-native";
import { useColors } from "../../hooks/use-colors";
import { Card, Chip, ChipRow, Result, Row, Segmented, T } from "../ui";
import { Fonts } from "../../constants/theme";
import { Box, FieldRow, Formula, Note, NumField, fmt, num, ok } from "./common";

type Cat = { id: string; label: string; units: { id: string; label: string; f: number }[] };
// facteur = valeur de l'unité exprimée dans l'unité de base
const CATS: Cat[] = [
  { id: "p", label: "Pression", units: [
    { id: "psi", label: "psi", f: 6.894757 }, { id: "kpa", label: "kPa", f: 1 }, { id: "bar", label: "bar", f: 100 },
    { id: "inhg", label: "po Hg", f: 3.38639 }, { id: "inwc", label: "po CE", f: 0.249089 }, { id: "pa", label: "Pa", f: 0.001 },
    { id: "micron", label: "microns", f: 0.000133322 }, { id: "mpa", label: "MPa", f: 1000 },
  ] },
  { id: "pow", label: "Puissance", units: [
    { id: "btu", label: "BTU/h", f: 1 }, { id: "kw", label: "kW", f: 3412.14 }, { id: "w", label: "W", f: 3.41214 },
    { id: "ton", label: "tonnes réfrig.", f: 12000 }, { id: "hp", label: "HP", f: 2544.43 }, { id: "mbh", label: "MBH", f: 1000 },
  ] },
  { id: "len", label: "Longueur", units: [
    { id: "m", label: "m", f: 1 }, { id: "ft", label: "pi", f: 0.3048 }, { id: "in", label: "po", f: 0.0254 }, { id: "mm", label: "mm", f: 0.001 }, { id: "cm", label: "cm", f: 0.01 },
  ] },
  { id: "mass", label: "Masse", units: [
    { id: "kg", label: "kg", f: 1 }, { id: "lb", label: "lb", f: 0.45359237 }, { id: "oz", label: "oz", f: 0.0283495 }, { id: "g", label: "g", f: 0.001 },
  ] },
  { id: "flow", label: "Débit d'air", units: [
    { id: "cfm", label: "CFM", f: 1 }, { id: "ls", label: "L/s", f: 2.11888 }, { id: "m3h", label: "m³/h", f: 0.588578 }, { id: "m3s", label: "m³/s", f: 2118.88 },
  ] },
  { id: "vol", label: "Volume", units: [
    { id: "l", label: "L", f: 1 }, { id: "galus", label: "gal US", f: 3.78541 }, { id: "galimp", label: "gal imp.", f: 4.54609 }, { id: "ft3", label: "pi³", f: 28.3168 }, { id: "m3", label: "m³", f: 1000 },
  ] },
  { id: "area", label: "Surface", units: [
    { id: "ft2", label: "pi²", f: 1 }, { id: "m2", label: "m²", f: 10.7639 }, { id: "in2", label: "po²", f: 1 / 144 },
  ] },
  { id: "energy", label: "Énergie", units: [
    { id: "kwh", label: "kWh", f: 1 }, { id: "btu", label: "BTU", f: 1 / 3412.14 }, { id: "mj", label: "MJ", f: 1 / 3.6 }, { id: "therm", label: "therm", f: 29.3071 },
  ] },
];

export function ConvTool() {
  const c = useColors();
  const [cat, setCat] = useState("temp");
  const [from, setFrom] = useState<string>("");
  const [v, setV] = useState("");
  const x = num(v);
  const isTemp = cat === "temp";
  const def = CATS.find((k) => k.id === cat);
  const fromId = from || (isTemp ? "c" : def?.units[0].id ?? "");

  let rows: { label: string; val: number }[] = [];
  if (isTemp && ok(x)) {
    const cV = fromId === "c" ? x : fromId === "f" ? ((x - 32) * 5) / 9 : x - 273.15;
    rows = [{ label: "°C", val: cV }, { label: "°F", val: (cV * 9) / 5 + 32 }, { label: "K", val: cV + 273.15 }];
  } else if (def && ok(x)) {
    const base = x * (def.units.find((u) => u.id === fromId)?.f ?? 1);
    rows = def.units.map((u) => ({ label: u.label, val: base / u.f }));
  }
  const units = isTemp ? [{ id: "c", label: "°C" }, { id: "f", label: "°F" }, { id: "k", label: "K" }] : def?.units ?? [];
  return (
    <>
      <View style={{ marginTop: 16 }}>
        <ChipRow>
          <Chip label="Température" active={isTemp} onPress={() => { setCat("temp"); setFrom(""); }} />
          {CATS.map((k) => <Chip key={k.id} label={k.label} active={cat === k.id} onPress={() => { setCat(k.id); setFrom(""); }} />)}
        </ChipRow>
      </View>
      <Box>
        <NumField label="Valeur" value={v} onChange={setV} suffix={units.find((u) => u.id === fromId)?.label} />
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
          {units.map((u) => <Chip key={u.id} label={u.label} active={fromId === u.id} onPress={() => setFrom(u.id)} />)}
        </View>
        <Card style={{ padding: 0, overflow: "hidden" }}>
          {rows.length ? rows.map((r, i) => (
            <View key={r.label} style={{ flexDirection: "row", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 12, backgroundColor: i % 2 ? c.muted : "transparent" }}>
              <T v="small" style={{ fontFamily: Fonts.bodyBold }}>{r.label}</T>
              <T style={{ fontFamily: Fonts.display }}>{fmt(r.val, Math.abs(r.val) < 1 ? 5 : 3)}</T>
            </View>
          )) : <T v="small" style={{ padding: 16 }}>Entrez une valeur pour voir toutes les conversions.</T>}
        </Card>
        {cat === "p" ? <Note>Pression manométrique (psig) = absolue (psia) − 14,7. 1 po Hg de vide ≈ 25 400 microns sous l'atmosphère.</Note> : null}
      </Box>
    </>
  );
}

/* ───────── Efficacité et coût ───────── */
export function EffTool() {
  const [mode, setMode] = useState<"conv" | "cost">("cost");
  const [seer, setSeer] = useState("");
  const [hspf, setHspf] = useState("");
  const [btu, setBtu] = useState("12000");
  const [hc, setHc] = useState("600");
  const [hh, setHh] = useState("1500");
  const [rate, setRate] = useState("0.085");
  const [s2, setS2] = useState("20");
  const [h2, setH2] = useState("9");
  const S = num(seer), H = num(hspf);
  const eer = ok(S) ? -0.02 * S * S + 1.12 * S : NaN;
  const B = num(btu), HC = num(hc), HH = num(hh), R = num(rate), SS = num(s2), HS = num(h2);
  const kwhC = ok(B, HC, SS) && SS > 0 ? (B * HC) / (SS * 1000) : NaN;
  const kwhH = ok(B, HH, HS) && HS > 0 ? (B * HH) / (HS * 1000) : NaN;
  const kwhBase = ok(B, HH) ? (B * HH) / 3412 : NaN; // plinthes électriques COP 1
  return (
    <Box>
      <Segmented value={mode} onChange={setMode} options={[{ value: "cost", label: "Coût d'opération" }, { value: "conv", label: "Conversions SEER/COP" }]} />
      {mode === "conv" ? (
        <>
          <FieldRow>
            <NumField label="SEER" value={seer} onChange={setSeer} />
            <NumField label="HSPF" value={hspf} onChange={setHspf} />
          </FieldRow>
          <Row>
            <Result label="SEER2 estimé" value={fmt(S * 0.95, 1)} sub="approximation, pas conversion certifiée" />
            <Result label="EER (estimé)" value={fmt(eer, 1)} tone="accent" />
          </Row>
          <Row>
            <Result label="COP froid" value={fmt(eer / 3.412, 2)} tone="success" sub="EER ÷ 3,412" />
            <Result label="HSPF2 estimé" value={fmt(H * 0.85, 1)} tone="warning" sub="approximation, pas conversion certifiée" />
          </Row>
          <Row>
            <Result label="COP saisonnier chauffage" value={fmt(H / 3.412, 2)} sub="HSPF ÷ 3,412" />
          </Row>
          <Note tone="warn">Conversions approximatives (méthodes de test différentes). Ne les utilisez pas pour comparer officiellement des appareils ni pour une demande de programme; utilisez les cotes AHRI du jumelage exact.</Note>
        </>
      ) : (
        <>
          <NumField label="Capacité" value={btu} onChange={setBtu} suffix="BTU/h" />
          <FieldRow>
            <NumField label="SEER / SEER2" value={s2} onChange={setS2} />
            <NumField label="HSPF / HSPF2" value={h2} onChange={setH2} />
          </FieldRow>
          <FieldRow>
            <NumField label="Heures clim./an" value={hc} onChange={setHc} suffix="h" />
            <NumField label="Heures chauff./an" value={hh} onChange={setHh} suffix="h" />
          </FieldRow>
          <NumField label="Tarif électricité" value={rate} onChange={setRate} suffix="$/kWh" />
          <Row>
            <Result label="Climatisation" value={ok(kwhC, R) ? `${fmt(kwhC * R, 0)} $` : "—"} sub={ok(kwhC) ? `${fmt(kwhC, 0)} kWh/an` : undefined} />
            <Result label="Chauffage" value={ok(kwhH, R) ? `${fmt(kwhH * R, 0)} $` : "—"} sub={ok(kwhH) ? `${fmt(kwhH, 0)} kWh/an` : undefined} tone="accent" />
          </Row>
          <Row>
            <Result label="Économie vs plinthes" value={ok(kwhBase, kwhH, R) ? `${fmt((kwhBase - kwhH) * R, 0)} $` : "—"} sub="Chauffage à capacité égale (COP 1)" tone="success" />
          </Row>
          <Note>Tarif par défaut ≈ moyenne Hydro-Québec tarif D — ajustez selon votre facture. Heures équivalentes à pleine charge — estimation simplifiée.</Note>
          <Formula>kWh = BTU/h × heures ÷ (SEER × 1000)</Formula>
        </>
      )}
    </Box>
  );
}
