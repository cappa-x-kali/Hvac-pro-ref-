import { type ReactNode } from "react";
import { Platform, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useStore } from "../../lib/store";
import { useColors } from "../../hooks/use-colors";
import { Card, Field, T } from "../ui";
import { cToF, fToC, kpaAbsToPsig, psigToKpaAbs } from "../../data/refrigerants";
import { loc } from "../../lib/i18n";

/** Analyse un nombre saisi (accepte la virgule). NaN si vide. */
export const num = (s: string | undefined) => {
  if (s == null) return NaN;
  const t = s.replace(",", ".").replace(/\s/g, "");
  if (t === "" || t === "-" || t === ".") return NaN;
  return Number(t);
};
export const ok = (...v: number[]) => v.every((x) => Number.isFinite(x));
export const fmt = (n: number, d = 1) =>
  Number.isFinite(n) ? n.toLocaleString(loc(), { maximumFractionDigits: d, minimumFractionDigits: 0 }) : "—";

export function useUnits() {
  const { settings } = useStore();
  const F = settings.tempUnit === "F";
  const psig = settings.pressureUnit === "psig";
  return {
    F,
    psig,
    tU: F ? "°F" : "°C",
    dU: F ? "°F" : "K",
    pU: psig ? "psig" : "kPa (rel.)",
    /** saisie utilisateur -> °C */
    toC: (v: number) => (F ? fToC(v) : v),
    /** °C -> affichage */
    fromC: (c: number) => (F ? cToF(c) : c),
    /** delta °C -> affichage */
    dFromC: (d: number) => (F ? d * 1.8 : d),
    /** saisie pression -> kPa abs */
    toKpaAbs: (v: number) => (psig ? psigToKpaAbs(v) : v + 101.325),
    /** kPa abs -> affichage */
    fromKpaAbs: (k: number) => (psig ? kpaAbsToPsig(k) : k - 101.325),
  };
}

export function Box({ children, gap = 12 }: { children: ReactNode; gap?: number }) {
  return <View style={{ paddingHorizontal: 16, marginTop: 16, gap }}>{children}</View>;
}

export function Note({ children, tone = "info" }: { children: ReactNode; tone?: "info" | "ok" | "warn" | "bad" }) {
  const c = useColors();
  const col = tone === "ok" ? c.success : tone === "warn" ? c.warning : tone === "bad" ? c.destructive : c.primary;
  const icon = tone === "ok" ? "checkmark-circle" : tone === "warn" ? "alert-circle" : tone === "bad" ? "close-circle" : "bulb";
  return (
    <View style={{ flexDirection: "row", gap: 10, padding: 12, borderRadius: 14, backgroundColor: col + "16", borderWidth: 1, borderColor: col + "33" }}>
      <Ionicons name={icon} size={18} color={col} />
      <T v="small" style={{ flex: 1, color: c.foreground }}>{children}</T>
    </View>
  );
}

export function Formula({ children }: { children: ReactNode }) {
  const c = useColors();
  return (
    <Card style={{ backgroundColor: c.muted, padding: 12 }}>
      <T v="label" style={{ marginBottom: 4 }}>Formule</T>
      <T v="mono" style={{ fontSize: 13 }}>{children}</T>
    </Card>
  );
}

export function FieldRow({ children }: { children: ReactNode }) {
  return <View style={{ flexDirection: "row", gap: 10 }}>{children}</View>;
}

export function NumField({ label, value, onChange, suffix, placeholder }: { label: string; value: string; onChange: (s: string) => void; suffix?: string; placeholder?: string }) {
  return (
    <Field
      label={label}
      value={value}
      onChangeText={onChange}
      suffix={suffix}
      placeholder={placeholder ?? "0"}
      keyboardType={Platform.OS === "ios" ? "numbers-and-punctuation" : "numeric"}
      returnKeyType="done"
    />
  );
}
