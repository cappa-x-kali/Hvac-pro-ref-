import { useState } from "react";
import { View } from "react-native";
import { useColors } from "../../hooks/use-colors";
import { Btn, Card, Chip, Result, Row, Segmented, T } from "../ui";
import { Fonts } from "../../constants/theme";
import { Box, FieldRow, Formula, Note, NumField, fmt, num, ok } from "./common";

/* ───────── Loi d'Ohm ───────── */
export function OhmTool() {
  const [v, setV] = useState("");
  const [i, setI] = useState("");
  const [r, setR] = useState("");
  const [p, setP] = useState("");
  const V = num(v), I = num(i), R = num(r), P = num(p);
  let out: { V: number; I: number; R: number; P: number } | null = null;
  if (ok(V, I) && V > 0 && I > 0) out = { V, I, R: V / I, P: V * I };
  else if (ok(V, R) && V > 0 && R > 0) out = { V, I: V / R, R, P: (V * V) / R };
  else if (ok(V, P) && V > 0 && P > 0) out = { V, I: P / V, R: (V * V) / P, P };
  else if (ok(I, R) && I > 0 && R > 0) out = { V: I * R, I, R, P: I * I * R };
  else if (ok(I, P) && I > 0 && P > 0) out = { V: P / I, I, R: P / (I * I), P };
  else if (ok(R, P) && R > 0 && P > 0) out = { V: Math.sqrt(P * R), I: Math.sqrt(P / R), R, P };
  return (
    <Box>
      <Note>Entrez deux valeurs connues : les deux autres sont calculées.</Note>
      <FieldRow>
        <NumField label="Tension" value={v} onChange={setV} suffix="V" />
        <NumField label="Courant" value={i} onChange={setI} suffix="A" />
      </FieldRow>
      <FieldRow>
        <NumField label="Résistance" value={r} onChange={setR} suffix="Ω" />
        <NumField label="Puissance" value={p} onChange={setP} suffix="W" />
      </FieldRow>
      <Row>
        <Result label="Tension" value={out ? fmt(out.V, 2) : "—"} unit="V" />
        <Result label="Courant" value={out ? fmt(out.I, 3) : "—"} unit="A" tone="accent" />
      </Row>
      <Row>
        <Result label="Résistance" value={out ? fmt(out.R, 2) : "—"} unit="Ω" tone="success" />
        <Result label="Puissance" value={out ? fmt(out.P, 1) : "—"} unit="W" sub={out ? `${fmt(out.P * 3.412, 0)} BTU/h` : undefined} tone="warning" />
      </Row>
      <Btn label="Effacer" icon="refresh" variant="ghost" onPress={() => { setV(""); setI(""); setR(""); setP(""); }} />
      <Formula>V = I × R   ·   P = V × I = I² × R = V² ÷ R</Formula>
    </Box>
  );
}

/* ───────── Ampérage ───────── */
export function AmpsTool() {
  const [mode, setMode] = useState<"W" | "BTU">("W");
  const [pw, setPw] = useState("");
  const [cop, setCop] = useState("3");
  const [volt, setVolt] = useState(240);
  const [phase, setPhase] = useState<"1" | "3">("1");
  const [pf, setPf] = useState("0.95");
  const P = num(pw), C = num(cop), F = num(pf);
  const watts = mode === "W" ? P : ok(P, C) && C > 0 ? P / 3.412 / C : NaN;
  const amps = ok(watts, F) && F > 0 ? (phase === "1" ? watts / (volt * F) : watts / (Math.sqrt(3) * volt * F)) : NaN;
  return (
    <Box>
      <Segmented value={mode} onChange={setMode} options={[{ value: "W", label: "Puissance (W)" }, { value: "BTU", label: "Capacité (BTU/h)" }]} />
      <FieldRow>
        <NumField label={mode === "W" ? "Puissance électrique" : "Capacité"} value={pw} onChange={setPw} suffix={mode === "W" ? "W" : "BTU/h"} />
        {mode === "BTU" ? <NumField label="COP" value={cop} onChange={setCop} /> : <NumField label="Facteur de puiss." value={pf} onChange={setPf} />}
      </FieldRow>
      <T v="label">Tension</T>
      <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
        {[120, 208, 240, 347, 575, 600].map((v) => <Chip key={v} label={`${v} V`} active={volt === v} onPress={() => setVolt(v)} />)}
      </View>
      <Segmented value={phase} onChange={setPhase} options={[{ value: "1", label: "Monophasé" }, { value: "3", label: "Triphasé" }]} />
      <Row>
        <Result label="Courant" value={fmt(amps, 2)} unit="A" tone="accent" />
        <Result label="Puissance élec." value={fmt(watts, 0)} unit="W" sub={ok(watts) ? `${fmt(watts / 1000, 2)} kW` : undefined} />
      </Row>
      <Formula>Mono : I = P ÷ (V × FP){"\n"}Tri : I = P ÷ (√3 × V × FP)</Formula>
    </Box>
  );
}

/* ───────── Fil et disjoncteur ───────── */
const WIRE: { awg: string; amp: number; ocp?: number; cm: number }[] = [
  { awg: "14", amp: 20, ocp: 15, cm: 4110 },
  { awg: "12", amp: 25, ocp: 20, cm: 6530 },
  { awg: "10", amp: 35, ocp: 30, cm: 10380 },
  { awg: "8", amp: 50, cm: 16510 },
  { awg: "6", amp: 65, cm: 26240 },
  { awg: "4", amp: 85, cm: 41740 },
  { awg: "3", amp: 100, cm: 52620 },
  { awg: "2", amp: 115, cm: 66360 },
  { awg: "1", amp: 130, cm: 83690 },
  { awg: "1/0", amp: 150, cm: 105600 },
];
const BREAKERS = [15, 20, 25, 30, 35, 40, 45, 50, 60, 70, 80, 90, 100, 110, 125, 150];
export function WireTool() {
  const c = useColors();
  const [mode, setMode] = useState<"plate" | "calc">("plate");
  const [mca, setMca] = useState("");
  const [mocp, setMocp] = useState("");
  const [rla, setRla] = useState("");
  const [fla, setFla] = useState("");
  const [len, setLen] = useState("");
  const [lu, setLu] = useState<"m" | "ft">("m");
  const [volt, setVolt] = useState(240);
  const M = mode === "plate" ? num(mca) : ok(num(rla)) ? 1.25 * num(rla) + (ok(num(fla)) ? num(fla) : 0) : NaN;
  const MO = mode === "plate" ? num(mocp) : ok(num(rla)) ? 2.25 * num(rla) + (ok(num(fla)) ? num(fla) : 0) : NaN;
  const wire = ok(M) ? WIRE.find((w) => w.amp >= M && (w.ocp ? w.ocp >= M : true)) : undefined;
  const maxBreaker = ok(MO) ? [...BREAKERS].reverse().find((b) => b <= MO) : undefined;
  const minBreaker = ok(M) ? BREAKERS.find((b) => b >= M) : undefined;
  const L = num(len);
  const Lft = ok(L) ? (lu === "m" ? L * 3.281 : L) : NaN;
  const vd = wire && ok(Lft, M) ? (2 * 12.9 * M * Lft) / wire.cm : NaN;
  const vdPct = ok(vd) ? (vd / volt) * 100 : NaN;
  return (
    <Box>
      <Segmented value={mode} onChange={setMode} options={[{ value: "plate", label: "Plaque (MCA/MOCP)" }, { value: "calc", label: "Depuis RLA/FLA" }]} />
      {mode === "plate" ? (
        <FieldRow>
          <NumField label="MCA" value={mca} onChange={setMca} suffix="A" />
          <NumField label="MOCP / Max fuse" value={mocp} onChange={setMocp} suffix="A" />
        </FieldRow>
      ) : (
        <FieldRow>
          <NumField label="RLA compresseur" value={rla} onChange={setRla} suffix="A" />
          <NumField label="FLA ventilateurs" value={fla} onChange={setFla} suffix="A" />
        </FieldRow>
      )}
      <FieldRow>
        <NumField label="Longueur du circuit" value={len} onChange={setLen} suffix={lu} />
        <View style={{ flex: 1, justifyContent: "flex-end" }}>
          <Segmented value={lu} onChange={setLu} options={[{ value: "m", label: "m" }, { value: "ft", label: "pi" }]} />
        </View>
      </FieldRow>
      <View style={{ flexDirection: "row", gap: 8 }}>
        {[120, 208, 240].map((v) => <Chip key={v} label={`${v} V`} active={volt === v} onPress={() => setVolt(v)} />)}
      </View>
      <Row>
        <Result label="Calibre cuivre" value={wire ? `${wire.awg} AWG` : "—"} sub={wire ? `Ampacité ${wire.amp} A (75 °C)` : undefined} />
        <Result label="Disjoncteur" value={minBreaker && maxBreaker ? (minBreaker <= maxBreaker ? `${maxBreaker} A` : "Voir plaque") : maxBreaker ? `${maxBreaker} A` : "—"} sub={ok(MO) ? `Max ${fmt(MO, 1)} A → ≤ ${maxBreaker ?? "?"} A` : undefined} tone="accent" />
      </Row>
      {mode === "calc" && ok(M) ? (
        <Row>
          <Result label="MCA calculé" value={fmt(M, 1)} unit="A" tone="success" />
          <Result label="MOCP calculé" value={fmt(MO, 1)} unit="A" tone="warning" />
        </Row>
      ) : null}
      {ok(vdPct) ? (
        <Row>
          <Result label="Chute de tension" value={fmt(vdPct, 1)} unit="%" sub={`${fmt(vd, 1)} V`} tone={vdPct > 3 ? "destructive" : "success"} />
        </Row>
      ) : null}
      {ok(vdPct) && vdPct > 3 ? <Note tone="bad">Chute &gt; 3 % : augmenter le calibre d'un cran.</Note> : null}
      <Card style={{ backgroundColor: c.muted, gap: 4 }}>
        <T v="label">Rappel</T>
        <T v="small" style={{ color: c.foreground }}>
          Le fil doit supporter le <T v="small" style={{ fontFamily: Fonts.bodyBold, color: c.foreground }}>MCA</T>, et le disjoncteur ne doit pas dépasser le <T v="small" style={{ fontFamily: Fonts.bodyBold, color: c.foreground }}>MOCP</T> (HACR si exigé). Sectionneur visible à proximité de l'unité extérieure.
        </T>
      </Card>
      <Note tone="bad">Cet outil donne seulement un pré-dimensionnement indicatif. Le calcul simplifié RLA/FLA ne remplace jamais les MCA/MOCP du fabricant et ne constitue pas une validation du Code. L'ampacité réelle dépend notamment du type de câble, du cuivre/aluminium, des bornes, de la température, du nombre de conducteurs, de la méthode de pose et des corrections applicables. Au Québec, faire valider selon le Code de construction, chapitre V – Électricité.</Note>
    </Box>
  );
}

/* ───────── Condensateur ───────── */
export function CapTool() {
  const [a, setA] = useState("");
  const [v, setV] = useState("");
  const [rated, setRated] = useState("");
  const [tol, setTol] = useState("6");
  const A = num(a), V = num(v), R = num(rated), T = num(tol);
  const uf = ok(A, V) && V > 0 ? (2652 * A) / V : NaN;
  const lo = ok(R, T) ? R * (1 - T / 100) : NaN;
  const hi = ok(R, T) ? R * (1 + T / 100) : NaN;
  const pass = ok(uf, lo, hi) ? uf >= lo && uf <= hi : null;
  return (
    <Box>
      <FieldRow>
        <NumField label="Courant enroul. démarrage" value={a} onChange={setA} suffix="A" />
        <NumField label="Tension aux bornes" value={v} onChange={setV} suffix="V" />
      </FieldRow>
      <FieldRow>
        <NumField label="Valeur nominale" value={rated} onChange={setRated} suffix="µF" />
        <NumField label="Tolérance" value={tol} onChange={setTol} suffix="± %" />
      </FieldRow>
      <Row>
        <Result label="Capacité mesurée" value={fmt(uf, 1)} unit="µF" tone={pass === null ? "primary" : pass ? "success" : "destructive"} />
        <Result label="Plage acceptable" value={ok(lo) ? `${fmt(lo, 1)}–${fmt(hi, 1)}` : "—"} unit="µF" tone="accent" />
      </Row>
      {pass !== null ? <Note tone={pass ? "ok" : "bad"}>{pass ? "Condensateur dans la tolérance." : "Hors tolérance : remplacer par la même valeur µF et une tension ≥ à l'original."}</Note> : null}
      <Note tone="warn">Décharger le condensateur avant manipulation. Condensateur double : HERM (compresseur) / FAN (ventilateur) / C (commun).</Note>
      <Formula>µF = (2652 × A) ÷ V   (60 Hz)</Formula>
    </Box>
  );
}

/* ───────── Déséquilibre triphasé ───────── */
export function ImbalanceTool() {
  const [kind, setKind] = useState<"V" | "A">("V");
  const [v1, setV1] = useState("");
  const [v2, setV2] = useState("");
  const [v3, setV3] = useState("");
  const a = num(v1), b = num(v2), c = num(v3);
  const avg = ok(a, b, c) ? (a + b + c) / 3 : NaN;
  const dev = ok(avg) ? Math.max(Math.abs(a - avg), Math.abs(b - avg), Math.abs(c - avg)) : NaN;
  const pct = ok(dev, avg) && avg > 0 ? (dev / avg) * 100 : NaN;
  const limit = kind === "V" ? 2 : 10;
  const u = kind === "V" ? "V" : "A";
  return (
    <Box>
      <Segmented value={kind} onChange={setKind} options={[{ value: "V", label: "Tension" }, { value: "A", label: "Courant" }]} />
      <FieldRow>
        <NumField label={kind === "V" ? "L1-L2" : "L1"} value={v1} onChange={setV1} suffix={u} />
        <NumField label={kind === "V" ? "L2-L3" : "L2"} value={v2} onChange={setV2} suffix={u} />
        <NumField label={kind === "V" ? "L1-L3" : "L3"} value={v3} onChange={setV3} suffix={u} />
      </FieldRow>
      <Row>
        <Result label="Moyenne" value={fmt(avg, 1)} unit={u} />
        <Result label="Déséquilibre" value={fmt(pct, 2)} unit="%" tone={!ok(pct) ? "accent" : pct > limit ? "destructive" : "success"} />
      </Row>
      {ok(pct) ? <Note tone={pct > limit ? "bad" : "ok"}>{pct > limit ? `Au-delà de ${limit} % : risque de surchauffe du moteur. Vérifier l'alimentation / les connexions.` : `Sous la limite recommandée de ${limit} %.`}</Note> : null}
      <Formula>% = écart max à la moyenne ÷ moyenne × 100</Formula>
    </Box>
  );
}

/* ───────── Débit de gaz (compteur) ───────── */
export function GasTool() {
  const [unit, setUnit] = useState<"ft3" | "m3">("ft3");
  const [dial, setDial] = useState("2");
  const [sec, setSec] = useState("");
  const [hv, setHv] = useState("");
  const [plate, setPlate] = useState("");
  const D = num(dial), S = num(sec);
  const H = ok(num(hv)) ? num(hv) : unit === "ft3" ? 1030 : 37.8;
  const btu = ok(D, S) && S > 0 ? (unit === "ft3" ? (3600 * D * H) / S : ((3600 * D * H) / S) * 947.8) : NaN;
  const P = num(plate);
  const pct = ok(btu, P) && P > 0 ? (btu / P) * 100 : NaN;
  return (
    <Box>
      <Segmented value={unit} onChange={(v) => { setUnit(v); setDial(v === "ft3" ? "2" : "0.1"); }} options={[{ value: "ft3", label: "Compteur pi³" }, { value: "m3", label: "Compteur m³" }]} />
      <FieldRow>
        <NumField label="Volume du cadran (1 tour)" value={dial} onChange={setDial} suffix={unit === "ft3" ? "pi³" : "m³"} />
        <NumField label="Temps pour 1 tour" value={sec} onChange={setSec} suffix="s" />
      </FieldRow>
      <FieldRow>
        <NumField label="Pouvoir calorifique" value={hv} onChange={setHv} suffix={unit === "ft3" ? "BTU/pi³" : "MJ/m³"} placeholder={unit === "ft3" ? "1030" : "37,8"} />
        <NumField label="Entrée nominale" value={plate} onChange={setPlate} suffix="BTU/h" />
      </FieldRow>
      <Row>
        <Result label="Débit mesuré" value={fmt(btu, 0)} unit="BTU/h" sub={ok(btu) ? `${fmt(btu / 3412, 1)} kW` : undefined} tone="accent" />
        <Result label="% de la plaque" value={fmt(pct, 0)} unit="%" tone={!ok(pct) ? "primary" : pct < 90 || pct > 105 ? "warning" : "success"} />
      </Row>
      {ok(pct) && (pct < 90 || pct > 105) ? <Note tone="warn">Écart notable : vérifier la pression au collecteur (gaz naturel ≈ 3,5 po CE) et les injecteurs.</Note> : null}
      <Note>Arrêter tous les autres appareils au gaz pendant la mesure. Pouvoir calorifique typique au Québec : ≈ 37,5–38 MJ/m³ (≈ 1 000–1 030 BTU/pi³).</Note>
      <Formula>BTU/h = 3600 × volume cadran × PC ÷ secondes</Formula>
    </Box>
  );
}
