import { useState } from "react";
import { View } from "react-native";
import { useColors } from "../../hooks/use-colors";
import { Card, Chip, Result, Row, Segmented, T } from "../ui";
import { Fonts } from "../../constants/theme";
import { Box, FieldRow, Formula, Note, NumField, fmt, num, ok, useUnits } from "./common";
import { fmtK, MURAL_SINGLE_MAX } from "../../lib/search";

/* ───────── Psychrométrie ───────── */
const ATM = 101.325;
/** Pression de vapeur saturante (kPa), Magnus-Tetens */
const pws = (tC: number) => 0.61094 * Math.exp((17.625 * tC) / (tC + 243.04));
export function psychro(tC: number, rh: number) {
  // Stull wet-bulb approximation is intended for roughly -20..50 C and 5..99 % RH.
  if (!Number.isFinite(tC) || !Number.isFinite(rh) || tC < -20 || tC > 50 || rh < 5 || rh > 99) {
    return { dew: NaN, wb: NaN, W: NaN, hKj: NaN, hBtu: NaN, grains: NaN };
  }
  const pw = (rh / 100) * pws(tC);
  const g = Math.log(pw / 0.61094);
  const dew = (243.04 * g) / (17.625 - g);
  const wb = tC * Math.atan(0.151977 * Math.sqrt(rh + 8.313659)) + Math.atan(tC + rh) - Math.atan(rh - 1.676331) + 0.00391838 * Math.pow(rh, 1.5) * Math.atan(0.023101 * rh) - 4.686035;
  const W = (0.621945 * pw) / (ATM - pw); // kg/kg
  const hKj = 1.006 * tC + W * (2501 + 1.86 * tC);
  const tF = (tC * 9) / 5 + 32;
  const hBtu = 0.24 * tF + W * (1061 + 0.444 * tF);
  return { dew, wb, W, hKj, hBtu, grains: W * 7000 };
}

export function PsychroTool() {
  const u = useUnits();
  const [t, setT] = useState("");
  const [rh, setRh] = useState("");
  const T = num(t), H = num(rh);
  const tC = u.toC(T);
  const inRange = ok(T, H) && tC >= -20 && tC <= 50 && H >= 5 && H <= 99;
  const r = inRange ? psychro(tC, H) : null;
  return (
    <Box>
      <FieldRow>
        <NumField label="Bulbe sec" value={t} onChange={setT} suffix={u.tU} />
        <NumField label="Humidité relative" value={rh} onChange={setRh} suffix="%" />
      </FieldRow>
      <Row>
        <Result label="Point de rosée" value={r ? fmt(u.fromC(r.dew)) : "—"} unit={u.tU} />
        <Result label="Bulbe humide" value={r ? fmt(u.fromC(r.wb)) : "—"} unit={u.tU} tone="accent" />
      </Row>
      <Row>
        <Result label="Humidité absolue" value={r ? fmt(r.grains, 0) : "—"} unit="gr/lb" sub={r ? `${fmt(r.W * 1000, 1)} g/kg` : undefined} tone="success" />
        <Result label="Enthalpie" value={r ? fmt(r.hBtu, 1) : "—"} unit="BTU/lb" sub={r ? `${fmt(r.hKj, 1)} kJ/kg` : undefined} tone="warning" />
      </Row>
      {r && u.toC(T) - r.dew < 3 ? <Note tone="warn">Écart faible avec le point de rosée : risque de condensation sur conduits et grilles non isolés.</Note> : null}
      {!r && ok(T, H) ? <Note tone="warn">Plage de cette approximation : −20 à 50 °C et 5 à 99 % HR. Entrez des valeurs dans cette plage.</Note> : null}
      <Note tone="warn">Calcul au niveau de la mer (101,3 kPa). Le bulbe humide utilise l'approximation de Stull; la précision dépend des conditions. Pour des calculs de conception, utiliser un calculateur psychrométrique validé et la pression barométrique locale.</Note>
    </Box>
  );
}

/* ───────── Delta T ───────── */
export function DeltaTTool() {
  const u = useUnits();
  const [mode, setMode] = useState<"froid" | "chaud">("froid");
  const [ret, setRet] = useState("");
  const [sup, setSup] = useState("");
  const [cfm, setCfm] = useState("");
  const R = num(ret), S = num(sup), Q = num(cfm);
  const signedDt = mode === "froid" ? R - S : S - R;
  const reversed = ok(R, S) && signedDt < 0;
  const dt = ok(R, S) && !reversed ? signedDt : NaN;
  const dtF = u.F ? dt : dt * 1.8;
  const btu = ok(dtF, Q) && Q > 0 ? 1.08 * Q * dtF : NaN;
  let tone: "ok" | "warn" | "bad" = "ok";
  let msg = "";
  if (reversed) { tone = "bad"; msg = mode === "froid" ? "En climatisation, l'air soufflé devrait être plus froid que l'air repris. Vérifiez les sondes et les champs." : "En chauffage, l'air soufflé devrait être plus chaud que l'air repris. Vérifiez les sondes et les champs."; }
  else if (ok(dtF)) {
    if (mode === "froid") {
      if (dtF < 14) { tone = "warn"; msg = "ΔT faible : sous-charge, débit d'air trop élevé, compresseur faible ou humidité élevée (charge latente)."; }
      else if (dtF > 24) { tone = "warn"; msg = "ΔT élevé : débit d'air insuffisant (filtre, serpentin sale, ventilateur) ou serpentin givré."; }
      else msg = "ΔT dans la plage normale (16–22 °F / 9–12 K).";
    } else {
      msg = "Fournaise : comparez à la plage de hausse de température de la plaque (ex. 35–65 °F). Thermopompe : ΔT typique 20–30 °F.";
    }
  }
  return (
    <Box>
      <Segmented value={mode} onChange={setMode} options={[{ value: "froid", label: "Climatisation" }, { value: "chaud", label: "Chauffage" }]} />
      <FieldRow>
        <NumField label="Retour" value={ret} onChange={setRet} suffix={u.tU} />
        <NumField label="Alimentation" value={sup} onChange={setSup} suffix={u.tU} />
      </FieldRow>
      <NumField label="Débit d'air (optionnel)" value={cfm} onChange={setCfm} suffix="CFM" />
      <Row>
        <Result label="ΔT" value={fmt(dt)} unit={u.dU} tone={tone === "ok" ? "success" : tone === "bad" ? "destructive" : "warning"} />
        <Result label="Capacité sensible" value={fmt(btu, 0)} unit="BTU/h" sub={ok(btu) ? `${fmt(btu / 12000, 2)} t · ${fmt(btu / 3412, 2)} kW` : undefined} tone="accent" />
      </Row>
      {msg ? <Note tone={tone}>{msg}</Note> : null}
      <Formula>Q sensible (BTU/h) = 1,08 × CFM × ΔT (°F)</Formula>
    </Box>
  );
}

/* ───────── CFM requis ───────── */
export function CFMTool() {
  const [mode, setMode] = useState<"ton" | "rise">("ton");
  const [tons, setTons] = useState("");
  const [per, setPer] = useState(400);
  const [btu, setBtu] = useState("");
  const [eff, setEff] = useState("95");
  const [rise, setRise] = useState("");
  const u = useUnits();
  const T = num(tons);
  const cfm1 = ok(T) ? T * per : NaN;
  const B = num(btu), E = num(eff), R = num(rise);
  const riseF = u.F ? R : R * 1.8;
  const cfm2 = ok(B, E, riseF) && riseF > 0 ? (B * (E / 100)) / (1.08 * riseF) : NaN;
  return (
    <Box>
      <Segmented value={mode} onChange={setMode} options={[{ value: "ton", label: "Par tonnage" }, { value: "rise", label: "Fournaise (hausse T)" }]} />
      {mode === "ton" ? (
        <>
          <NumField label="Capacité" value={tons} onChange={setTons} suffix="tonnes" placeholder="ex. 2,5" />
          <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
            {[350, 400, 450].map((v) => <Chip key={v} label={`${v} CFM/t`} active={per === v} onPress={() => setPer(v)} />)}
          </View>
          <Row>
            <Result label="Débit requis" value={fmt(cfm1, 0)} unit="CFM" sub={ok(cfm1) ? `${fmt(cfm1 * 0.4719, 0)} L/s · ${fmt(cfm1 * 1.699, 0)} m³/h` : undefined} />
          </Row>
          <Note>350 CFM/t : climat humide (meilleure déshumidification). 400 : standard. 450 : climat sec / thermopompe en chauffage.</Note>
        </>
      ) : (
        <>
          <FieldRow>
            <NumField label="Puissance entrée" value={btu} onChange={setBtu} suffix="BTU/h" />
            <NumField label="Efficacité" value={eff} onChange={setEff} suffix="%" />
          </FieldRow>
          <NumField label="Hausse de température mesurée" value={rise} onChange={setRise} suffix={u.dU} />
          <Row>
            <Result label="Débit estimé" value={fmt(cfm2, 0)} unit="CFM" tone="accent" />
          </Row>
          <Formula>CFM = (BTU entrée × efficacité) ÷ (1,08 × ΔT °F)</Formula>
        </>
      )}
    </Box>
  );
}

/* ───────── Dimensionnement de conduits ───────── */
export function DuctTool() {
  const c = useColors();
  const [cfm, setCfm] = useState("");
  const [method, setMethod] = useState<"vel" | "fric">("fric");
  const [vel, setVel] = useState("700");
  const [fric, setFric] = useState("0.08");
  const [side, setSide] = useState("8");
  const Q = num(cfm), V = num(vel), F = num(fric), H = num(side);
  let d = NaN;
  if (ok(Q)) {
    if (method === "vel" && ok(V) && V > 0) d = Math.sqrt(((Q / V) * 144 * 4) / Math.PI);
    if (method === "fric" && ok(F) && F > 0) d = Math.pow((0.109136 * Math.pow(Q, 1.9)) / F, 1 / 5.02);
  }
  const area = ok(d) ? (Math.PI * d * d) / 4 : NaN;
  const velOut = ok(area, Q) ? Q / (area / 144) : NaN;
  // Rectangulaire équivalent (Huebscher) : itération sur la largeur
  let w = NaN;
  if (ok(d, H) && H > 0) {
    let lo = 1, hi = 200;
    for (let i = 0; i < 60; i++) {
      const mid = (lo + hi) / 2;
      const de = (1.3 * Math.pow(mid * H, 0.625)) / Math.pow(mid + H, 0.25);
      if (de < d) lo = mid; else hi = mid;
    }
    w = (lo + hi) / 2;
  }
  const std = [4, 5, 6, 7, 8, 9, 10, 12, 14, 16, 18, 20, 22, 24];
  const round = ok(d) ? std.find((s) => s >= d) ?? Math.ceil(d) : NaN;
  return (
    <Box>
      <NumField label="Débit d'air" value={cfm} onChange={setCfm} suffix="CFM" />
      <Segmented value={method} onChange={setMethod} options={[{ value: "fric", label: "Friction égale" }, { value: "vel", label: "Vitesse" }]} />
      {method === "fric" ? (
        <NumField label="Perte de charge" value={fric} onChange={setFric} suffix="po CE/100 pi" />
      ) : (
        <NumField label="Vitesse visée" value={vel} onChange={setVel} suffix="pi/min" />
      )}
      <NumField label="Hauteur conduit rectangulaire" value={side} onChange={setSide} suffix="po" />
      <Row>
        <Result label="Diamètre rond" value={fmt(d, 1)} unit="po" sub={ok(round) ? `Standard : ${round} po (${fmt(round * 25.4, 0)} mm)` : undefined} />
        <Result label="Rectangulaire" value={ok(w) ? `${Math.ceil(w)} × ${fmt(H, 0)}` : "—"} unit="po" tone="accent" />
      </Row>
      <Row>
        <Result label="Vitesse" value={fmt(velOut, 0)} unit="pi/min" tone={ok(velOut) && velOut > 900 ? "warning" : "success"} />
        <Result label="Section" value={fmt(area, 1)} unit="po²" tone="primary" />
      </Row>
      <Card style={{ backgroundColor: c.muted, gap: 4 }}>
        <T v="label">Repères résidentiels</T>
        <T v="small" style={{ color: c.foreground }}>Plénum / tronc : 700–900 pi/min · Embranchements : 500–600 · Retour : 500–700 · Grilles : ≤ 500{"\n"}Friction usuelle : 0,08–0,10 po CE/100 pi</T>
      </Card>
      <Formula>Friction égale : d = (0,109 × CFM^1,9 ÷ f)^(1/5,02){"\n"}Équiv. rect. : De = 1,3 (a·b)^0,625 ÷ (a+b)^0,25</Formula>
    </Box>
  );
}

/* ───────── Condensat ───────── */
export function CondensateTool() {
  const u = useUnits();
  const [cfm, setCfm] = useState("");
  const [rt, setRt] = useState("");
  const [rrh, setRrh] = useState("");
  const [st, setSt] = useState("");
  const [srh, setSrh] = useState("95");
  const [tons, setTons] = useState("");
  const Q = num(cfm), a = num(rt), b = num(rrh), c2 = num(st), d = num(srh);
  let lbh = NaN;
  if (ok(Q, a, b, c2, d)) {
    const W1 = psychro(u.toC(a), b).W, W2 = psychro(u.toC(c2), d).W;
    lbh = Math.max(0, 4.5 * Q * (W1 - W2));
  }
  const tn = num(tons);
  return (
    <Box>
      <T v="h3">Estimation rapide</T>
      <NumField label="Capacité" value={tons} onChange={setTons} suffix="tonnes" />
      <Row>
        <Result label="Condensat typique" value={ok(tn) ? `${fmt(tn * 0.4, 1)}–${fmt(tn * 1.2, 1)}` : "—"} unit="L/h" sub="Selon l'humidité" />
      </Row>
      <T v="h3" style={{ marginTop: 6 }}>Calcul psychrométrique</T>
      <NumField label="Débit d'air" value={cfm} onChange={setCfm} suffix="CFM" />
      <FieldRow>
        <NumField label="Retour" value={rt} onChange={setRt} suffix={u.tU} />
        <NumField label="HR retour" value={rrh} onChange={setRrh} suffix="%" />
      </FieldRow>
      <FieldRow>
        <NumField label="Alimentation" value={st} onChange={setSt} suffix={u.tU} />
        <NumField label="HR alim." value={srh} onChange={setSrh} suffix="%" />
      </FieldRow>
      <Row>
        <Result label="Eau extraite" value={fmt(lbh / 2.2046, 2)} unit="L/h" sub={ok(lbh) ? `${fmt(lbh, 2)} lb/h · ${fmt((lbh / 8.34) * 24, 1)} gal US/jour` : undefined} tone="accent" />
      </Row>
      <Note tone="warn">Estimation psychrométrique au niveau de la mer, limitée à −20..50 °C et 5..99 % HR. Drain : respecter les prescriptions du fabricant et les exigences locales; le siphon dépend de la pression statique du bac. Dimensionner la pompe selon sa courbe de hauteur/débit, pas seulement un multiplicateur.</Note>
      <Formula>lb/h = 4,5 × CFM × (W retour − W alim.)</Formula>
    </Box>
  );
}

/* ───────── Charge thermique d'une pièce ───────── */
const MURAL_SIZES = [9000, 12000, 15000, 18000, 24000, 30000, 36000, 42000, 48000, 60000];
export function LoadTool() {
  const c = useColors();
  const [unit, setUnit] = useState<"ft" | "m">("ft");
  const [L, setL] = useState("");
  const [W, setW] = useState("");
  const [H, setH] = useState(unit === "ft" ? "8" : "2,4");
  const [ins, setIns] = useState<"bonne" | "moy" | "faible">("moy");
  const [sun, setSun] = useState<"ombre" | "normal" | "soleil">("normal");
  const [occ, setOcc] = useState("2");
  const [kitchen, setKitchen] = useState(false);
  const l = num(L), w = num(W), h = num(H), o = num(occ);
  const areaFt = ok(l, w) ? (unit === "ft" ? l * w : l * w * 10.764) : NaN;
  const hFt = ok(h) ? (unit === "ft" ? h : h * 3.281) : 8;
  const hf = Math.max(0.8, hFt / 8);
  let cool = ok(areaFt) ? areaFt * 20 * hf : NaN;
  if (ok(cool)) {
    cool *= sun === "ombre" ? 0.9 : sun === "soleil" ? 1.1 : 1;
    cool *= ins === "bonne" ? 0.9 : ins === "faible" ? 1.15 : 1;
    if (ok(o) && o > 2) cool += (o - 2) * 600;
    if (kitchen) cool += 4000;
  }
  const heatFactor = ins === "bonne" ? 30 : ins === "moy" ? 40 : 50;
  const heat = ok(areaFt) ? areaFt * heatFactor * hf : NaN;
  const pick = (b: number) => MURAL_SIZES.find((s) => s >= b * 0.95);
  const pc = ok(cool) ? pick(cool) : undefined;
  const ph = ok(heat) ? pick(heat) : undefined;
  return (
    <Box>
      <Segmented value={unit} onChange={(v) => { setUnit(v); setH(v === "ft" ? "8" : "2,4"); }} options={[{ value: "ft", label: "Pieds" }, { value: "m", label: "Mètres" }]} />
      <FieldRow>
        <NumField label="Longueur" value={L} onChange={setL} suffix={unit} />
        <NumField label="Largeur" value={W} onChange={setW} suffix={unit} />
      </FieldRow>
      <FieldRow>
        <NumField label="Plafond" value={H} onChange={setH} suffix={unit} />
        <NumField label="Occupants" value={occ} onChange={setOcc} />
      </FieldRow>
      <T v="label">Isolation</T>
      <Segmented value={ins} onChange={setIns} options={[{ value: "bonne", label: "Bonne (récente)" }, { value: "moy", label: "Moyenne" }, { value: "faible", label: "Faible" }]} />
      <T v="label">Ensoleillement</T>
      <Segmented value={sun} onChange={setSun} options={[{ value: "ombre", label: "Ombragée" }, { value: "normal", label: "Normal" }, { value: "soleil", label: "Très ensoleillée" }]} />
      <View style={{ flexDirection: "row" }}>
        <Chip label="Cuisine (+4 000 BTU)" icon="restaurant-outline" active={kitchen} onPress={() => setKitchen(!kitchen)} />
      </View>
      <Row>
        <Result label="Climatisation" value={fmt(cool, 0)} unit="BTU/h" sub={pc ? `Suggestion : ${fmtK(pc)}${pc > MURAL_SINGLE_MAX ? " · multi-zone" : ""}` : ok(cool) ? "Au-delà de 60k (5 t) : central ou plusieurs systèmes" : undefined} />
        <Result label="Chauffage (Québec)" value={fmt(heat, 0)} unit="BTU/h" sub={ph ? `Suggestion : ${fmtK(ph)} · grand froid` : ok(heat) ? "Prévoir chauffage d'appoint ou central" : undefined} tone="accent" />
      </Row>
      <View style={{ padding: 12, borderRadius: 14, backgroundColor: c.muted }}>
        <T v="small" style={{ color: c.foreground }}>
          Superficie : <T v="small" style={{ fontFamily: Fonts.bodyBold, color: c.foreground }}>{fmt(areaFt, 0)} pi²</T> ({fmt(areaFt / 10.764, 1)} m²)
        </T>
      </View>
      <Note tone="warn">Estimation rapide par règle du pouce. Pour une installation, faites un calcul de charge complet (CSA F280 / Manuel J). En chauffage, la capacité baisse au grand froid : vérifiez la capacité à −15 / −25 °C du modèle.</Note>
    </Box>
  );
}
