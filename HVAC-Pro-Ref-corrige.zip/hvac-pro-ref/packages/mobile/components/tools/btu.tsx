import { useState } from "react";
import { Pressable, View } from "react-native";
import { router } from "expo-router";
import { useColors } from "../../hooks/use-colors";
import { Fonts } from "../../constants/theme";
import { BTU_OPTIONS } from "../../data/models";
import { fmtK, MURAL_SINGLE_MAX } from "../../lib/search";
import { Btn, Chip, Result, Row, Segmented, T } from "../ui";
import { Box, FieldRow, Formula, Note, NumField, fmt, num, ok } from "./common";

/** Tableau ENERGY STAR : superficie (pi²) → capacité de climatisation (BTU/h). */
const ES_TABLE: [number, number, number][] = [
  [100, 150, 5000], [150, 250, 6000], [250, 300, 7000], [300, 350, 8000], [350, 400, 9000],
  [400, 450, 10000], [450, 550, 12000], [550, 700, 14000], [700, 1000, 18000], [1000, 1200, 21000],
  [1200, 1400, 23000], [1400, 1500, 24000], [1500, 2000, 30000], [2000, 2500, 34000],
];
const esCool = (ft2: number) => {
  if (ft2 <= 0) return NaN;
  const row = ES_TABLE.find((r) => ft2 <= r[1]);
  return row ? row[2] : ft2 * 14; // au-delà : ≈ 14 BTU/pi²
};

type Ins = "r2000" | "recente" | "moy" | "faible";
const INS: Record<Ins, { label: string; heat: number; cool: number }> = {
  r2000: { label: "Novoclimat", heat: 22, cool: 0.85 },
  recente: { label: "Récente", heat: 28, cool: 0.92 },
  moy: { label: "Moyenne", heat: 38, cool: 1 },
  faible: { label: "Faible", heat: 50, cool: 1.15 },
};
type Zone = "sud" | "centre" | "nord";
const ZONES: Record<Zone, { label: string; f: number; design: string }> = {
  sud: { label: "Sud (Montréal)", f: 1, design: "−23 °C" },
  centre: { label: "Centre (Québec)", f: 1.1, design: "−27 °C" },
  nord: { label: "Nord (Saguenay+)", f: 1.22, design: "−31 °C" },
};

export function BtuTool() {
  const c = useColors();
  const [unit, setUnit] = useState<"ft2" | "m2">("ft2");
  const [area, setArea] = useState("");
  const [h, setH] = useState("8");
  const [ins, setIns] = useState<Ins>("moy");
  const [sun, setSun] = useState<"ombre" | "normal" | "soleil">("normal");
  const [zone, setZone] = useState<Zone>("sud");
  const [occ, setOcc] = useState("2");
  const [kitchen, setKitchen] = useState(false);
  const [openPlan, setOpenPlan] = useState(false);

  const a = num(area);
  const ft2 = ok(a) && a > 0 ? (unit === "ft2" ? a : a * 10.764) : NaN;
  const hRaw = num(h);
  const hFt = ok(hRaw) && hRaw > 0 ? (unit === "ft2" ? hRaw : hRaw * 3.281) : 8;
  const hf = Math.max(0.85, hFt / 8);
  const o = num(occ);

  let cool = ok(ft2) ? esCool(ft2) * hf * INS[ins].cool : NaN;
  if (ok(cool)) {
    cool *= sun === "ombre" ? 0.9 : sun === "soleil" ? 1.1 : 1;
    if (ok(o) && o > 2) cool += (o - 2) * 600;
    if (kitchen) cool += 4000;
    if (openPlan) cool *= 1.1;
  }
  let heat = ok(ft2) ? ft2 * INS[ins].heat * ZONES[zone].f * hf : NaN;
  if (ok(heat) && openPlan) heat *= 1.05;

  const sizes = BTU_OPTIONS.mural;
  const pick = (b: number) => sizes.find((s) => s >= b * 0.95);
  const need = ok(cool, heat) ? Math.max(cool, heat * 0.8) : NaN; // thermopompe : capacité nominale ≈ 80 % du besoin de chauffe couvert
  const size = ok(need) ? pick(need) : undefined;
  const coolSize = ok(cool) ? pick(cool) : undefined;
  const central = ok(need) && !size;

  return (
    <Box>
      <Segmented value={unit} onChange={(v) => { setUnit(v); setH(v === "ft2" ? "8" : "2,4"); }} options={[{ value: "ft2", label: "Pieds² (pi²)" }, { value: "m2", label: "Mètres² (m²)" }]} />
      <FieldRow>
        <NumField label="Superficie" value={area} onChange={setArea} suffix={unit === "ft2" ? "pi²" : "m²"} placeholder={unit === "ft2" ? "400" : "37"} />
        <NumField label="Plafond" value={h} onChange={setH} suffix={unit === "ft2" ? "pi" : "m"} />
      </FieldRow>
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
        {(unit === "ft2" ? [150, 250, 400, 550, 800, 1200] : [15, 25, 40, 50, 75, 110]).map((v) => (
          <Chip key={v} label={`${v} ${unit === "ft2" ? "pi²" : "m²"}`} active={area === String(v)} onPress={() => setArea(String(v))} />
        ))}
      </View>
      <T v="label">Isolation / enveloppe</T>
      <Segmented value={ins} onChange={setIns} options={(Object.keys(INS) as Ins[]).map((k) => ({ value: k, label: INS[k].label }))} />
      <T v="label">Ensoleillement</T>
      <Segmented value={sun} onChange={setSun} options={[{ value: "ombre", label: "Ombragée" }, { value: "normal", label: "Normal" }, { value: "soleil", label: "Très ensoleillée" }]} />
      <T v="label">Zone climatique (Québec)</T>
      <Segmented value={zone} onChange={setZone} options={(Object.keys(ZONES) as Zone[]).map((k) => ({ value: k, label: ZONES[k].label }))} />
      <FieldRow>
        <NumField label="Occupants" value={occ} onChange={setOcc} />
        <View style={{ flex: 1 }} />
      </FieldRow>
      <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
        <Chip label="Cuisine (+4 000)" icon="restaurant-outline" active={kitchen} onPress={() => setKitchen(!kitchen)} />
        <Chip label="Aire ouverte / mezzanine" icon="expand-outline" active={openPlan} onPress={() => setOpenPlan(!openPlan)} />
      </View>

      <Row>
        <Result label="Climatisation" value={fmt(cool, 0)} unit="BTU/h" sub={ok(cool) ? `${fmt(cool / 12000, 2)} t · ${fmt(cool / 3412, 2)} kW` : undefined} />
        <Result label={`Chauffage (${ZONES[zone].design})`} value={fmt(heat, 0)} unit="BTU/h" sub={ok(heat) ? `${fmt(heat / 12000, 2)} t · ${fmt(heat / 3412, 2)} kW` : undefined} tone="accent" />
      </Row>

      {ok(need) ? (
        <View style={{ padding: 16, borderRadius: 18, backgroundColor: c.success + "14", borderWidth: 1, borderColor: c.success + "40", gap: 6 }}>
          <T v="label" color={c.success}>Format suggéré (thermopompe murale)</T>
          {size ? (
            <>
              <View style={{ flexDirection: "row", alignItems: "baseline", gap: 8 }}>
                <T v="num" style={{ fontSize: 34, lineHeight: 40 }}>{size / 1000}k</T>
                <T v="small" style={{ fontFamily: Fonts.bodyBold }}>BTU/h ({fmt(size / 12000, 2)} t)</T>
              </View>
              <T v="small">
                {coolSize && coolSize !== size ? `Climatisation seule : ${fmtK(coolSize)} suffit — le chauffage québécois impose ${fmtK(size)}. ` : ""}
                {size > MURAL_SINGLE_MAX ? "Au-delà de 36k (3 t) : système multizone (plusieurs têtes murales, voir le badge MULTI) ou gainable. " : ""}
                Superficie : {fmt(ft2, 0)} pi² ({fmt(ft2 / 10.764, 1)} m²) · {fmt(need / ft2, 1)} BTU/pi²
              </T>
              <Btn label={size > MURAL_SINGLE_MAX ? `Voir les multizones ${fmtK(size)}` : `Voir les muraux ${fmtK(size)}`} icon="search" onPress={() => router.push({ pathname: "/", params: size > MURAL_SINGLE_MAX ? { btu: String(size), zone: "multi" } : { btu: String(size) } })} style={{ marginTop: 6 }} />
            </>
          ) : (
            <T v="small">Au-delà de 60k (5 t) : plusieurs systèmes ou système central recommandé.</T>
          )}
          {central ? <Btn label="Voir les systèmes centraux" icon="search" variant="ghost" onPress={() => router.push("/centraux")} style={{ marginTop: 6 }} /> : null}
        </View>
      ) : null}

      <T v="label" style={{ marginTop: 6 }}>Tableau rapide surface → BTU (climatisation)</T>
      <View style={{ borderRadius: 16, borderWidth: 1, borderColor: c.border, overflow: "hidden" }}>
        {ES_TABLE.map(([lo, hi, b], i) => {
          const hit = ok(ft2) && ft2 > lo && ft2 <= hi;
          return (
            <Pressable key={lo} onPress={() => { setUnit("ft2"); setH("8"); setArea(String(hi)); }} style={{ flexDirection: "row", paddingHorizontal: 14, paddingVertical: 9, backgroundColor: hit ? c.primary + "1C" : i % 2 ? c.muted : c.card }}>
              <T v="small" style={{ flex: 1, color: c.foreground, fontFamily: hit ? Fonts.bodyBold : Fonts.body }}>{lo}–{hi} pi²</T>
              <T v="small" style={{ flex: 1, color: c.mutedForeground }}>{fmt(lo / 10.764, 0)}–{fmt(hi / 10.764, 0)} m²</T>
              <T v="small" style={{ fontFamily: Fonts.bodyBold, color: hit ? c.primary : c.foreground }}>{fmt(b, 0)} BTU ({fmt(b / 12000, 2)} t)</T>
            </Pressable>
          );
        })}
      </View>

      <Formula>{"Clim. = table ENERGY STAR × (H/8) × isolation × soleil + 600/occupant (>2) + 4 000 cuisine\nChauffage = pi² × facteur isolation (22–50 BTU/pi²) × zone × (H/8)"}</Formula>
      <Note tone="warn">Estimation rapide. Pour dimensionner une installation, faites un calcul de charge complet (CSA F280 / Manuel J). Au grand froid, vérifiez la capacité réelle du modèle à −15 °C / −25 °C (fiche NEEP).</Note>
    </Box>
  );
}
