import { useState } from "react";
import { View } from "react-native";
import { useColors } from "../../hooks/use-colors";
import { Card, Result, Row, Segmented, T, RefBadge } from "../ui";
import { REFS, refById, satPressureKpaAbs, satTempC } from "../../data/refrigerants";
import { REF_COLORS, Fonts } from "../../constants/theme";
import { Box, FieldRow, Formula, Note, NumField, fmt, num, ok, useUnits } from "./common";

const REF_OPTS = REFS.map((r) => ({ value: r.id, label: r.id }));

function RefPicker({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return <Segmented value={value} onChange={onChange} options={REF_OPTS} />;
}

/* ───────── Tableau P/T ───────── */
export function PTTool() {
  const c = useColors();
  const u = useUnits();
  const [ref, setRef] = useState("R410A");
  const [mode, setMode] = useState<"p2t" | "t2p">("p2t");
  const [v, setV] = useState("");
  const x = num(v);
  let res = "—";
  if (ok(x)) {
    const result = mode === "p2t"
      ? u.fromC(satTempC(ref, u.toKpaAbs(x)))
      : u.fromKpaAbs(satPressureKpaAbs(ref, u.toC(x)));
    res = Number.isFinite(result) ? fmt(result, 1) : "Hors plage";
  }
  const rows: number[] = [];
  if (u.F) for (let t = -40; t <= 140; t += 5) rows.push(t);
  else for (let t = -40; t <= 60; t += 2.5) rows.push(t);
  const info = refById(ref);
  return (
    <>
      <Box>
        <RefPicker value={ref} onChange={setRef} />
        <Segmented value={mode} onChange={setMode} options={[{ value: "p2t", label: "Pression → Temp." }, { value: "t2p", label: "Temp. → Pression" }]} />
        <NumField label={mode === "p2t" ? "Pression lue" : "Température de saturation"} value={v} onChange={setV} suffix={mode === "p2t" ? u.pU : u.tU} />
        <Row>
          <Result label={mode === "p2t" ? "Temp. saturation" : "Pression saturation"} value={res} unit={mode === "p2t" ? u.tU : u.pU} />
        </Row>
        {ref === "R454B" ? <Note tone="warn">R-454B a un léger glissement (≈ 1 °C). Valeurs données au point de bulle — utilisez le point de rosée du manuel pour la surchauffe.</Note> : null}
      </Box>
      <Box gap={8}>
        <T v="label">Tableau {info?.id ?? ref}</T>
        <Card style={{ padding: 0, overflow: "hidden" }}>
          <View style={{ flexDirection: "row", backgroundColor: REF_COLORS[ref] + "22", paddingVertical: 10, paddingHorizontal: 14 }}>
            <T v="label" style={{ flex: 1 }}>{u.tU}</T>
            <T v="label" style={{ flex: 1, textAlign: "right" }}>{u.pU}</T>
          </View>
          {rows.map((t, i) => {
            const p = u.fromKpaAbs(satPressureKpaAbs(ref, u.toC(t)));
            return (
              <View key={t} style={{ flexDirection: "row", paddingVertical: 8, paddingHorizontal: 14, backgroundColor: i % 2 ? c.muted : "transparent" }}>
                <T style={{ flex: 1, fontFamily: Fonts.bodyBold }}>{fmt(t, 1)}</T>
                <T style={{ flex: 1, textAlign: "right" }}>{p < 0 ? `${fmt(p, 1)} (vide)` : fmt(p, 1)}</T>
              </View>
            );
          })}
        </Card>
        <Note tone="warn">Tableau indicatif interpolé à partir de données internes non certifiées. La plage est limitée à −40 à 60 °C. La conversion de pression manométrique utilise 101,325 kPa comme pression atmosphérique standard; l'altitude et la météo peuvent modifier la pression locale. Pour le diagnostic et la charge, confirmez toujours avec les données du fabricant ou un instrument P/T vérifié.</Note>
      </Box>
    </>
  );
}

/* ───────── Surchauffe / sous-refroidissement ───────── */
export function SHSCTool() {
  const u = useUnits();
  const [ref, setRef] = useState("R410A");
  const [ps, setPs] = useState("");
  const [ts, setTs] = useState("");
  const [pl, setPl] = useState("");
  const [tl, setTl] = useState("");
  const a = num(ps), b = num(ts), d = num(pl), e = num(tl);
  // R-454B is zeotropic: superheat needs dew-point data and subcooling needs bubble-point data.
  // The current internal dataset contains bubble-point values only, so suppress the superheat result.
  const blendCurveUnavailable = ref === "R454B";
  const satS = ok(a) && !blendCurveUnavailable ? satTempC(ref, u.toKpaAbs(a)) : NaN;
  // The available R-454B table is bubble-point data, which is the correct basis for SC.
  const satL = ok(d) ? satTempC(ref, u.toKpaAbs(d)) : NaN;
  const sh = ok(satS, b) ? u.dFromC(u.toC(b) - satS) : NaN;
  const sc = ok(satL, e) ? u.dFromC(satL - u.toC(e)) : NaN;
  const shF = u.F ? sh : sh * 1.8;
  const scF = u.F ? sc : sc * 1.8;
  return (
    <Box>
      <RefPicker value={ref} onChange={setRef} />
      <T v="h3">Basse pression (aspiration)</T>
      <FieldRow>
        <NumField label="Pression" value={ps} onChange={setPs} suffix={u.pU} />
        <NumField label="Temp. ligne" value={ts} onChange={setTs} suffix={u.tU} />
      </FieldRow>
      <T v="h3">Haute pression (liquide)</T>
      <FieldRow>
        <NumField label="Pression" value={pl} onChange={setPl} suffix={u.pU} />
        <NumField label="Temp. ligne" value={tl} onChange={setTl} suffix={u.tU} />
      </FieldRow>
      <Row>
        <Result label="Surchauffe" value={fmt(sh)} unit={u.dU} sub={ok(satS) ? `Évap. sat. ${fmt(u.fromC(satS))} ${u.tU}` : undefined} tone={!ok(shF) ? "primary" : shF < 3 ? "destructive" : shF > 25 ? "warning" : "success"} />
        <Result label="Sous-refroid." value={fmt(sc)} unit={u.dU} sub={ok(satL) ? `Cond. sat. ${fmt(u.fromC(satL))} ${u.tU}` : undefined} tone={!ok(scF) ? "accent" : scF < 3 ? "warning" : scF > 20 ? "warning" : "success"} />
      </Row>
      {ok(shF) && shF < 3 ? <Note tone="bad">Surchauffe très basse : risque de retour liquide au compresseur (surcharge, débit d'air faible, détendeur ouvert).</Note> : null}
      {ok(shF) && shF > 25 ? <Note tone="warn">Surchauffe élevée : sous-charge, restriction ou détendeur fermé possible.</Note> : null}
      {blendCurveUnavailable ? <Note tone="warn">Pour le R-454B, la surchauffe est masquée car la courbe de rosée manque. Le sous-refroidissement utilise la courbe de bulle interne, qui reste indicative : confirmez-la avec le tableau fabricant.</Note> : null}
      <Note tone="warn">Repères indicatifs seulement : détendeur TXV/EEV — les cibles SH/SC dépendent du fabricant et des conditions. Orifice fixe — utilisez la table de surchauffe du fabricant. Muraux inverter : charge au poids selon le manuel.</Note>
      <Formula>SH = T ligne aspiration − T sat(BP){"\n"}SC = T sat(HP) − T ligne liquide</Formula>
    </Box>
  );
}

/* ───────── Surchauffe cible (orifice fixe) ───────── */
export function TargetSHTool() {
  const u = useUnits();
  const [wb, setWb] = useState("");
  const [odb, setOdb] = useState("");
  const w = num(wb), o = num(odb);
  const wF = u.F ? w : (w * 9) / 5 + 32;
  const oF = u.F ? o : (o * 9) / 5 + 32;
  const tF = ok(w, o) ? (3 * wF - 80 - oF) / 2 : NaN;
  const disp = u.F ? tF : tF / 1.8;
  return (
    <Box>
      <FieldRow>
        <NumField label="Bulbe humide intérieur" value={wb} onChange={setWb} suffix={u.tU} />
        <NumField label="Bulbe sec extérieur" value={odb} onChange={setOdb} suffix={u.tU} />
      </FieldRow>
      <Row>
        <Result label="Surchauffe cible" value={ok(tF) && tF >= 5 ? fmt(disp) : ok(tF) ? "< 5 °F" : "—"} unit={u.dU} tone="success" sub={ok(tF) ? "Tolérance ± 5 °F (± 3 K)" : undefined} />
      </Row>
      {ok(tF) && tF < 5 ? <Note tone="warn">Conditions hors plage : ne pas ajuster la charge par la surchauffe. Charger au poids ou revenir à des conditions plus chaudes.</Note> : null}
      <Note>S'applique aux systèmes à orifice fixe (piston). Les systèmes à TXV/EEV se chargent au sous-refroidissement.</Note>
      <Formula>SH cible (°F) = (3 × BH int. − 80 − BS ext.) ÷ 2</Formula>
    </Box>
  );
}

/* ───────── Charge additionnelle ───────── */
const RATES: Record<string, Record<string, number>> = {
  R22: { "1/4": 23, "3/8": 60, "1/2": 120 },
  R410A: { "1/4": 20, "3/8": 54, "1/2": 110 },
  R32: { "1/4": 18, "3/8": 48, "1/2": 98 },
  R454B: { "1/4": 19, "3/8": 50, "1/2": 104 },
};
export function ChargeTool() {
  const [ref, setRef] = useState("R410A");
  const [line, setLine] = useState<"1/4" | "3/8" | "1/2">("1/4");
  const [unit, setUnit] = useState<"m" | "ft">("m");
  const [len, setLen] = useState("");
  const [pre, setPre] = useState("");
  const [rate, setRate] = useState("");
  const L = num(len);
  const P = ok(num(pre)) ? num(pre) : unit === "m" ? 7.5 : 25;
  const defRate = RATES[ref][line];
  const R = ok(num(rate)) ? num(rate) : unit === "m" ? defRate : defRate * 0.3048 / 28.35;
  const extra = ok(L) ? Math.max(0, L - P) : NaN;
  const grams = ok(extra) ? (unit === "m" ? extra * R : extra * R * 28.35) : NaN;
  return (
    <Box>
      <RefPicker value={ref} onChange={setRef} />
      <Segmented value={line} onChange={setLine} options={[{ value: "1/4", label: 'Liquide 1/4"' }, { value: "3/8", label: '3/8"' }, { value: "1/2", label: '1/2"' }]} />
      <Segmented value={unit} onChange={setUnit} options={[{ value: "m", label: "Mètres" }, { value: "ft", label: "Pieds" }]} />
      <FieldRow>
        <NumField label="Longueur totale" value={len} onChange={setLen} suffix={unit} />
        <NumField label="Pré-chargée" value={pre} onChange={setPre} suffix={unit} placeholder={unit === "m" ? "7,5" : "25"} />
      </FieldRow>
      <NumField label={`Taux d'ajout (défaut ${unit === "m" ? `${defRate} g/m` : `${fmt(defRate * 0.3048 / 28.35, 2)} oz/pi`})`} value={rate} onChange={setRate} suffix={unit === "m" ? "g/m" : "oz/pi"} placeholder={unit === "m" ? String(defRate) : fmt(defRate * 0.3048 / 28.35, 2)} />
      <Row>
        <Result label="Charge à ajouter" value={fmt(grams, 0)} unit="g" sub={ok(grams) ? `${fmt(grams / 28.35, 1)} oz · ${fmt(grams / 453.6, 2)} lb` : undefined} tone="accent" />
        <Result label="Longueur excédentaire" value={fmt(extra, 1)} unit={unit} />
      </Row>
      <Note tone="warn">Le taux et la longueur pré-chargée varient selon le fabricant (ex. 15–30 g/m en 1/4"). Utilisez TOUJOURS la valeur de la plaque / du manuel d'installation.</Note>
    </Box>
  );
}

/* ───────── Vide ───────── */
export function VacuumTool() {
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [min, setMin] = useState("10");
  const s = num(start), e = num(end), m = num(min);
  const rise = ok(s, e) ? e - s : NaN;
  const rate = ok(rise, m) && m > 0 ? rise / m : NaN;
  let verdict: { t: "ok" | "warn" | "bad"; txt: string } | null = null;
  if (ok(s, e)) {
    if (s > 500) verdict = { t: "warn", txt: "Vide initial insuffisant : descendre sous 500 microns avant le test d'isolement." };
    else if (e <= 1000 && rise <= 500) verdict = { t: "ok", txt: "Test réussi : le vide tient (≤ 1000 microns après isolement)." };
    else if (e <= 1500) verdict = { t: "warn", txt: "Remontée qui se stabilise : humidité probable. Poursuivre l'évacuation (azote sec / vide triple)." };
    else verdict = { t: "bad", txt: "Remontée continue : fuite probable. Vérifier évasements, raccords, valves Schrader, flexibles." };
  }
  return (
    <Box>
      <FieldRow>
        <NumField label="Vide atteint" value={start} onChange={setStart} suffix="µm" />
        <NumField label="Après isolement" value={end} onChange={setEnd} suffix="µm" />
      </FieldRow>
      <NumField label="Durée du test" value={min} onChange={setMin} suffix="min" />
      <Row>
        <Result label="Remontée" value={fmt(rise, 0)} unit="µm" />
        <Result label="Taux" value={fmt(rate, 0)} unit="µm/min" tone="accent" />
      </Row>
      {verdict ? <Note tone={verdict.t}>{verdict.txt}</Note> : null}
      <Note tone="warn">Les seuils et verdicts sont des repères de dépistage, pas une certification d'étanchéité ou de déshydratation. Appliquer la procédure et les critères du fabricant. Bonnes pratiques : flexibles courts et gros diamètre, retirer les noyaux Schrader, jauge à micron à l'opposé de la pompe, huile de pompe propre.</Note>
    </Box>
  );
}

/* ───────── Test à l'azote (correction température) ───────── */
export function NitrogenTool() {
  const u = useUnits();
  const [p1, setP1] = useState("");
  const [t1, setT1] = useState("");
  const [p2, setP2] = useState("");
  const [t2, setT2] = useState("");
  const P1 = num(p1), T1 = num(t1), P2 = num(p2), T2 = num(t2);
  const t1K = u.toC(T1) + 273.15;
  const t2K = u.toC(T2) + 273.15;
  const exp = ok(P1, T1, T2) && t1K > 0 && t2K > 0 && u.toKpaAbs(P1) > 0
    ? u.fromKpaAbs(u.toKpaAbs(P1) * (t2K / t1K))
    : NaN;
  const diff = ok(exp, P2) ? P2 - exp : NaN;
  const pct = ok(diff, exp) ? (diff / exp) * 100 : NaN;
  return (
    <Box>
      <T v="h3">Début du test</T>
      <FieldRow>
        <NumField label="Pression" value={p1} onChange={setP1} suffix={u.pU} />
        <NumField label="Temp. ambiante" value={t1} onChange={setT1} suffix={u.tU} />
      </FieldRow>
      <T v="h3">Fin du test</T>
      <FieldRow>
        <NumField label="Pression" value={p2} onChange={setP2} suffix={u.pU} />
        <NumField label="Temp. ambiante" value={t2} onChange={setT2} suffix={u.tU} />
      </FieldRow>
      <Row>
        <Result label="Pression attendue" value={fmt(exp)} unit={u.pU} sub="Corrigée pour la température" />
        <Result label="Écart réel" value={fmt(diff)} unit={u.pU} sub={ok(pct) ? `${fmt(pct)} %` : undefined} tone={!ok(pct) ? "accent" : Math.abs(pct) < 1 ? "success" : "destructive"} />
      </Row>
      {ok(pct) ? <Note tone={Math.abs(pct) < 1 ? "ok" : "bad"}>{Math.abs(pct) < 1 ? "Aucune perte significative : étanchéité OK." : "Perte de pression non expliquée par la température : rechercher la fuite (eau savonneuse, détecteur)."}</Note> : null}
      <Note tone="warn">Modèle de gaz parfait, indicatif : à haute pression, les écarts de compressibilité peuvent compter. Ne jamais dépasser la pression d'essai indiquée par le fabricant pour la section testée. Utiliser un régulateur, une soupape et les procédures de sécurité applicables. Cette correction ne valide pas l'étanchéité.</Note>
      <Formula>P2 attendue (abs) = P1 (abs) × T2 (K) ÷ T1 (K)</Formula>
    </Box>
  );
}

/* ───────── Récupération (règle 80 %) ───────── */
const SG: Record<string, number> = { R22: 1.19, R410A: 1.06, R32: 0.96, R454B: 1.03 };
export function RecoveryTool() {
  const [ref, setRef] = useState("R410A");
  const [unit, setUnit] = useState<"lb" | "kg">("lb");
  const [wc, setWc] = useState("");
  const [tare, setTare] = useState("");
  const W = num(wc), T = num(tare);
  const net = ok(W) ? W * 0.8 * SG[ref] : NaN;
  const gross = ok(net, T) ? net + T : NaN;
  return (
    <Box>
      <RefPicker value={ref} onChange={setRef} />
      <Segmented value={unit} onChange={setUnit} options={[{ value: "lb", label: "Livres" }, { value: "kg", label: "Kilogrammes" }]} />
      <FieldRow>
        <NumField label="Capacité eau (WC)" value={wc} onChange={setWc} suffix={unit} />
        <NumField label="Tare (TW)" value={tare} onChange={setTare} suffix={unit} />
      </FieldRow>
      <Row>
        <Result label="Réfrigérant max" value={fmt(net, 1)} unit={unit} tone="accent" />
        <Result label="Poids brut max" value={fmt(gross, 1)} unit={unit} sub="Arrêter la récupération ici" tone="destructive" />
      </Row>
      <Note tone="bad">Estimation seulement : la densité liquide dépend de la température. La limite réelle doit être calculée avec la densité du réfrigérant à la température maximale de stockage, la WC/TW inscrite sur le cylindre et les règles applicables. Ne jamais utiliser ce résultat comme seule limite de remplissage. Ne pas mélanger les réfrigérants; utiliser un cylindre et une machine homologués pour la classe de sécurité, notamment A2L.</Note>
      <Formula>Net max = WC × 0,80 × densité relative ({ref} ≈ {SG[ref]}){"\n"}Brut max = Net max + Tare</Formula>
    </Box>
  );
}

/* ───────── Fiches réfrigérants ───────── */
export function RefsTool() {
  const c = useColors();
  return (
    <Box>
      {REFS.map((r) => (
        <Card key={r.id} style={{ gap: 8, borderLeftWidth: 5, borderLeftColor: r.color }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
            <T v="h2" style={{ flex: 1 }}>{r.name}</T>
            <RefBadge r={r.id} />
          </View>
          <T v="small">{r.type}</T>
          {[
            ["Classe de sécurité", r.safety],
            ["PRP (GWP)", String(r.gwp)],
            ["Glissement", r.glide],
            ["Huile", r.oil],
            ["Couleur cylindre", r.cylinder],
            ["Table indicative à 0 °C", `${fmt((r.table[4] - 101.325) * 0.1450377, 0)} psig`],
            ["Table indicative à 40 °C", `${fmt((r.table[8] - 101.325) * 0.1450377, 0)} psig`],
          ].map(([k, v]) => (
            <View key={k} style={{ flexDirection: "row", justifyContent: "space-between", borderTopWidth: 1, borderTopColor: c.border, paddingTop: 6 }}>
              <T v="small">{k}</T>
              <T style={{ fontFamily: Fonts.bodyBold, flexShrink: 1, textAlign: "right" }}>{v}</T>
            </View>
          ))}
          <Note tone="warn">{r.notes} Données P/T indicatives, non certifiées; confirmer avec la documentation du fabricant.</Note>
        </Card>
      ))}
    </Box>
  );
}
