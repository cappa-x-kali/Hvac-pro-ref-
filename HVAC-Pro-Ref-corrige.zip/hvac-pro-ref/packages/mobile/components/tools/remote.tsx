import { useMemo, useState } from "react";
import { Platform, Pressable, View } from "react-native";
import { TText as Text } from "../ttext";
import { Ionicons } from "@expo/vector-icons";
import { useColors } from "../../hooks/use-colors";
import { Fonts } from "../../constants/theme";
import { BRANDS } from "../../data/brands";
import { BRAND_APPS, BRAND_PROTOCOLS, PROTOCOLS, playSearchUrl, protocolById, type AcAction, type AcFan, type AcMode, type AcState } from "../../data/ir-protocols";
import { irFrequencies, irSend, irStatus } from "../../lib/ir";
import { openUrl } from "../../lib/files";
import { Card, Chip, ChipRow, Pill, Section, T } from "../ui";
import { Box, Note } from "./common";
import { CreditFooter } from "../credits";

/** Marques absentes du répertoire mais utiles pour la télécommande IR. */
const EXTRA_BRANDS = [{ id: "haier", name: "Haier", color: "#0072CE" }, { id: "sinclair", name: "Sinclair", color: "#0F766E" }, { id: "kaysun", name: "Kaysun", color: "#2563EB" }];

const MODES: { id: AcMode; label: string; icon: keyof typeof Ionicons.glyphMap; color: string }[] = [
  { id: "auto", label: "Auto", icon: "sync", color: "#22C55E" },
  { id: "cool", label: "Froid", icon: "snow", color: "#38BDF8" },
  { id: "dry", label: "Déshum.", icon: "water", color: "#14B8A6" },
  { id: "fan", label: "Ventil.", icon: "aperture", color: "#A3A3A3" },
  { id: "heat", label: "Chaud", icon: "flame", color: "#F97316" },
];
const FANS: { id: AcFan; label: string; bars: number }[] = [
  { id: "auto", label: "Auto", bars: 0 },
  { id: "low", label: "Basse", bars: 1 },
  { id: "med", label: "Moy.", bars: 2 },
  { id: "high", label: "Haute", bars: 3 },
];

const STATUS_TXT = {
  ready: { t: "Émetteur IR détecté", d: "Pointez le haut du téléphone vers l'unité intérieure.", tone: "ok" },
  "no-emitter": { t: "Aucun émetteur IR", d: "Cet appareil n'a pas de diode IR. Les adaptateurs IR USB-C / prise audio exigent souvent l'application du fabricant.", tone: "bad" },
  "no-module": { t: "Mode démonstration", d: "Le module IR natif n'est pas inclus dans ce build (Expo Go / aperçu). Il sera actif dans l'APK installée.", tone: "warn" },
  web: { t: "Mode démonstration (web)", d: "L'émission IR n'est possible que sur un téléphone Android équipé d'un émetteur IR.", tone: "warn" },
} as const;

export function RemoteTool() {
  const c = useColors();
  const status = useMemo(() => irStatus(), []);
  const freqs = useMemo(() => irFrequencies(), []);
  const brands = useMemo(() => {
    const l = [...BRANDS.filter((b) => BRAND_PROTOCOLS[b.id] || BRAND_APPS[b.id]).map((b) => ({ id: b.id, name: b.name, color: b.color })), ...EXTRA_BRANDS];
    const top = ["midea", "senville", "kinghome", "tcl"];
    return [...l.filter((b) => top.includes(b.id)), ...l.filter((b) => !top.includes(b.id))];
  }, []);
  const [brandId, setBrandId] = useState<string>("midea");
  const [showAll, setShowAll] = useState(false);
  const brandProtos = BRAND_PROTOCOLS[brandId] ?? [];
  const [protoId, setProtoId] = useState<string>("midea48");
  const proto = protocolById(protoId);
  const [s, setS] = useState<AcState>({ power: false, mode: "cool", temp: 22, fan: "auto", swing: false });
  const [last, setLast] = useState<{ ok: boolean; msg: string } | null>(null);

  const pickBrand = (id: string) => {
    setBrandId(id);
    const first = BRAND_PROTOCOLS[id]?.[0];
    if (first) setProtoId(first);
  };

  const send = async (next: AcState, action: AcAction = "state") => {
    setS(next);
    if (!proto?.encode) {
      setLast({ ok: false, msg: `${proto?.name ?? "Protocole"} : encodeur pas encore disponible` });
      return;
    }
    const frame = proto.encode(next, action);
    const info = `${frame.hex} · ${frame.pattern.length} impulsions · ${frame.frequency / 1000} kHz`;
    if (status !== "ready") {
      setLast({ ok: true, msg: `Simulé : ${info}` });
      return;
    }
    try {
      await irSend(frame);
      setLast({ ok: true, msg: `Envoyé : ${info}` });
    } catch (e) {
      setLast({ ok: false, msg: e instanceof Error ? e.message : "Échec de l'envoi IR" });
    }
  };

  const min = proto?.minTemp ?? 16;
  const max = proto?.maxTemp ?? 30;
  const mode = MODES.find((m) => m.id === s.mode) ?? MODES[1];
  const fan = FANS.find((f) => f.id === s.fan) ?? FANS[0];
  const st = STATUS_TXT[status];
  const stCol = st.tone === "ok" ? c.success : st.tone === "bad" ? c.destructive : c.warning;
  const protoList = showAll ? PROTOCOLS : PROTOCOLS.filter((p) => brandProtos.includes(p.id) || p.id === protoId);
  const apps = BRAND_APPS[brandId] ?? [];

  return (
    <View>
      <Box>
        <View style={{ flexDirection: "row", gap: 12, alignItems: "center", padding: 14, borderRadius: 16, backgroundColor: stCol + "14", borderWidth: 1, borderColor: stCol + "40" }}>
          <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: stCol + "26", alignItems: "center", justifyContent: "center" }}>
            <Ionicons name={status === "ready" ? "radio" : "radio-outline"} size={20} color={stCol} />
          </View>
          <View style={{ flex: 1, gap: 2 }}>
            <T v="h3" style={{ fontSize: 15 }}>{st.t}</T>
            <T v="small">{st.d}</T>
            {freqs.length ? <T v="small" style={{ fontSize: 11 }}>Fréquences : {freqs.map((f) => `${Math.round(f[0] / 1000)}–${Math.round(f[1] / 1000)} kHz`).join(", ")}</T> : null}
          </View>
        </View>
      </Box>

      <Section title="1 · Marque" style={{ marginTop: 18 }}>
        <View style={{ marginHorizontal: -16 }}>
          <ChipRow>
            {brands.map((b) => (
              <Chip key={b.id} label={b.name} active={b.id === brandId} color={b.color} onPress={() => pickBrand(b.id)} />
            ))}
          </ChipRow>
        </View>
      </Section>

      <Section title="2 · Protocole IR" action={<Pressable onPress={() => setShowAll(!showAll)}><T v="small" color={c.primary} style={{ fontFamily: Fonts.bodyBold }}>{showAll ? "Suggérés" : "Tous"}</T></Pressable>}>
        <View style={{ gap: 8 }}>
          {protoList.length === 0 ? <T v="small">Aucun protocole IR connu pour cette marque — voir les applications Wi-Fi plus bas.</T> : null}
          {protoList.map((p) => {
            const a = p.id === protoId;
            const pc = p.status === "soon" ? c.mutedForeground : p.status === "beta" ? c.warning : c.success;
            return (
              <Pressable key={p.id} onPress={() => setProtoId(p.id)} style={{ flexDirection: "row", alignItems: "center", gap: 10, padding: 12, borderRadius: 14, backgroundColor: a ? c.primary + "14" : c.card, borderWidth: 1, borderColor: a ? c.primary : c.border }}>
                <Ionicons name={a ? "radio-button-on" : "radio-button-off"} size={18} color={a ? c.primary : c.mutedForeground} />
                <View style={{ flex: 1, gap: 2 }}>
                  <T v="h3" style={{ fontSize: 14 }}>{p.name}</T>
                  {a ? <T v="small" style={{ fontSize: 12 }}>{p.note}</T> : null}
                </View>
                <Pill label={p.status === "ok" ? "Prêt" : p.status === "beta" ? "Bêta" : "À venir"} color={pc} />
              </Pressable>
            );
          })}
        </View>
      </Section>

      <Section title="3 · Télécommande">
        <View style={{ alignItems: "center" }}>
          <View style={{ width: "100%", maxWidth: 340, borderRadius: 36, padding: 18, gap: 16, backgroundColor: "#0B1322", borderWidth: 1, borderColor: "#1E2A3F", ...(Platform.OS === "web" ? {} : { elevation: 6 }) }}>
            <View style={{ alignSelf: "center", width: 26, height: 8, borderRadius: 4, backgroundColor: s.power ? "#EF4444" : "#3A2020" }} />
            {/* Écran LCD */}
            <View style={{ borderRadius: 18, padding: 16, backgroundColor: s.power ? "#C9F2E4" : "#2A3A38", opacity: s.power ? 1 : 0.7 }}>
              <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                  <Ionicons name={mode.icon} size={18} color="#0B3B33" />
                  <Text style={{ fontFamily: Fonts.bodyBold, fontSize: 13, color: "#0B3B33" }}>{mode.label.toUpperCase()}</Text>
                </View>
                <View style={{ flexDirection: "row", alignItems: "flex-end", gap: 3 }}>
                  <Ionicons name="aperture-outline" size={14} color="#0B3B33" />
                  {fan.bars === 0 ? <Text style={{ fontFamily: Fonts.bodyBold, fontSize: 11, color: "#0B3B33" }}>AUTO</Text> : [1, 2, 3].map((i) => <View key={i} style={{ width: 5, height: 4 + i * 4, borderRadius: 1, backgroundColor: i <= fan.bars ? "#0B3B33" : "#0B3B3333" }} />)}
                </View>
              </View>
              <View style={{ flexDirection: "row", justifyContent: "center", alignItems: "flex-start", marginTop: 4 }}>
                <Text style={{ fontFamily: Fonts.display, fontSize: 64, lineHeight: 72, color: "#0B3B33" }}>{s.power ? (s.mode === "fan" ? "--" : s.temp) : "OFF"}</Text>
                {s.power && s.mode !== "fan" ? <Text style={{ fontFamily: Fonts.bodyBold, fontSize: 20, color: "#0B3B33", marginTop: 10 }}>°C</Text> : null}
              </View>
              <View style={{ flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 6 }}>
                {s.swing && s.power ? <Ionicons name="swap-vertical" size={12} color="#0B3B33" /> : null}
                <Text style={{ textAlign: "center", fontFamily: Fonts.body, fontSize: 11, color: "#0B3B33AA" }} numberOfLines={1}>{s.swing && s.power ? "SWING · " : ""}{proto?.name ?? ""}</Text>
              </View>
            </View>

            {/* Rangée marche / mode */}
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
              <RoundBtn icon="power" color="#EF4444" big label="Marche" onPress={() => send({ ...s, power: !s.power }, s.power ? "off" : "state")} />
              <RoundBtn icon={mode.icon} color={mode.color} label="Mode" onPress={() => { const i = MODES.findIndex((m) => m.id === s.mode); send({ ...s, power: true, mode: MODES[(i + 1) % MODES.length].id }); }} />
              <RoundBtn icon="aperture" color="#A78BFA" label="Vitesse" onPress={() => { const i = FANS.findIndex((f) => f.id === s.fan); send({ ...s, power: true, fan: FANS[(i + 1) % FANS.length].id }); }} />
            </View>

            {/* Température */}
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: "#121D31", borderRadius: 999, padding: 6 }}>
              <RoundBtn icon="remove" color="#38BDF8" onPress={() => send({ ...s, power: true, temp: Math.max(min, s.temp - 1) })} />
              <View style={{ alignItems: "center" }}>
                <Text style={{ fontFamily: Fonts.bodyBold, fontSize: 12, color: "#8FA3BF", letterSpacing: 1.5 }}>CONSIGNE</Text>
                <Text style={{ fontFamily: Fonts.body, fontSize: 11, color: "#5E708C" }}>{min}–{max} °C</Text>
              </View>
              <RoundBtn icon="add" color="#F97316" onPress={() => send({ ...s, power: true, temp: Math.min(max, s.temp + 1) })} />
            </View>

            <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap", justifyContent: "center" }}>
              {MODES.map((m) => (
                <Pressable key={m.id} onPress={() => send({ ...s, power: true, mode: m.id })} style={{ paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, backgroundColor: s.mode === m.id ? m.color + "33" : "#121D31", borderWidth: 1, borderColor: s.mode === m.id ? m.color : "#1E2A3F" }}>
                  <Text style={{ fontFamily: Fonts.bodyBold, fontSize: 11, color: s.mode === m.id ? m.color : "#8FA3BF" }}>{m.label}</Text>
                </Pressable>
              ))}
            </View>

            <View style={{ flexDirection: "row", gap: 8 }}>
              <Pressable onPress={() => send({ ...s, power: true, swing: !s.swing }, "swing")} style={({ pressed }) => ({ flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, height: 44, borderRadius: 14, backgroundColor: pressed ? "#1E2A3F" : s.swing ? "#8B5CF633" : "#121D31", borderWidth: 1, borderColor: s.swing ? "#8B5CF6" : "#1E2A3F" })}>
                <Ionicons name="swap-vertical" size={18} color={s.swing ? "#C4B5FD" : "#8FA3BF"} />
                <Text style={{ fontFamily: Fonts.bodyBold, fontSize: 13, color: "#C9D6E8" }}>Oscillation</Text>
              </Pressable>
              <Pressable onPress={() => send(s, s.power ? "state" : "off")} style={({ pressed }) => ({ flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, height: 44, borderRadius: 14, backgroundColor: pressed ? "#1E2A3F" : "#121D31", borderWidth: 1, borderColor: "#1E2A3F" })}>
                <Ionicons name="paper-plane-outline" size={17} color="#8FA3BF" />
                <Text style={{ fontFamily: Fonts.bodyBold, fontSize: 13, color: "#C9D6E8" }}>Renvoyer</Text>
              </Pressable>
            </View>
          </View>
          {last ? (
            <View style={{ marginTop: 12, flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 12, backgroundColor: (last.ok ? c.success : c.destructive) + "16" }}>
              <Ionicons name={last.ok ? "checkmark-circle" : "alert-circle"} size={15} color={last.ok ? c.success : c.destructive} />
              <T v="mono" style={{ fontSize: 11 }}>{last.msg}</T>
            </View>
          ) : null}
        </View>
      </Section>

      <Section title="4 · Wi-Fi & Bluetooth (applications officielles)">
        <View style={{ gap: 8 }}>
          {apps.length === 0 ? <T v="small">Aucune application connue pour cette marque.</T> : null}
          {apps.map((a) => (
            <Card key={a.app} onPress={() => openUrl(playSearchUrl(a.app))} style={{ flexDirection: "row", alignItems: "center", gap: 12, padding: 12 }}>
              <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: c.primary + "1C", alignItems: "center", justifyContent: "center" }}>
                <Ionicons name={a.link === "ble" ? "bluetooth" : "wifi"} size={20} color={c.primary} />
              </View>
              <View style={{ flex: 1, gap: 2 }}>
                <T v="h3" style={{ fontSize: 14 }}>{a.app}</T>
                <T v="small" style={{ fontSize: 12 }}>{a.link === "both" ? "Wi-Fi + Bluetooth" : a.link === "ble" ? "Bluetooth" : "Wi-Fi"}{a.note ? ` · ${a.note}` : ""}</T>
              </View>
              <Ionicons name="logo-google-playstore" size={18} color={c.mutedForeground} />
            </Card>
          ))}
          <Note>Le contrôle Wi-Fi passe par le nuage de chaque fabricant (compte requis) : l'application officielle reste la méthode fiable. Le Bluetooth sert surtout au jumelage initial du module Wi-Fi ; peu de mini-splits se pilotent directement en Bluetooth.</Note>
        </View>
      </Section>

      <Box>
        <Note>Méthode de test : allumez l'unité avec MARCHE, puis changez la consigne. Si rien ne se passe après 2 ou 3 essais à moins de 3 m, passez au protocole suivant de la liste (« Tous » pour tout afficher).</Note>
        <Note tone="warn">Fonction expérimentale (bêta). Les climatiseurs reçoivent une trame complète (mode, consigne, ventilation) à chaque touche : si l'unité ne réagit pas, essayez un autre protocole. Ne remplace pas la télécommande d'origine pour les modes de service.</Note>
        <Note>Encodeurs adaptés de la bibliothèque libre IRremoteESP8266 (crankyoldgit et contributeurs, licence LGPL-2.1).</Note>
      </Box>
      <CreditFooter extra="Télécommande HVAC" />
    </View>
  );
}

function RoundBtn({ icon, color, onPress, label, big }: { icon: keyof typeof Ionicons.glyphMap; color: string; onPress: () => void; label?: string; big?: boolean }) {
  const size = big ? 64 : 52;
  return (
    <Pressable onPress={onPress} style={{ alignItems: "center", gap: 4 }}>
      {({ pressed }) => (
        <>
          <View style={{ width: size, height: size, borderRadius: size / 2, alignItems: "center", justifyContent: "center", backgroundColor: pressed ? color + "55" : color + "22", borderWidth: 1.5, borderColor: color + "88", transform: [{ scale: pressed ? 0.94 : 1 }] }}>
            <Ionicons name={icon} size={big ? 28 : 22} color={color} />
          </View>
          {label ? <Text style={{ fontFamily: Fonts.bodyBold, fontSize: 10, color: "#8FA3BF", letterSpacing: 0.5 }}>{label.toUpperCase()}</Text> : null}
        </>
      )}
    </Pressable>
  );
}
