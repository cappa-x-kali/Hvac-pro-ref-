import { useEffect, useMemo, useState } from "react";
import { View } from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useColors } from "../hooks/use-colors";
import { useStore } from "../lib/store";
import { BRANDS, brandById } from "../data/brands";
import { BTU_OPTIONS, REFRIGERANTS } from "../data/models";
import { REF_COLORS } from "../constants/theme";
import type { SystemType } from "../data/types";
import { allModels, fmtK, MURAL_SINGLE_MAX, searchModels } from "../lib/search";
import { BrandAvatar, Btn, Card, Chip, ChipRow, Disclaimer, Empty, Hero, HeroIcon, SearchBar, Section, T } from "./ui";
import { BrandTile, ModelRow } from "./hvac";

const YEARS = (() => {
  const y = new Date().getFullYear();
  const out: number[] = [];
  for (let i = y; i >= 2000; i--) out.push(i);
  return out;
})();

export function SystemBrowser({ type, initialBtu, initialZone }: { type: SystemType; initialBtu?: number; initialZone?: "mono" | "multi" }) {
  const c = useColors();
  const { sortBrands, settings, customModels, isFavModel } = useStore();
  const [q, setQ] = useState("");
  const [brand, setBrand] = useState<string | null>(null);
  const [btu, setBtu] = useState<number | null>(null);
  const [ref, setRef] = useState<string | null>(null);
  const [zone, setZone] = useState<"mono" | "multi" | null>(null);
  const [year, setYear] = useState<number | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  useEffect(() => {
    if (initialBtu) {
      setBtu(initialBtu);
      setShowFilters(true);
    }
  }, [initialBtu]);
  useEffect(() => {
    if (initialZone) {
      setZone(initialZone);
      setShowFilters(true);
    }
  }, [initialZone]);

  const brands = useMemo(() => sortBrands(BRANDS.filter((b) => b.types.includes(type))), [sortBrands, type]);
  const all = useMemo(() => allModels(customModels).filter((m) => m.type === type), [customModels, type]);
  const counts = useMemo(() => {
    const r: Record<string, number> = {};
    all.forEach((m) => (r[m.brandId] = (r[m.brandId] ?? 0) + 1));
    return r;
  }, [all]);

  const active = !!(q.trim() || brand || btu || ref || year || zone);
  const results = useMemo(() => {
    if (!active) return [];
    const list = searchModels(q, { type, brandIds: brand ? [brand] : undefined, btu, refrigerant: ref, year }, customModels);
    const rank = (id: string) => (id === settings.primaryBrand ? 0 : settings.favoriteBrands.includes(id) ? 1 : 2);
    const list2 = zone ? list.filter((m) => (zone === "multi" ? !!m.zones : !m.zones)) : list;
    return list2.sort((a, b) => rank(a.brandId) - rank(b.brandId) || (isFavModel(b.id) ? 1 : 0) - (isFavModel(a.id) ? 1 : 0));
  }, [active, q, type, brand, btu, ref, year, zone, customModels, settings.primaryBrand, settings.favoriteBrands, isFavModel]);

  const favs = all.filter((m) => isFavModel(m.id));
  const primary = brandById(settings.primaryBrand);
  const primaryModels = primary ? all.filter((m) => m.brandId === primary.id) : [];
  const filterCount = [btu, ref, year, zone].filter(Boolean).length;
  const looksSerial = /^[A-Z]?\d{4,}[A-Z0-9]*$/i.test(q.trim()) && q.trim().length >= 8;

  const title = type === "mural" ? "Muraux" : "Centraux";
  const subtitle = type === "mural" ? "Murales 5 000 – 60 000 BTU (0,42 – 5 t)" : "Thermopompes, climatiseurs et fournaises 1,5 – 5 t";

  return (
    <View style={{ flex: 1 }}>
      <Hero
        title={title}
        subtitle={subtitle}
        right={
          <View style={{ flexDirection: "row", gap: 8 }}>
            <HeroIcon name="barcode-outline" onPress={() => router.push("/serie")} />
            <HeroIcon name="settings-outline" onPress={() => router.push("/reglages")} />
          </View>
        }
      >
        <SearchBar value={q} onChange={setQ} placeholder="Marque, modèle, n° série, BTU…" onDark />
      </Hero>

      <View style={{ marginTop: 14, gap: 10 }}>
        <ChipRow>
          <Chip label={filterCount ? `Filtres (${filterCount})` : "Filtres"} icon="options-outline" active={showFilters || filterCount > 0} onPress={() => setShowFilters(!showFilters)} />
          <Chip label="Toutes marques" active={!brand} onPress={() => setBrand(null)} />
          {brands.map((b) => (
            <Chip key={b.id} label={(b.id === settings.primaryBrand ? "★ " : "") + b.name} active={brand === b.id} color={b.color} onPress={() => setBrand(brand === b.id ? null : b.id)} />
          ))}
        </ChipRow>
        {showFilters ? (
          <View style={{ gap: 8 }}>
            <ChipRow>
              <T v="label" style={{ alignSelf: "center" }}>BTU</T>
              {BTU_OPTIONS[type].map((v) => (
                <Chip key={v} label={fmtK(v)} active={btu === v} onPress={() => setBtu(btu === v ? null : v)} />
              ))}
            </ChipRow>
            {type === "mural" ? (
              <ChipRow>
                <T v="label" style={{ alignSelf: "center" }}>Zones</T>
                <Chip label="Mono-zone" active={zone === "mono"} onPress={() => setZone(zone === "mono" ? null : "mono")} />
                <Chip label="Multizone" icon="git-network-outline" active={zone === "multi"} onPress={() => setZone(zone === "multi" ? null : "multi")} />
              </ChipRow>
            ) : null}
            <ChipRow>
              <T v="label" style={{ alignSelf: "center" }}>Réfrig.</T>
              {REFRIGERANTS.map((r) => (
                <Chip key={r} label={r} color={REF_COLORS[r]} active={ref === r} onPress={() => setRef(ref === r ? null : r)} />
              ))}
            </ChipRow>
            <ChipRow>
              <T v="label" style={{ alignSelf: "center" }}>Année</T>
              {YEARS.map((y) => (
                <Chip key={y} label={String(y)} active={year === y} onPress={() => setYear(year === y ? null : y)} />
              ))}
            </ChipRow>
          </View>
        ) : null}
      </View>

      {active ? (
        <Section
          title={`${results.length} résultat${results.length > 1 ? "s" : ""}`}
          action={<Chip label="Réinitialiser" icon="refresh" onPress={() => { setQ(""); setBrand(null); setBtu(null); setRef(null); setYear(null); setZone(null); }} />}
        >
          {looksSerial ? (
            <Card onPress={() => router.push(`/serie?s=${encodeURIComponent(q.trim())}${brand ? `&b=${brand}` : ""}`)} style={{ flexDirection: "row", alignItems: "center", gap: 12, borderColor: c.accent }}>
              <Ionicons name="barcode" size={26} color={c.accent} />
              <View style={{ flex: 1 }}>
                <T v="h3">Décoder ce numéro de série</T>
                <T v="small">Trouver l'année de fabrication de « {q.trim()} »</T>
              </View>
              <Ionicons name="chevron-forward" size={18} color={c.mutedForeground} />
            </Card>
          ) : null}
          {results.slice(0, 80).map((m) => <ModelRow key={m.id} m={m} />)}
          {results.length > 80 ? <T v="small" style={{ textAlign: "center" }}>Affinez la recherche pour voir plus de résultats.</T> : null}
          {!results.length ? <Empty icon="search" title="Aucun modèle trouvé" text={type === "mural" && btu && btu > MURAL_SINGLE_MAX ? `${fmtK(btu)} : au-delà de 36k, il s'agit de systèmes multizones (filtre « Multizone ») ou gainables. Retirez un filtre, voyez l'onglet Centraux ou ajoutez votre propre modèle.` : "Essayez une partie du numéro de modèle (ex. MSZ-FS, GWH12) ou ajoutez votre propre modèle."} /> : null}
          <Btn label="Ajouter un modèle perso" icon="add" variant="ghost" onPress={() => router.push(`/modele-perso/new?type=${type}`)} />
        </Section>
      ) : (
        <>
          {primary ? (
            <Section title="Ma marque principale">
              <Card onPress={() => router.push(`/marque/${primary.id}?type=${type}`)} style={{ flexDirection: "row", alignItems: "center", gap: 14, borderColor: c.accent, borderWidth: 2 }}>
                <BrandAvatar name={primary.name} color={primary.color} size={52} />
                <View style={{ flex: 1 }}>
                  <T v="h2">{primary.name}</T>
                  <T v="small">{primaryModels.length} modèles {type === "mural" ? "muraux" : "centraux"} · codes · manuels</T>
                </View>
                <Ionicons name="chevron-forward" size={20} color={c.mutedForeground} />
              </Card>
            </Section>
          ) : (
            <Section title="Astuce">
              <Card onPress={() => router.push("/reglages")} style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                <Ionicons name="star" size={24} color="#FFB300" />
                <View style={{ flex: 1 }}>
                  <T v="h3">Choisir ma marque principale</T>
                  <T v="small">Elle apparaîtra en premier partout (modèles, codes, recherches).</T>
                </View>
                <Ionicons name="chevron-forward" size={18} color={c.mutedForeground} />
              </Card>
            </Section>
          )}

          {favs.length ? (
            <Section title="Modèles favoris">
              {favs.slice(0, 8).map((m) => <ModelRow key={m.id} m={m} />)}
            </Section>
          ) : null}

          <Section
            title={`Marques (${brands.length})`}
            action={<Chip label="Modèle perso" icon="add" onPress={() => router.push(`/modele-perso/new?type=${type}`)} />}
          >
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
              {brands.map((b) => <BrandTile key={b.id} b={b} type={type} count={counts[b.id] ?? 0} />)}
            </View>
          </Section>
          <Disclaimer text={`Catalogue de référence (${all.length} modèles) — séries courantes au Québec. Ajoutez vos propres modèles et manuels PDF au besoin.`} />
        </>
      )}
    </View>
  );
}
