import { useEffect, useRef } from "react";
import { Animated, Easing, Image, Platform, Pressable, StyleSheet, View, useWindowDimensions } from "react-native";
import { TText as Text } from "./ttext";
import { LinearGradient } from "expo-linear-gradient";
import { Fonts } from "../constants/theme";

const SNOW = require("../assets/brand/snow.png");
const FLAME = require("../assets/brand/flame.png");
const EMBLEM = require("../assets/brand/emblem.png");
const GLOW = require("../assets/brand/glow.png");

const native = Platform.OS !== "web";
const t = (v: Animated.Value, toValue: number, duration: number, delay = 0, easing = Easing.out(Easing.cubic)) =>
  Animated.timing(v, { toValue, duration, delay, easing, useNativeDriver: native });

/** Intro animée : un flocon et une flamme se rejoignent pour former l'emblème. */
export function Intro({ onDone }: { onDone: () => void }) {
  const { width } = useWindowDimensions();
  const S = Math.min(width * 0.42, 190);
  const vals = useRef({
    snowX: new Animated.Value(-width * 0.6), flameX: new Animated.Value(width * 0.6),
    pair: new Animated.Value(0), merge: new Animated.Value(0), spin: new Animated.Value(0),
    flash: new Animated.Value(0), emblem: new Animated.Value(0), text: new Animated.Value(0),
    credits: new Animated.Value(0), out: new Animated.Value(1), flicker: new Animated.Value(0),
  }).current;
  const done = useRef(false);

  const finish = () => {
    if (done.current) return;
    done.current = true;
    t(vals.out, 0, 450, 0, Easing.inOut(Easing.quad)).start(() => onDone());
  };

  const finishRef = useRef(finish);
  finishRef.current = finish;

  useEffect(() => {
    Animated.loop(Animated.sequence([t(vals.flicker, 1, 260, 0, Easing.inOut(Easing.sin)), t(vals.flicker, 0, 300, 0, Easing.inOut(Easing.sin))])).start();
    Animated.sequence([
      Animated.parallel([
        t(vals.snowX, -S * 0.42, 1000), t(vals.flameX, S * 0.42, 1000),
        t(vals.pair, 1, 800), t(vals.spin, 1, 1500, 0, Easing.inOut(Easing.cubic)),
      ]),
      Animated.parallel([
        t(vals.snowX, 0, 420, 0, Easing.in(Easing.cubic)), t(vals.flameX, 0, 420, 0, Easing.in(Easing.cubic)),
        t(vals.merge, 1, 420, 0, Easing.in(Easing.quad)),
        Animated.sequence([t(vals.flash, 1, 260, 260), t(vals.flash, 0, 600)]),
        Animated.spring(vals.emblem, { toValue: 1, friction: 6, tension: 60, delay: 330, useNativeDriver: native }),
      ]),
      t(vals.text, 1, 600, 50),
      t(vals.credits, 1, 600),
    ]).start();
    const timer = setTimeout(() => finishRef.current(), 4300);
    return () => clearTimeout(timer);
  }, [vals, S]);

  const pairOpacity = Animated.multiply(vals.pair, vals.merge.interpolate({ inputRange: [0, 1], outputRange: [1, 0] }));
  const pairScale = vals.merge.interpolate({ inputRange: [0, 1], outputRange: [1, 0.55] });
  const rot = vals.spin.interpolate({ inputRange: [0, 1], outputRange: ["-120deg", "60deg"] });

  return (
    <Animated.View style={[StyleSheet.absoluteFill, { zIndex: 999, opacity: vals.out }]}>
      <Pressable onPress={finish} style={{ flex: 1 }}>
        <LinearGradient colors={["#03070F", "#071A33", "#03070F"]} style={StyleSheet.absoluteFill} />
        {/* lueurs froide / chaude */}
        <Animated.Image source={GLOW} style={[styles.glow, { tintColor: "#1E90FF", left: -S * 0.9, top: "22%", width: S * 2.8, height: S * 2.8, opacity: Animated.multiply(vals.pair, 0.45) }]} />
        <Animated.Image source={GLOW} style={[styles.glow, { tintColor: "#FF6A00", right: -S * 0.9, top: "30%", width: S * 2.8, height: S * 2.8, opacity: Animated.multiply(vals.pair, 0.4) }]} />

        <View style={styles.center}>
          <View style={{ width: S * 2, height: S * 1.4, alignItems: "center", justifyContent: "center" }}>
            <Animated.Image source={SNOW} resizeMode="contain" style={{ position: "absolute", width: S, height: S, opacity: pairOpacity, transform: [{ translateX: vals.snowX }, { scale: pairScale }, { rotate: rot }] }} />
            <Animated.Image
              source={FLAME}
              resizeMode="contain"
              style={{
                position: "absolute", width: S * 1.05, height: S * 1.2, opacity: pairOpacity,
                transform: [{ translateX: vals.flameX }, { scale: pairScale }, { scaleY: vals.flicker.interpolate({ inputRange: [0, 1], outputRange: [1, 1.07] }) }],
              }}
            />
            <Animated.Image source={GLOW} style={[styles.glow, { width: S * 2.4, height: S * 2.4, opacity: Animated.multiply(vals.flash, 0.9), transform: [{ scale: vals.flash.interpolate({ inputRange: [0, 1], outputRange: [0.3, 1.2] }) }] }]} />
            <Animated.Image
              source={EMBLEM}
              resizeMode="contain"
              style={{ position: "absolute", width: S * 1.25, height: S * 1.25, opacity: vals.emblem.interpolate({ inputRange: [0, 0.3, 1], outputRange: [0, 1, 1] }), transform: [{ scale: vals.emblem.interpolate({ inputRange: [0, 1], outputRange: [0.35, 1] }) }] }}
            />
          </View>

          <Animated.View style={{ alignItems: "center", marginTop: 18, opacity: vals.text, transform: [{ translateY: vals.text.interpolate({ inputRange: [0, 1], outputRange: [18, 0] }) }] }}>
            <Text style={styles.title}>
              <Text style={{ color: "#7FD3FF" }}>HVAC </Text>
              <Text style={{ color: "#FFFFFF" }}>Pro </Text>
              <Text style={{ color: "#FF9A3D" }}>Ref</Text>
            </Text>
            <View style={styles.rule}>
              <LinearGradient colors={["#2EA8FF", "#FFFFFF", "#FF7A1A"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ flex: 1 }} />
            </View>
            <Text style={styles.tag}>CLIMATISATION · CHAUFFAGE · DIAGNOSTIC</Text>
          </Animated.View>
        </View>

        <Animated.View style={[styles.credits, { opacity: vals.credits }]}>
          <Image source={EMBLEM} style={{ width: 18, height: 18, opacity: 0.8 }} />
          <Text style={styles.by}>Création et conception · <Text style={{ color: "#FFFFFF", fontFamily: Fonts.bodyBold }}>Jean Marion</Text></Text>
          <Text style={styles.small}>Crédits · Cappa-X Tools</Text>
          <Text style={[styles.small, { marginTop: 10, opacity: 0.5 }]}>Toucher pour passer</Text>
        </Animated.View>
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  glow: { position: "absolute" },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  title: { fontFamily: Fonts.display, fontSize: 38, letterSpacing: -0.8 },
  rule: { width: 150, height: 2, borderRadius: 2, overflow: "hidden", marginTop: 10, marginBottom: 10 },
  tag: { fontFamily: Fonts.bodyBold, fontSize: 11, letterSpacing: 2.4, color: "rgba(255,255,255,0.7)" },
  credits: { position: "absolute", bottom: 48, left: 0, right: 0, alignItems: "center", gap: 4 },
  by: { fontFamily: Fonts.body, fontSize: 14, color: "rgba(255,255,255,0.75)" },
  small: { fontFamily: Fonts.body, fontSize: 12, color: "rgba(255,255,255,0.55)", letterSpacing: 0.5 },
});
