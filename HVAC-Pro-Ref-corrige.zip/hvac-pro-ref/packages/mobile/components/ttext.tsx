import { Text, type TextProps } from "react-native";
import { trNode, useLang } from "../lib/i18n";

/** <Text> qui traduit automatiquement ses enfants selon la langue choisie. */
export function TText({ children, ...props }: TextProps) {
  const lang = useLang();
  return <Text {...props}>{trNode(children, lang)}</Text>;
}
