import { Image, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useColors } from "../hooks/use-colors";
import { Fonts } from "../constants/theme";
import { T } from "./ui";
import type { Severity } from "../data/code-details";

const FACES = {
  calme: require("../assets/tech/calme.png"),
  attentif: require("../assets/tech/attentif.png"),
  inquiet: require("../assets/tech/inquiet.png"),
  alarme: require("../assets/tech/alarme.png"),
};

const HEADS = {
  calme: require("../assets/tech/face-calme.png"),
  attentif: require("../assets/tech/face-attentif.png"),
  inquiet: require("../assets/tech/face-inquiet.png"),
  alarme: require("../assets/tech/face-alarme.png"),
};

export type Mood = keyof typeof FACES;

export const moodFor = (s: Severity): Mood => (s === "info" || s === "faible" ? "calme" : s === "moyen" ? "attentif" : s === "élevé" ? "inquiet" : "alarme");

const LINES: Record<Mood, { head: string; text: string }> = {
  calme: { head: "Pas de panique", text: "Information ou défaut mineur. Vérifie les bases et laisse passer les délais de protection." },
  attentif: { head: "On regarde ça de près", text: "Défaut à diagnostiquer, l'appareil peut fonctionner en mode dégradé. Suis les étapes dans l'ordre." },
  inquiet: { head: "Ça mérite une intervention", text: "L'appareil est probablement à l'arrêt. Mesure avant de remplacer quoi que ce soit." },
  alarme: { head: "Stop — sécurité d'abord", text: "Défaut critique. Coupe l'alimentation et lis l'encadré sécurité avant d'ouvrir l'appareil." },
};

export function severityColor(s: Severity, c: ReturnType<typeof useColors>) {
  return s === "info" || s === "faible" ? c.success : s === "moyen" ? c.warning : c.destructive;
}

/** Visage seul, dans un médaillon */
export function TechFace({ mood, size = 44, ring }: { mood: Mood; size?: number; ring?: string }) {
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, overflow: "hidden", backgroundColor: "#DCE7F3", borderWidth: ring ? 2 : 0, borderColor: ring }}>
      <Image source={HEADS[mood]} style={{ width: size, height: size }} resizeMode="cover" />
    </View>
  );
}

/** Carte « Avis du technicien » avec expression selon la gravité */
export function TechnicianCard({ severity, label }: { severity: Severity; label: string }) {
  const c = useColors();
  const mood = moodFor(severity);
  const col = severityColor(severity, c);
  const line = LINES[mood];
  const level = { info: 1, faible: 1, moyen: 2, élevé: 3, critique: 4 }[severity];
  return (
    <View style={{ borderRadius: 22, overflow: "hidden", borderWidth: 1, borderColor: col + "55", backgroundColor: c.card, flexDirection: "row", minHeight: 170 }}>
      <LinearGradient colors={[col + "33", col + "08"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ width: 128, alignItems: "center", justifyContent: "flex-end", overflow: "hidden" }}>
        <Image source={FACES[mood]} style={{ width: 132, height: 196, marginBottom: -26 }} resizeMode="contain" />
      </LinearGradient>
      <View style={{ flex: 1, padding: 14, gap: 6, justifyContent: "center" }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <Ionicons name="chatbubble-ellipses" size={14} color={col} />
          <T v="label" color={col}>Avis du technicien</T>
        </View>
        <T v="h3" style={{ fontSize: 17 }}>{line.head}</T>
        <T v="small" style={{ color: c.foreground, opacity: 0.85 }}>{line.text}</T>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 4 }}>
          {[1, 2, 3, 4].map((i) => (
            <View key={i} style={{ flex: 1, height: 6, borderRadius: 3, backgroundColor: i <= level ? col : c.muted }} />
          ))}
        </View>
        <T v="small" style={{ fontFamily: Fonts.bodyBold, color: col }}>Gravité : {label}</T>
      </View>
    </View>
  );
}
