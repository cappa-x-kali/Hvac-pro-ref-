import { type ReactNode } from "react";
import { Image, Pressable, ScrollView, Text, TextInput, View, type TextStyle, type ViewStyle, type TextInputProps, KeyboardAvoidingView, Platform } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useColors } from "../hooks/use-colors";
import { Fonts, REF_COLORS } from "../constants/theme";
import { tr, trNode, useLang } from "../lib/i18n";

/** Caractères absents de Sora (police titres) : on bascule sur Manrope pour éviter les carrés ☒ sur Android. */
const SORA_MISSING = /[≈→←√Δ↔★▲▾▸─═≤≥−]/;
const hasMissing = (n: ReactNode): boolean => (typeof n === "string" ? SORA_MISSING.test(n) : Array.isArray(n) ? n.some(hasMissing) : false);
/** Retire l'étoile texte (absente des polices) pour l'afficher en icône. */
const splitStar = (label: string) => (label.startsWith("★ ") ? { star: true, text: label.slice(2) } : { star: false, text: label });

export function T({ children, style, v = "body", color, numberOfLines }: { children: ReactNode; style?: TextStyle | TextStyle[]; v?: "h1" | "h2" | "h3" | "body" | "small" | "label" | "num" | "mono"; color?: string; numberOfLines?: number }) {
  const c = useColors();
  const lang = useLang();
  const kids = trNode(children, lang);
  const base: Record<string, TextStyle> = {
    h1: { fontFamily: Fonts.display, fontSize: 28, lineHeight: 34, letterSpacing: -0.5 },
    h2: { fontFamily: Fonts.display, fontSize: 20, lineHeight: 26, letterSpacing: -0.3 },
    h3: { fontFamily: Fonts.displaySemi, fontSize: 16, lineHeight: 22 },
    body: { fontFamily: Fonts.body, fontSize: 15, lineHeight: 22 },
    small: { fontFamily: Fonts.body, fontSize: 13, lineHeight: 18, color: c.mutedForeground },
    label: { fontFamily: Fonts.bodyBold, fontSize: 11, letterSpacing: 1.1, textTransform: "uppercase", color: c.mutedForeground },
    num: { fontFamily: Fonts.display, fontSize: 34, lineHeight: 40, letterSpacing: -1 },
    mono: { fontFamily: Fonts.mono, fontSize: 14 },
  };
  return (
    <Text numberOfLines={numberOfLines} style={[{ color: c.foreground }, base[v], color ? { color } : null, style as TextStyle, (v === "h1" || v === "h2" || v === "h3" || v === "num") && hasMissing(kids) ? { fontFamily: Fonts.bodyBold } : null]}>
      {kids}
    </Text>
  );
}

export function Screen({ children, scroll = true, padded = true }: { children: ReactNode; scroll?: boolean; padded?: boolean }) {
  const c = useColors();
  return (
    <SafeAreaView edges={["left", "right"]} style={{ flex: 1, backgroundColor: c.background }}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        {scroll ? (
          <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingBottom: 48 }}>
            {children}
          </ScrollView>
        ) : (
          <View style={{ flex: 1, padding: padded ? 0 : 0 }}>{children}</View>
        )}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const EMBLEM = require("../assets/brand/emblem.png");

export function Hero({ title, subtitle, back, right, children, compact }: { title: string; subtitle?: string; back?: boolean; right?: ReactNode; children?: ReactNode; compact?: boolean }) {
  const c = useColors();
  return (
    <View>
      <LinearGradient colors={[c.primary, c.primaryDeep, c.dark ? "#03070F" : c.primaryDeep]} locations={[0, 0.7, 1]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ borderBottomLeftRadius: 30, borderBottomRightRadius: 30, overflow: "hidden" }}>
        <SafeAreaView edges={["top"]}>
          <Image source={EMBLEM} style={{ position: "absolute", right: -50, top: -10, width: 210, height: 210, opacity: 0.1 }} />
          <View style={{ position: "absolute", left: -80, bottom: -90, width: 220, height: 220, borderRadius: 110, backgroundColor: "#2EA8FF", opacity: 0.12 }} />
          <View style={{ position: "absolute", right: 30, bottom: -60, width: 140, height: 140, borderRadius: 70, backgroundColor: "#FF7A1A", opacity: 0.12 }} />
          <View style={{ paddingHorizontal: 20, paddingTop: 10, paddingBottom: compact ? 20 : 26, gap: 6 }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", minHeight: 40 }}>
              {back ? (
                <Pressable onPress={() => (router.canGoBack() ? router.back() : router.replace("/"))} hitSlop={12} style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(255,255,255,0.16)", borderWidth: 1, borderColor: "rgba(255,255,255,0.18)", alignItems: "center", justifyContent: "center" }}>
                  <Ionicons name="chevron-back" size={22} color={c.heroText} />
                </Pressable>
              ) : (
                <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                  <Image source={EMBLEM} style={{ width: 26, height: 26 }} />
                  <Text style={{ fontFamily: Fonts.bodyBold, fontSize: 11, letterSpacing: 2, color: c.heroText, opacity: 0.85 }}>HVAC PRO REF</Text>
                </View>
              )}
              {right}
            </View>
            <T v="h1" color={c.heroText}>{title}</T>
            {subtitle ? <T v="body" color={c.heroText} style={{ opacity: 0.8 }}>{subtitle}</T> : null}
            {children ? <View style={{ marginTop: 10 }}>{children}</View> : null}
          </View>
        </SafeAreaView>
        <LinearGradient colors={["#2EA8FF", "rgba(255,255,255,0.6)", "#FF7A1A"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ height: 3, marginHorizontal: 60, marginBottom: 0, borderRadius: 2, opacity: 0.9 }} />
      </LinearGradient>
    </View>
  );
}

export function HeroIcon({ name, onPress, active }: { name: keyof typeof Ionicons.glyphMap; onPress: () => void; active?: boolean }) {
  const c = useColors();
  return (
    <Pressable onPress={onPress} hitSlop={10} style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: active ? c.accent : "rgba(255,255,255,0.16)", alignItems: "center", justifyContent: "center" }}>
      <Ionicons name={name} size={20} color={active ? c.accentForeground : c.heroText} />
    </Pressable>
  );
}

export function Card({ children, style, onPress }: { children: ReactNode; style?: ViewStyle; onPress?: () => void }) {
  const c = useColors();
  const s: ViewStyle = {
    backgroundColor: c.card, borderRadius: 18, borderWidth: 1, borderColor: c.border, padding: 16,
    shadowColor: "#0B1B33", shadowOpacity: c.dark ? 0 : 0.06, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: c.dark ? 0 : 2,
  };
  if (onPress) return <Pressable onPress={onPress} style={({ pressed }) => [s, style, { opacity: pressed ? 0.85 : 1, transform: [{ scale: pressed ? 0.99 : 1 }] }]}>{children}</Pressable>;
  return <View style={[s, style]}>{children}</View>;
}

export function Section({ title, action, children, style }: { title: string; action?: ReactNode; children: ReactNode; style?: ViewStyle }) {
  return (
    <View style={[{ paddingHorizontal: 16, marginTop: 22, gap: 10 }, style]}>
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
        <T v="label">{title}</T>
        {action}
      </View>
      {children}
    </View>
  );
}

export function Chip({ label, active, onPress, color, icon }: { label: string; active?: boolean; onPress?: () => void; color?: string; icon?: keyof typeof Ionicons.glyphMap }) {
  const c = useColors();
  const lang = useLang();
  const bg = active ? color ?? c.primary : c.card;
  const { star, text } = splitStar(tr(label, lang));
  return (
    <Pressable onPress={onPress} style={{ flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 999, backgroundColor: bg, borderWidth: 1, borderColor: active ? bg : c.border }}>
      {icon ? <Ionicons name={icon} size={14} color={active ? c.primaryForeground : c.mutedForeground} /> : null}
      {star ? <Ionicons name="star" size={12} color={active ? (color ? "#fff" : c.primaryForeground) : c.accent} /> : null}
      <Text style={{ fontFamily: Fonts.bodyBold, fontSize: 13, color: active ? (color ? "#fff" : c.primaryForeground) : c.foreground }}>{text}</Text>
    </Pressable>
  );
}

export function ChipRow({ children }: { children: ReactNode }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingHorizontal: 16 }}>
      {children}
    </ScrollView>
  );
}

export function SearchBar({ value, onChange, placeholder, onDark }: { value: string; onChange: (s: string) => void; placeholder?: string; onDark?: boolean }) {
  const c = useColors();
  const lang = useLang();
  return (
    <View style={{ flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: onDark ? "rgba(255,255,255,0.96)" : c.card, borderRadius: 16, paddingHorizontal: 14, height: 50, borderWidth: onDark ? 0 : 1, borderColor: c.border }}>
      <Ionicons name="search" size={20} color={onDark ? "#5B6B80" : c.mutedForeground} />
      <TextInput
        value={value}
        onChangeText={onChange}
        placeholder={placeholder ? tr(placeholder, lang) : placeholder}
        placeholderTextColor={onDark ? "#8796A8" : c.mutedForeground}
        autoCapitalize="characters"
        autoCorrect={false}
        style={{ flex: 1, fontFamily: Fonts.body, fontSize: 15, color: onDark ? "#0E1726" : c.foreground, outlineStyle: "none" } as unknown as TextStyle}
      />
      {value ? (
        <Pressable onPress={() => onChange("")} hitSlop={10}>
          <Ionicons name="close-circle" size={20} color={onDark ? "#8796A8" : c.mutedForeground} />
        </Pressable>
      ) : null}
    </View>
  );
}

export function Field({ label, suffix, ...props }: TextInputProps & { label?: string; suffix?: string }) {
  const c = useColors();
  const lang = useLang();
  return (
    <View style={{ gap: 6, flex: 1 }}>
      {label ? <T v="label">{label}</T> : null}
      <View style={{ flexDirection: "row", alignItems: "center", backgroundColor: c.muted, borderRadius: 12, paddingHorizontal: 12, minHeight: 48, borderWidth: 1, borderColor: c.border }}>
        <TextInput
          placeholderTextColor={c.mutedForeground}
          {...props}
          placeholder={props.placeholder ? tr(props.placeholder, lang) : props.placeholder}
          style={[{ flex: 1, fontFamily: Fonts.bodyBold, fontSize: 16, color: c.foreground, paddingVertical: 10, outlineStyle: "none" } as unknown as TextStyle, props.style as TextStyle]}
        />
        {suffix ? <T v="small" style={{ marginLeft: 6 }}>{suffix}</T> : null}
      </View>
    </View>
  );
}

export function Btn({ label, onPress, icon, variant = "primary", style, disabled }: { label: string; onPress: () => void; icon?: keyof typeof Ionicons.glyphMap; variant?: "primary" | "ghost" | "accent" | "danger"; style?: ViewStyle; disabled?: boolean }) {
  const c = useColors();
  const lang = useLang();
  const map = {
    primary: { bg: c.primary, fg: c.primaryForeground, bd: c.primary },
    accent: { bg: c.accent, fg: c.accentForeground, bd: c.accent },
    ghost: { bg: "transparent", fg: c.foreground, bd: c.border },
    danger: { bg: "transparent", fg: c.destructive, bd: c.destructive },
  }[variant];
  return (
    <Pressable disabled={disabled} onPress={onPress} style={({ pressed }) => [{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, height: 48, paddingHorizontal: 18, borderRadius: 14, backgroundColor: map.bg, borderWidth: 1, borderColor: map.bd, opacity: disabled ? 0.5 : pressed ? 0.85 : 1 }, style]}>
      {icon ? <Ionicons name={icon} size={18} color={map.fg} /> : null}
      <Text style={{ fontFamily: Fonts.bodyBold, fontSize: 15, color: map.fg }}>{tr(label, lang)}</Text>
    </Pressable>
  );
}

export function Segmented<V extends string>({ options, value, onChange }: { options: { value: V; label: string }[]; value: V; onChange: (v: V) => void }) {
  const c = useColors();
  const lang = useLang();
  return (
    <View style={{ flexDirection: "row", backgroundColor: c.muted, borderRadius: 14, padding: 4, gap: 4, borderWidth: 1, borderColor: c.border }}>
      {options.map((o) => {
        const a = o.value === value;
        return (
          <Pressable key={o.value} onPress={() => onChange(o.value)} style={{ flex: 1, paddingVertical: 9, borderRadius: 10, alignItems: "center", backgroundColor: a ? c.card : "transparent", borderWidth: a ? 1 : 0, borderColor: c.border }}>
            <Text numberOfLines={1} style={{ fontFamily: Fonts.bodyBold, fontSize: 13, color: a ? c.primary : c.mutedForeground }}>{tr(o.label, lang)}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export function BrandAvatar({ name, color, size = 44 }: { name: string; color: string; size?: number }) {
  const initials = name.replace(/[^A-Za-zÀ-ÿ& ]/g, "").split(/[\s-]+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
  return (
    <View style={{ width: size, height: size, borderRadius: size / 3, backgroundColor: color, alignItems: "center", justifyContent: "center" }}>
      <Text style={{ fontFamily: Fonts.display, color: "#fff", fontSize: size * 0.36 }}>{initials}</Text>
    </View>
  );
}

export function RefBadge({ r }: { r: string }) {
  const col = REF_COLORS[r] ?? "#777";
  return (
    <View style={{ paddingHorizontal: 8, paddingVertical: 3, borderRadius: 999, backgroundColor: col + "22", borderWidth: 1, borderColor: col + "66" }}>
      <Text style={{ fontFamily: Fonts.bodyBold, fontSize: 11, color: col }}>{r}</Text>
    </View>
  );
}

export function Pill({ label, color }: { label: string; color?: string }) {
  const c = useColors();
  const lang = useLang();
  const { star, text } = splitStar(tr(label, lang));
  return (
    <View style={{ flexDirection: "row", alignItems: "center", gap: 3, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 999, backgroundColor: color ? color + "22" : c.muted }}>
      {star ? <Ionicons name="star" size={10} color={color ?? c.mutedForeground} /> : null}
      <Text style={{ fontFamily: Fonts.bodyBold, fontSize: 11, color: color ?? c.mutedForeground }}>{text}</Text>
    </View>
  );
}

export function Result({ label, value, unit, sub, tone = "primary" }: { label: string; value: string; unit?: string; sub?: string; tone?: "primary" | "accent" | "success" | "warning" | "destructive" }) {
  const c = useColors();
  const col = c[tone];
  return (
    <View style={{ flex: 1, minWidth: 140, backgroundColor: col + "14", borderRadius: 16, padding: 14, borderWidth: 1, borderColor: col + "40", gap: 2 }}>
      <T v="label" color={col}>{label}</T>
      <View style={{ flexDirection: "row", alignItems: "baseline", gap: 6, flexWrap: "wrap" }}>
        <T v="num" style={{ fontSize: 28, lineHeight: 34 }}>{value}</T>
        {unit ? <T v="small" style={{ fontFamily: Fonts.bodyBold }}>{unit}</T> : null}
      </View>
      {sub ? <T v="small">{sub}</T> : null}
    </View>
  );
}

export function Row({ children, style, gap = 10 }: { children: ReactNode; style?: ViewStyle; gap?: number }) {
  return <View style={[{ flexDirection: "row", gap, flexWrap: "wrap" }, style]}>{children}</View>;
}

export function Empty({ icon, title, text }: { icon: keyof typeof Ionicons.glyphMap; title: string; text?: string }) {
  const c = useColors();
  return (
    <View style={{ alignItems: "center", padding: 32, gap: 8 }}>
      <View style={{ width: 64, height: 64, borderRadius: 22, backgroundColor: c.muted, alignItems: "center", justifyContent: "center" }}>
        <Ionicons name={icon} size={28} color={c.mutedForeground} />
      </View>
      <T v="h3">{title}</T>
      {text ? <T v="small" style={{ textAlign: "center" }}>{text}</T> : null}
    </View>
  );
}

export function Disclaimer({ text }: { text?: string }) {
  const c = useColors();
  return (
    <View style={{ flexDirection: "row", gap: 8, padding: 12, borderRadius: 14, backgroundColor: c.warning + "18", marginHorizontal: 16, marginTop: 16 }}>
      <Ionicons name="information-circle" size={18} color={c.warning} />
      <T v="small" style={{ flex: 1, color: c.foreground }}>{text ?? "Référence terrain. Toujours valider avec le manuel officiel du fabricant et la plaque signalétique."}</T>
    </View>
  );
}
