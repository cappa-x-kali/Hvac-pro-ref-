import { useState } from "react";
import { Image, Pressable, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import type { Model } from "../data/types";
import { partsFor, partSearchUrl, terminalLabels, terminalNote, thermistorKOhm, THERMISTOR_TEMPS } from "../data/parts";
import { useColors } from "../hooks/use-colors";
import { useStore } from "../lib/store";
import { openAttachment, openUrl } from "../lib/files";
import { Fonts } from "../constants/theme";
import { Attachments } from "./attachments";
import { Btn, Card, Section, T } from "./ui";
import { CondenserHV, DiagramCard, HeatPump24V, MiniSplit115, MiniSplit230, MultiZone, WIRE_LEGEND_230 } from "./wiring";

const IMG = {
  mural: require("../assets/systems/mural.jpg"),
  central: require("../assets/systems/central.jpg"),
  cassette: require("../assets/systems/cassette.jpg"),
  gainable: require("../assets/systems/gainable.jpg"),
  console: require("../assets/systems/console.jpg"),
  multi: require("../assets/systems/multi.jpg"),
};

export type SystemKind = keyof typeof IMG;

export function systemKind(m: Model): SystemKind {
  const s = `${m.kind ?? ""} ${m.series} ${m.indoor}`.toLowerCase();
  if (/extérieure multizone|^mul|multi.*ext/.test(s) || /^mul\d/i.test(m.indoor)) return "multi";
  if (/cassette|^cas\d|^owc\d/.test(s) || /^(CAS|OWC)\d/.test(m.indoor)) return "cassette";
  if (/gainable|ducted|^duc\d/.test(s) || /^DUC\d/.test(m.indoor)) return "gainable";
  if (/console|plancher|plafond|^con\d|^flr\d/.test(s) || /^(CON|FLR)\d/.test(m.indoor)) return "console";
  return m.type === "central" ? "central" : "mural";
}

const KIND_LABEL: Record<SystemKind, string> = {
  mural: "Mini-split mural + unité extérieure",
  central: "Thermopompe centrale + air handler",
  cassette: "Cassette au plafond",
  gainable: "Unité gainable (ducted)",
  console: "Console / plancher-plafond",
  multi: "Unité extérieure multizone",
};

const g = (q: string) => `https://www.google.com/search?q=${encodeURIComponent(q)}`;

export function SystemImage({ m, brand }: { m: Model; brand: string }) {
  const c = useColors();
  const { docsFor, saveModelDocs } = useStore();
  const docs = docsFor(m.id);
  const photos = docs.photos.filter((p) => p.kind === "image");
  const [idx, setIdx] = useState(0);
  const kind = systemKind(m);
  const mine = photos[idx];
  const model = (m.outdoor || m.indoor).replace(/\*/g, "");
  return (
    <Card style={{ padding: 0, overflow: "hidden" }}>
      <Pressable onPress={() => (mine ? openAttachment(mine) : undefined)}>
        <View style={{ width: "100%", aspectRatio: 4 / 3, backgroundColor: c.muted }}>
          <Image source={mine ? { uri: mine.uri } : IMG[kind]} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, width: "100%", height: "100%" }} resizeMode="cover" />
        </View>
        <View style={{ position: "absolute", left: 10, bottom: 10, backgroundColor: "rgba(14,23,38,0.72)", borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4 }}>
          <T v="small" style={{ color: "#fff", fontFamily: Fonts.bodyBold }}>{mine ? `Ma photo ${idx + 1}/${photos.length}` : `Illustration · ${KIND_LABEL[kind]}`}</T>
        </View>
      </Pressable>
      {photos.length > 1 ? (
        <View style={{ flexDirection: "row", gap: 6, padding: 10, paddingBottom: 0 }}>
          {photos.map((p, i) => (
            <Pressable key={p.uri + i} onPress={() => setIdx(i)}>
              <Image source={{ uri: p.uri }} style={{ width: 44, height: 44, borderRadius: 8, borderWidth: 2, borderColor: i === idx ? c.primary : "transparent" }} />
            </Pressable>
          ))}
        </View>
      ) : null}
      <View style={{ padding: 12, gap: 10 }}>
        <Btn label="Photos réelles du modèle (Google Images)" icon="images-outline" variant="ghost" onPress={() => openUrl(`https://www.google.com/search?tbm=isch&q=${encodeURIComponent(`${brand} ${model}`)}`)} />
        <Attachments items={docs.photos} onChange={(photos) => { saveModelDocs(m.id, { photos }); setIdx(0); }} pdfLabel="Fichier" />
        <T v="small">Ajoutez vos photos de l'installation ou de la plaque signalétique : elles remplacent l'illustration.</T>
      </View>
    </Card>
  );
}

export function PartsTab({ m, brand }: { m: Model; brand: string }) {
  const c = useColors();
  const { docsFor, saveModelDocs } = useStore();
  const docs = docsFor(m.id);
  const [open, setOpen] = useState<string | null>(null);
  const model = (m.outdoor || m.indoor).replace(/\*/g, "");
  return (
    <>
      <Section title="Liste de pièces officielle">
        <Card onPress={() => openUrl(g(`${brand} ${model} parts list exploded view filetype:pdf`))} style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <Ionicons name="list-circle-outline" size={28} color={c.primary} />
          <View style={{ flex: 1 }}>
            <T v="h3" style={{ fontSize: 15 }}>Vue éclatée / liste de pièces (PDF)</T>
            <T v="small">Recherche · {brand} {model}</T>
          </View>
          <Ionicons name="open-outline" size={18} color={c.mutedForeground} />
        </Card>
        <Card onPress={() => openUrl(`https://www.google.com/search?tbm=shop&q=${encodeURIComponent(`${brand} ${model} pièce`)}`)} style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <Ionicons name="cart-outline" size={26} color={c.accent} />
          <View style={{ flex: 1 }}>
            <T v="h3" style={{ fontSize: 15 }}>Acheter des pièces</T>
            <T v="small">Fournisseurs / boutiques en ligne</T>
          </View>
          <Ionicons name="open-outline" size={18} color={c.mutedForeground} />
        </Card>
      </Section>

      <Section title="Mes pièces & numéros (photos, PDF)">
        <Attachments items={docs.parts} onChange={(parts) => saveModelDocs(m.id, { parts })} pdfLabel="Ajouter un PDF" />
      </Section>

      {partsFor(m.type).map((grp) => (
        <Section key={grp.title} title={grp.title}>
          <Card style={{ padding: 0, overflow: "hidden" }}>
            {grp.parts.map((p, i) => {
              const k = grp.title + p.name;
              const isOpen = open === k;
              return (
                <View key={k} style={{ borderTopWidth: i ? 1 : 0, borderTopColor: c.border }}>
                  <Pressable onPress={() => setOpen(isOpen ? null : k)} style={{ flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 14, paddingVertical: 12 }}>
                    <Ionicons name={grp.icon as keyof typeof Ionicons.glyphMap} size={18} color={c.primary} />
                    <View style={{ flex: 1 }}>
                      <T style={{ fontFamily: Fonts.bodyBold }}>{p.name}</T>
                      {!isOpen ? <T v="small" numberOfLines={1}>{p.desc}</T> : null}
                    </View>
                    <Ionicons name={isOpen ? "chevron-up" : "chevron-down"} size={18} color={c.mutedForeground} />
                  </Pressable>
                  {isOpen ? (
                    <View style={{ paddingHorizontal: 14, paddingBottom: 14, gap: 8 }}>
                      <T>{p.desc}</T>
                      {p.spec ? (
                        <View style={{ backgroundColor: c.muted, borderRadius: 10, padding: 10 }}>
                          <T v="label">Valeurs typiques</T>
                          <T style={{ fontFamily: Fonts.bodyBold }}>{p.spec}</T>
                        </View>
                      ) : null}
                      {p.test ? (
                        <View style={{ backgroundColor: c.primary + "12", borderRadius: 10, padding: 10 }}>
                          <T v="label">Test terrain</T>
                          <T>{p.test}</T>
                        </View>
                      ) : null}
                      <Btn label="Trouver cette pièce pour ce modèle" icon="search" variant="ghost" onPress={() => openUrl(partSearchUrl(brand, m, p.q))} />
                    </View>
                  ) : null}
                </View>
              );
            })}
          </Card>
        </Section>
      ))}

      <Section title="Table des thermistances (CTN)">
        <Card style={{ padding: 0, overflow: "hidden" }}>
          <View style={{ flexDirection: "row", backgroundColor: c.muted, paddingVertical: 8 }}>
            {["°C", "10 kΩ", "15 kΩ", "20 kΩ", "50 kΩ"].map((h) => (
              <T key={h} v="label" style={{ flex: 1, textAlign: "center" }}>{h}</T>
            ))}
          </View>
          {THERMISTOR_TEMPS.map((t) => (
            <View key={t} style={{ flexDirection: "row", paddingVertical: 7, borderTopWidth: 1, borderTopColor: c.border, backgroundColor: t === 25 ? c.primary + "12" : undefined }}>
              <T style={{ flex: 1, textAlign: "center", fontFamily: Fonts.bodyBold }}>{t}</T>
              {[10, 15, 20, 50].map((r) => (
                <T key={r} style={{ flex: 1, textAlign: "center" }}>{thermistorKOhm(r, t).toFixed(1)}</T>
              ))}
            </View>
          ))}
        </Card>
        <T v="small">Valeurs en kΩ, courbe bêta ≈ 3950 (indicatif). La courbe exacte varie selon le fabricant : voir le manuel de service.</T>
      </Section>
    </>
  );
}

export function WiringTab({ m, brand }: { m: Model; brand: string }) {
  const c = useColors();
  const { docsFor, saveModelDocs } = useStore();
  const docs = docsFor(m.id);
  const model = (m.outdoor || m.indoor).replace(/\*/g, "");
  const labels = terminalLabels(m.brandId);
  const note = terminalNote(m.brandId);
  const kind = systemKind(m);
  const only115 = m.voltage.startsWith("115 V /");
  const has115 = m.voltage.startsWith("115");
  return (
    <>
      <Section title="Schéma officiel du modèle">
        <Card onPress={() => openUrl(g(`${brand} ${model} wiring diagram filetype:pdf`))} style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <Ionicons name="git-network-outline" size={26} color={c.primary} />
          <View style={{ flex: 1 }}>
            <T v="h3" style={{ fontSize: 15 }}>Schéma électrique (PDF)</T>
            <T v="small">Recherche · {brand} {model}</T>
          </View>
          <Ionicons name="open-outline" size={18} color={c.mutedForeground} />
        </Card>
        <Card onPress={() => openUrl(g(`${brand} ${model} service manual PCB wiring diagram filetype:pdf`))} style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <Ionicons name="hardware-chip-outline" size={26} color={c.accent} />
          <View style={{ flex: 1 }}>
            <T v="h3" style={{ fontSize: 15 }}>Schéma électronique des cartes (PCB)</T>
            <T v="small">Manuel de service · connecteurs, fusibles, points de test</T>
          </View>
          <Ionicons name="open-outline" size={18} color={c.mutedForeground} />
        </Card>
        <T v="small">Astuce : le schéma exact est presque toujours collé à l'intérieur du couvercle de service (unité extérieure) ou derrière le panneau avant (intérieur). Prenez-le en photo ci-dessous.</T>
      </Section>

      <Section title="Mes schémas (photos, PDF)">
        <Attachments items={docs.wiring} onChange={(wiring) => saveModelDocs(m.id, { wiring })} pdfLabel="Ajouter un PDF" />
      </Section>

      <Section title="Schémas types">
        {m.type === "mural" && kind !== "multi" ? (
          <>
          {has115 ? (
            <DiagramCard title="Alimentation & interconnexion 115 V" sub="Mini-split 115 V / 1 ph" legend={[[c.foreground, "Ligne (noir)"], ["#9E9E9E", "Neutre (blanc)"], ["#1E88E5", "Signal"], ["#2E7D32", "Terre"]]} notes={["Disjoncteur et calibre de fil selon MCA / MOP de la plaque.", "Sectionneur à moins de 3 m et visible de l'unité (Code de l'électricité)."]}>
              <MiniSplit115 />
            </DiagramCard>
          ) : null}
          {!only115 ? (
            <DiagramCard title="Alimentation & interconnexion 208-230 V" sub={`Bornier ${labels.join(" · ")} — ${brand}`} legend={WIRE_LEGEND_230(labels)} notes={[note ?? `${labels[0]}-${labels[1]} = 230 V vers l'intérieur, ${labels[2]} = communication. Vérifier l'ordre sur le bornier.`, "Disjoncteur et calibre de fil selon MCA / MOP de la plaque.", "Ne jamais mesurer la communication avec l'unité débranchée du bornier : tension fluctuante normale."]}>
              <MiniSplit230 labels={labels} />
            </DiagramCard>
          ) : null}
          </>
        ) : null}
        {kind === "multi" || /multi/i.test(m.series) ? (
          <DiagramCard title="Multizone — interconnexion par zone" sub={`Une ligne ${labels.join("-")} par tête intérieure`} legend={WIRE_LEGEND_230(labels)} notes={["Une erreur d'appariement câble/tuyauterie cause des codes de communication ou une zone qui chauffe la mauvaise pièce.", "Plusieurs marques offrent une fonction d'auto-correction du câblage (voir manuel)."]}>
            <MultiZone labels={labels} />
          </DiagramCard>
        ) : null}
        {m.type === "central" && kind !== "multi" ? (
          <>
            <DiagramCard title="Thermostat 24 V — thermopompe" sub="Thermostat → air handler → unité extérieure" legend={[["#E53935", "R"], ["#1E88E5", "C"], ["#F9A825", "Y"], ["#EF6C00", "O/B"], ["#2E7D32", "G"], ["#BDBDBD", "W2/E"]]} notes={["O = vanne alimentée en refroidissement (Carrier, Trane, Goodman, Lennox…). B = en chauffage (Rheem/Ruud). Configurer le thermostat en conséquence.", "Thermopompe inverter (Flexx, IDS…) : souvent une communication propriétaire ou un adaptateur 24 V, voir manuel."]} h={225}>
              <HeatPump24V />
            </DiagramCard>
            <DiagramCard title="Circuit haute tension — condenseur" sub="Contacteur · condensateur double · compresseur · moteur PSC" legend={[[c.foreground, "L1 / T1"], ["#E53935", "L2 / T2"], ["#F9A825", "HERM → S"], ["#6D4C41", "FAN"], ["#8E24AA", "Commun moteur"]]} notes={["Couper l'alimentation et décharger le condensateur avant intervention.", "Moteur ECM : pas de condensateur ventilateur, suivre le schéma du modèle."]} h={255}>
              <CondenserHV />
            </DiagramCard>
          </>
        ) : null}
        {m.type === "mural" ? (
          <Card style={{ gap: 6, borderLeftWidth: 4, borderLeftColor: c.destructive }}>
            <T v="h3" style={{ fontSize: 15 }}>Sécurité — électronique inverter</T>
            <T v="small">Le bus DC de la carte extérieure atteint 310–380 V DC et reste chargé plusieurs minutes après la coupure. Attendre 5–10 min et mesurer &lt; 30 V DC entre P et N avant de toucher la carte ou le compresseur.</T>
          </Card>
        ) : null}
      </Section>
    </>
  );
}
