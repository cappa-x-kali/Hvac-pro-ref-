import { View } from "react-native";
import Svg, { Circle, G, Polyline, Rect, Text as SvgText } from "react-native-svg";
import { useColors } from "../hooks/use-colors";
import { Fonts } from "../constants/theme";
import { Card, T } from "./ui";
import { tr, useLang } from "../lib/i18n";

type Pt = [number, number];

function useWire() {
  const c = useColors();
  useLang();
  return {
    c,
    L1: c.foreground, // noir
    L2: "#E53935", // rouge
    N: "#9E9E9E", // blanc / neutre
    G: "#2E7D32", // vert / nu
    S: "#1E88E5", // signal
    Y: "#F9A825",
    O: "#EF6C00",
    W: "#BDBDBD",
    B: "#6D4C41",
    V: "#8E24AA",
  };
}

function Box({ x, y, w, h, title, sub, mid }: { x: number; y: number; w: number; h: number; title: string; sub?: string; mid?: boolean }) {
  const ty = mid ? y + h / 2 : y + 14;
  const { c } = useWire();
  return (
    <G>
      <Rect x={x} y={y} width={w} height={h} rx={8} fill={c.card} stroke={c.border} strokeWidth={1.5} />
      <SvgText x={x + w / 2} y={ty} fontSize={11} fontWeight="700" fill={c.foreground} textAnchor="middle" fontFamily={Fonts.bodyBold}>{tr(title)}</SvgText>
      {sub ? <SvgText x={x + w / 2} y={ty + 11} fontSize={8} fill={c.mutedForeground} textAnchor="middle" fontFamily={Fonts.body}>{tr(sub)}</SvgText> : null}
    </G>
  );
}

function Term({ x, y, label, side = "right" }: { x: number; y: number; label: string; side?: "left" | "right" | "top" | "bottom" }) {
  const { c } = useWire();
  const dx = side === "left" ? 7 : side === "right" ? -7 : 0;
  const dy = side === "top" ? 12 : side === "bottom" ? -7 : 3;
  const anchor = side === "left" ? "start" : side === "right" ? "end" : "middle";
  return (
    <G>
      <Circle cx={x} cy={y} r={3.2} fill={c.card} stroke={c.foreground} strokeWidth={1.4} />
      <SvgText x={x + dx} y={y + dy} fontSize={9} fontWeight="700" fill={c.foreground} textAnchor={anchor} fontFamily={Fonts.bodyBold}>{tr(label)}</SvgText>
    </G>
  );
}

function Wire({ pts, color, dash }: { pts: Pt[]; color: string; dash?: boolean }) {
  return <Polyline points={pts.map((p) => p.join(",")).join(" ")} fill="none" stroke={color} strokeWidth={2.2} strokeLinejoin="round" strokeDasharray={dash ? "5,3" : undefined} />;
}

function Dot({ x, y, color }: { x: number; y: number; color: string }) {
  return <Circle cx={x} cy={y} r={3} fill={color} />;
}

function Label({ x, y, text, color, anchor = "start" }: { x: number; y: number; text: string; color?: string; anchor?: "start" | "middle" | "end" }) {
  const { c } = useWire();
  return <SvgText x={x} y={y} fontSize={8.5} fill={color ?? c.mutedForeground} textAnchor={anchor} fontFamily={Fonts.body}>{tr(text)}</SvgText>;
}

function Legend({ items }: { items: [string, string][] }) {
  const c = useColors();
  return (
    <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
      {items.map(([col, l]) => (
        <View key={l} style={{ flexDirection: "row", alignItems: "center", gap: 5 }}>
          <View style={{ width: 16, height: 4, borderRadius: 2, backgroundColor: col }} />
          <T v="small" style={{ color: c.mutedForeground }}>{l}</T>
        </View>
      ))}
    </View>
  );
}

export function DiagramCard({ title, sub, children, notes, legend, h = 230 }: { title: string; sub?: string; children: React.ReactNode; notes?: string[]; legend?: [string, string][]; h?: number }) {
  const c = useColors();
  return (
    <Card style={{ gap: 10 }}>
      <View style={{ gap: 2 }}>
        <T v="h3">{title}</T>
        {sub ? <T v="small">{sub}</T> : null}
      </View>
      <View style={{ backgroundColor: c.muted, borderRadius: 12, padding: 6 }}>
        <Svg width="100%" height={undefined} viewBox={`0 0 340 ${h}`} style={{ aspectRatio: 340 / h }}>
          {children}
        </Svg>
      </View>
      {legend ? <Legend items={legend} /> : null}
      {notes?.map((n) => (
        <T key={n} v="small">• {n}</T>
      ))}
    </Card>
  );
}

/** Alimentation + interconnexion d'un mini-split 208-230 V */
export function MiniSplit230({ labels }: { labels: [string, string, string] }) {
  const w = useWire();
  const [t1, t2, t3] = labels;
  return (
    <>
      <Box x={8} y={14} w={86} h={78} title="Panneau" sub="Disj. 2 pôles" />
      <Box x={124} y={14} w={76} h={78} title="Sectionneur" sub="extérieur" />
      <Box x={232} y={14} w={100} h={200} title="Unité ext." sub="bornier" />
      <Box x={8} y={128} w={116} h={86} title="Unité int." sub="bornier" />
      {/* ligne */}
      {([[44, "L1", w.L1], [60, "L2", w.L2], [76, "G", w.G]] as const).map(([y, l, col]) => (
        <G key={l}>
          <Wire pts={[[94, y], [124, y]]} color={col} />
          <Wire pts={[[200, y], [232, y]]} color={col} />
          <Term x={94} y={y} label={l} />
          <Term x={232} y={y} label={l} side="left" />
        </G>
      ))}
      {/* interconnexion */}
      {([[152, t1, w.L1], [168, t2, w.L2], [184, t3, w.S], [200, "G", w.G]] as const).map(([y, l, col]) => (
        <G key={`i${l}`}>
          <Wire pts={[[124, y], [232, y]]} color={col} />
          <Term x={124} y={y} label={l} />
          <Term x={232} y={y} label={l} side="left" />
        </G>
      ))}
      <Label x={178} y={120} text="Câble 14/4 AWG (pas d'épissure)" anchor="middle" />
      <Label x={178} y={226} text={`${t1}-${t2} = 230 V · ${t3} = communication`} anchor="middle" />
    </>
  );
}

/** Mini-split 115 V */
export function MiniSplit115() {
  const w = useWire();
  return (
    <>
      <Box x={8} y={14} w={86} h={78} title="Panneau" sub="Disj. 1 pôle 15–20 A" />
      <Box x={124} y={14} w={76} h={78} title="Sectionneur" sub="extérieur" />
      <Box x={232} y={14} w={100} h={200} title="Unité ext." sub="bornier" />
      <Box x={8} y={128} w={116} h={86} title="Unité int." sub="bornier" />
      {([[44, "L", w.L1], [60, "N", w.N], [76, "G", w.G]] as const).map(([y, l, col]) => (
        <G key={l}>
          <Wire pts={[[94, y], [124, y]]} color={col} />
          <Wire pts={[[200, y], [232, y]]} color={col} />
          <Term x={94} y={y} label={l} />
          <Term x={232} y={y} label={l} side="left" />
        </G>
      ))}
      {([[152, "1(L)", w.L1], [168, "2(N)", w.N], [184, "3", w.S], [200, "G", w.G]] as const).map(([y, l, col]) => (
        <G key={`i${l}`}>
          <Wire pts={[[124, y], [232, y]]} color={col} />
          <Term x={124} y={y} label={l} />
          <Term x={232} y={y} label={l} side="left" />
        </G>
      ))}
      <Label x={178} y={120} text="Câble 14/4 AWG" anchor="middle" />
      <Label x={178} y={226} text="Neutre requis : vérifier N au sectionneur" anchor="middle" />
    </>
  );
}

/** Multizone : une unité extérieure, plusieurs têtes */
export function MultiZone({ labels }: { labels: [string, string, string] }) {
  const w = useWire();
  const zones = ["A", "B", "C"];
  return (
    <>
      <Box x={8} y={14} w={96} h={196} title="Unité ext." sub="multizone" />
      {zones.map((z, i) => {
        const y0 = 14 + i * 68;
        return (
          <G key={z}>
            <Box x={236} y={y0} w={96} h={60} title={`Tête ${z}`} sub="bornier" />
            {[labels[0], labels[1], labels[2]].map((l, k) => {
              const y = y0 + 32 + k * 9;
              const col = k === 0 ? w.L1 : k === 1 ? w.L2 : w.S;
              return (
                <G key={l}>
                  <Wire pts={[[104, y], [236, y]]} color={col} />
                  <Term x={104} y={y} label={`${z}${l}`} />
                  <Circle cx={236} cy={y} r={2.6} fill={col} />
                </G>
              );
            })}
          </G>
        );
      })}
      <Label x={170} y={222} text="Respecter la paire tuyauterie / câble de chaque zone" anchor="middle" />
    </>
  );
}

/** Thermostat 24 V — thermopompe centrale */
export function HeatPump24V() {
  const w = useWire();
  const rows: [string, string, string][] = [
    ["R", "24 V (chaud)", w.L2],
    ["C", "commun", w.S],
    ["Y", "compresseur", w.Y],
    ["O/B", "vanne d'inversion", w.O],
    ["G", "ventilateur", w.G],
    ["W2/E", "appoint / urgence", w.W],
  ];
  const y0 = 46;
  return (
    <>
      <Box x={8} y={14} w={78} h={200} title="Thermostat" />
      <Box x={130} y={14} w={86} h={200} title="Air handler" sub="ou fournaise" />
      <Box x={256} y={14} w={76} h={200} title="Unité ext." sub="carte dégivrage" />
      {rows.map(([l, , col], i) => {
        const y = y0 + i * 26;
        const toOut = l !== "G";
        return (
          <G key={l}>
            <Wire pts={[[86, y], [130, y]]} color={col} />
            <Term x={86} y={y} label={l} />
            <Term x={130} y={y} label={l} side="left" />
            {toOut ? (
              <>
                <Wire pts={[[216, y], [256, y]]} color={col} dash={l === "W2/E"} />
                <Term x={216} y={y} label="" />
                <Term x={256} y={y} label={l === "W2/E" ? "W" : l} side="left" />
              </>
            ) : null}
          </G>
        );
      })}
      <Label x={236} y={208} text="W : appoint pendant le dégivrage" anchor="middle" />
    </>
  );
}

/** Circuit haute tension condenseur (contacteur, condensateur double, compresseur, ventilateur PSC) */
export function CondenserHV() {
  const w = useWire();
  return (
    <>
      <Box x={10} y={40} w={80} h={110} title="Contacteur" sub="bobine 24 V" mid />
      <Box x={128} y={30} w={96} h={70} title="Condensateur" sub="double µF" />
      <Box x={128} y={170} w={96} h={66} title="Compresseur" sub="scroll" mid />
      <Box x={256} y={76} w={76} h={86} title="Moteur vent." sub="PSC" />
      {/* alimentation */}
      <Wire pts={[[30, 8], [30, 40]]} color={w.L1} />
      <Wire pts={[[70, 8], [70, 40]]} color={w.L2} />
      <Label x={36} y={14} text="L1" />
      <Label x={76} y={14} text="L2 · 208-230 V" />
      {/* T1 → compresseur C */}
      <Wire pts={[[30, 150], [30, 160], [148, 160], [148, 170]]} color={w.L1} />
      {/* T2 → condensateur C */}
      <Wire pts={[[70, 150], [70, 120], [176, 120], [176, 100]]} color={w.L2} />
      {/* compresseur R → condensateur C (même phase que T2) */}
      <Wire pts={[[204, 170], [204, 130], [176, 130], [176, 100]]} color={w.L2} />
      {/* HERM → S */}
      <Wire pts={[[148, 100], [148, 145], [176, 145], [176, 170]]} color={w.Y} />
      {/* FAN → brun moteur */}
      <Wire pts={[[204, 100], [204, 112], [256, 112]]} color={w.B} />
      {/* noir moteur → T1 */}
      <Wire pts={[[256, 128], [240, 128], [240, 246], [16, 246], [16, 160], [30, 160]]} color={w.L1} />
      {/* blanc/violet moteur → R / T2 */}
      <Wire pts={[[256, 144], [222, 144], [222, 155], [204, 155]]} color={w.V} />
      <Dot x={204} y={155} color={w.L2} />
      <Dot x={30} y={160} color={w.L1} />
      <Term x={30} y={40} label="L1" side="top" />
      <Term x={70} y={40} label="L2" side="top" />
      <Term x={30} y={150} label="T1" side="bottom" />
      <Term x={70} y={150} label="T2" side="bottom" />
      <Term x={148} y={100} label="HERM" side="bottom" />
      <Term x={176} y={100} label="C" side="bottom" />
      <Term x={204} y={100} label="FAN" side="bottom" />
      <Term x={148} y={170} label="C" side="top" />
      <Term x={176} y={170} label="S" side="top" />
      <Term x={204} y={170} label="R" side="top" />
      <Term x={256} y={112} label="brun" side="left" />
      <Term x={256} y={128} label="noir" side="left" />
      <Term x={256} y={144} label="blanc" side="left" />
    </>
  );
}

export const WIRE_LEGEND_230 = (labels: [string, string, string]): [string, string][] => [
  ["#424242", `L1 / ${labels[0]} (noir)`],
  ["#E53935", `L2 / ${labels[1]} (rouge)`],
  ["#1E88E5", `${labels[2]} signal`],
  ["#2E7D32", "Mise à la terre"],
];
