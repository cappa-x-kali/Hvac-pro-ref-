import { Alert, Image, Platform, Pressable, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useColors } from "../hooks/use-colors";
import type { Attachment } from "../lib/store";
import { openAttachment, pickDocument, pickPhoto } from "../lib/files";
import { Btn, Card, T } from "./ui";
import { tr } from "../lib/i18n";

export function Attachments({ items, onChange, pdfLabel = "PDF / fichier" }: { items: Attachment[]; onChange: (a: Attachment[]) => void; pdfLabel?: string }) {
  const c = useColors();
  const add = async (fn: () => Promise<Attachment | null>) => {
    try {
      const a = await fn();
      if (a) onChange([...items, a]);
    } catch {
      Alert.alert(tr("Erreur"), tr("Impossible d'ajouter ce fichier."));
    }
  };
  const remove = (i: number) => {
    const doIt = () => onChange(items.filter((_, k) => k !== i));
    if (Platform.OS === "web") return doIt();
    Alert.alert(tr("Retirer la pièce jointe ?"), items[i].name, [{ text: tr("Annuler"), style: "cancel" }, { text: tr("Retirer"), style: "destructive", onPress: doIt }]);
  };
  return (
    <View style={{ gap: 10 }}>
      {items.map((a, i) => (
        <Card key={a.uri + i} onPress={() => openAttachment(a)} style={{ flexDirection: "row", alignItems: "center", gap: 12, padding: 10 }}>
          {a.kind === "image" ? (
            <Image source={{ uri: a.uri }} style={{ width: 48, height: 48, borderRadius: 10, backgroundColor: c.muted }} />
          ) : (
            <View style={{ width: 48, height: 48, borderRadius: 10, backgroundColor: c.destructive + "16", alignItems: "center", justifyContent: "center" }}>
              <Ionicons name={a.kind === "pdf" ? "document-text" : "document"} size={24} color={c.destructive} />
            </View>
          )}
          <View style={{ flex: 1 }}>
            <T v="h3" numberOfLines={1} style={{ fontSize: 14 }}>{a.name}</T>
            <T v="small">{a.kind === "pdf" ? "PDF" : a.kind === "image" ? "Photo" : "Fichier"} · toucher pour ouvrir</T>
          </View>
          <Pressable onPress={() => remove(i)} hitSlop={10}>
            <Ionicons name="trash-outline" size={20} color={c.mutedForeground} />
          </Pressable>
        </Card>
      ))}
      <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
        <Btn label={pdfLabel} icon="attach" variant="ghost" onPress={() => add(pickDocument)} style={{ flexGrow: 1 }} />
        <Btn label="Galerie" icon="images-outline" variant="ghost" onPress={() => add(() => pickPhoto(false))} style={{ flexGrow: 1 }} />
        {Platform.OS !== "web" ? <Btn label="Photo" icon="camera-outline" variant="ghost" onPress={() => add(() => pickPhoto(true))} style={{ flexGrow: 1 }} /> : null}
      </View>
    </View>
  );
}
