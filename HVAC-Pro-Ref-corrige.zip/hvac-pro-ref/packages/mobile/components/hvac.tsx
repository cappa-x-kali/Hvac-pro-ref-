import { useState } from "react";
import { Pressable, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useColors } from "../hooks/use-colors";
import { Fonts } from "../constants/theme";
import { useStore, type CustomModel, type Note } from "../lib/store";
import { BrandAvatar, Card, Pill, RefBadge, T } from "./ui";
import { brandById } from "../data/brands";
import type { Brand, CodeSet, ErrorCode, Model } from "../data/types";
import { categorize, codeKey, SEVERITY_LABEL } from "../data/code-details";
import { TechFace, moodFor, severityColor } from "./technician";
import { brandName, fmtBtu, fmtYears } from "../lib/search";
import { loc } from "../lib/i18n";

export function FavStar({ active, onPress, size = 22, light }: { active: boolean; onPress: () => void; size?: number; light?: boolean }) {
  const c = useColors();
  return (
    <Pressable onPress={onPress} hitSlop={12}>
      <Ionicons name={active ? "star" : "star-outline"} size={size} color={active ? "#FFB300" : light ? c.heroText : c.mutedForeground} />
    </Pressable>
  );
}

export function ModelRow({ m }: { m: Model | CustomModel }) {
  const c = useColors();
  const { isFavModel, toggleFavoriteModel } = useStore();
  const b = brandById(m.brandId);
  const name = brandName(m);
  return (
    <Card onPress={() => router.push(`/modele/${encodeURIComponent(m.id)}`)} style={{ padding: 14 }}>
      <View style={{ flexDirection: "row", gap: 12, alignItems: "center" }}>
        <BrandAvatar name={name || "?"} color={b?.color ?? c.accent} size={42} />
        <View style={{ flex: 1, gap: 3 }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
            <T v="small" numberOfLines={1} style={{ flexShrink: 1 }}>{name} · {m.series}</T>
            {m.custom ? <Pill label="PERSO" color={c.accent} /> : null}
            {m.zones ? <Pill label="MULTI" color={c.primary} /> : null}
          </View>
          <T v="h3" numberOfLines={1}>{m.indoor}</T>
          <View style={{ flexDirection: "row", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
            <Pill label={fmtBtu(m.btu)} />
            <RefBadge r={m.refrigerant} />
            <T v="small">{fmtYears(m)}</T>
          </View>
        </View>
        <FavStar active={isFavModel(m.id)} onPress={() => toggleFavoriteModel(m.id)} />
      </View>
    </Card>
  );
}

export function BrandTile({ b, type, count }: { b: Brand; type?: string; count?: number }) {
  const c = useColors();
  const { isFavBrand, toggleFavoriteBrand, settings } = useStore();
  const primary = settings.primaryBrand === b.id;
  return (
    <Card onPress={() => router.push(`/marque/${b.id}${type ? `?type=${type}` : ""}`)} style={{ padding: 14, width: "48%", flexGrow: 1, borderColor: primary ? c.accent : c.border, borderWidth: primary ? 2 : 1 }}>
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
        <BrandAvatar name={b.name} color={b.color} size={40} />
        <FavStar active={isFavBrand(b.id)} onPress={() => toggleFavoriteBrand(b.id)} size={20} />
      </View>
      <T v="h3" numberOfLines={1} style={{ marginTop: 10 }}>{b.name}</T>
      <T v="small" numberOfLines={1}>{primary ? "Marque principale" : count != null ? `${count} modèles` : b.origin}</T>
    </Card>
  );
}

export function CodeCard({ code, set, setName, brands, defaultOpen }: { code: ErrorCode; set?: CodeSet; setName?: string; brands?: string[]; defaultOpen?: boolean }) {
  const c = useColors();
  const [open, setOpen] = useState(!!defaultOpen);
  const cat = set ? categorize(code, set) : undefined;
  const sevCol = cat ? severityColor(cat.severity, c) : c.mutedForeground;
  return (
    <Card onPress={() => setOpen(!open)} style={{ padding: 14 }}>
      <View style={{ flexDirection: "row", gap: 12, alignItems: "center" }}>
        <View style={{ minWidth: 62, paddingHorizontal: 8, height: 44, borderRadius: 12, backgroundColor: c.destructive + "16", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: c.destructive + "40" }}>
          <T v="h3" color={c.destructive} style={{ fontSize: code.code.length > 6 ? 12 : 15 }}>{code.code}</T>
        </View>
        <View style={{ flex: 1 }}>
          <T v="h3" style={{ fontSize: 15 }}>{code.title}</T>
          {setName ? <T v="small" numberOfLines={1}>{setName}</T> : null}
        </View>
        <Ionicons name={open ? "chevron-up" : "chevron-down"} size={18} color={c.mutedForeground} />
      </View>
      {open ? (
        <View style={{ marginTop: 12, gap: 10 }}>
          {cat ? (
            <View style={{ flexDirection: "row", gap: 10, alignItems: "center" }}>
              <TechFace mood={moodFor(cat.severity)} size={40} ring={sevCol} />
              <View style={{ flex: 1, flexDirection: "row", gap: 6, flexWrap: "wrap" }}>
                <Pill label={`Gravité : ${SEVERITY_LABEL[cat.severity]}`} color={sevCol} />
                <Pill label={cat.label} color={c.primary} />
              </View>
            </View>
          ) : null}
          <View style={{ gap: 2 }}>
            <T v="label" color={c.warning}>Causes probables</T>
            <T>{code.causes}</T>
          </View>
          <View style={{ gap: 2 }}>
            <T v="label" color={c.success}>Diagnostic / correctif</T>
            <T>{code.fix}</T>
          </View>
          {brands?.length ? (
            <View style={{ flexDirection: "row", gap: 6, flexWrap: "wrap" }}>
              {brands.map((id) => <Pill key={id} label={brandById(id)?.name ?? id} />)}
            </View>
          ) : null}
          {set ? (
            <Pressable onPress={() => router.push(`/code/${codeKey(set.id, code.code)}`)} style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingVertical: 11, borderRadius: 12, backgroundColor: c.primary }}>
              <Ionicons name="document-text-outline" size={16} color={c.primaryForeground} />
              <T style={{ fontFamily: Fonts.bodyBold, color: c.primaryForeground }}>Voir le détail complet</T>
              <Ionicons name="chevron-forward" size={16} color={c.primaryForeground} />
            </Pressable>
          ) : null}
        </View>
      ) : null}
    </Card>
  );
}

export function NoteCard({ n }: { n: Note }) {
  const c = useColors();
  const b = brandById(n.brandId);
  return (
    <Card onPress={() => router.push(`/note/${n.id}`)} style={{ padding: 14, gap: 6 }}>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
        {n.pinned ? <Ionicons name="pin" size={14} color={c.accent} /> : null}
        <T v="h3" numberOfLines={1} style={{ flex: 1 }}>{n.title || "Sans titre"}</T>
        <T v="small">{new Date(n.updatedAt).toLocaleDateString(loc())}</T>
      </View>
      {n.body ? <T v="small" numberOfLines={2} style={{ color: c.foreground, opacity: 0.8 }}>{n.body}</T> : null}
      <View style={{ flexDirection: "row", gap: 6, flexWrap: "wrap" }}>
        {b ? <Pill label={b.name} color={b.color} /> : null}
        {n.modelLabel ? <Pill label={n.modelLabel} /> : null}
        {n.client ? <Pill label={`Client : ${n.client}`} /> : null}
        {n.tags.map((t) => <Pill key={t} label={`#${t}`} color={c.primary} />)}
        {n.attachments.length ? <Pill label={`${n.attachments.length} pièce(s) jointe(s)`} /> : null}
      </View>
    </Card>
  );
}
