const staticExpo = require("./app.json").expo;
const profile = process.env.EAS_BUILD_PROFILE;
const isProduction = profile ? profile === "production" : process.env.NODE_ENV === "production";
const apiUrl = process.env.EXPO_PUBLIC_API_URL || (isProduction ? "" : staticExpo.extra?.apiUrl || "");

if (isProduction && !apiUrl) {
  throw new Error("EXPO_PUBLIC_API_URL must point to the production HVAC Pro Ref API before a production build.");
}

module.exports = {
  expo: {
    ...staticExpo,
    extra: {
      ...staticExpo.extra,
      apiUrl,
    },
  },
};
