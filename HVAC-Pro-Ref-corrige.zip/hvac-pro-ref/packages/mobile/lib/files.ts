import { Linking, Platform, Alert } from "react-native";
import * as DocumentPicker from "expo-document-picker";
import * as ImagePicker from "expo-image-picker";
import * as FileSystem from "expo-file-system/legacy";
import * as IntentLauncher from "expo-intent-launcher";
import type { Attachment } from "./store";
import { tr } from "./i18n";

async function persist(uri: string, name: string): Promise<string> {
  if (Platform.OS === "web" || !FileSystem.documentDirectory) return uri;
  const dir = FileSystem.documentDirectory + "fichiers/";
  try {
    await FileSystem.makeDirectoryAsync(dir, { intermediates: true });
  } catch {}
  const safe = `${Date.now()}-${name.replace(/[^\w.-]/g, "_")}`;
  const dest = dir + safe;
  await FileSystem.copyAsync({ from: uri, to: dest });
  return dest;
}

export async function pickDocument(): Promise<Attachment | null> {
  const r = await DocumentPicker.getDocumentAsync({ type: ["application/pdf", "image/*", "*/*"], copyToCacheDirectory: true });
  if (r.canceled || !r.assets?.[0]) return null;
  const a = r.assets[0];
  const uri = await persist(a.uri, a.name);
  const kind = a.mimeType?.includes("pdf") || a.name.toLowerCase().endsWith(".pdf") ? "pdf" : a.mimeType?.startsWith("image") ? "image" : "file";
  return { name: a.name, uri, kind };
}

export async function pickPhoto(camera = false): Promise<Attachment | null> {
  if (camera) {
    const p = await ImagePicker.requestCameraPermissionsAsync();
    if (!p.granted) {
      Alert.alert(tr("Permission refusée"), tr("Autorisez l'accès à la caméra dans les réglages."));
      return null;
    }
  }
  const r = camera
    ? await ImagePicker.launchCameraAsync({ quality: 0.7 })
    : await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], quality: 0.7 });
  if (r.canceled || !r.assets?.[0]) return null;
  const a = r.assets[0];
  const name = a.fileName ?? `photo-${Date.now()}.jpg`;
  const uri = await persist(a.uri, name);
  return { name, uri, kind: "image" };
}

export async function openAttachment(a: Attachment) {
  try {
    if (Platform.OS === "android" && a.uri.startsWith("file://")) {
      const contentUri = await FileSystem.getContentUriAsync(a.uri);
      await IntentLauncher.startActivityAsync("android.intent.action.VIEW", {
        data: contentUri,
        flags: 1,
        type: a.kind === "pdf" ? "application/pdf" : a.kind === "image" ? "image/*" : "*/*",
      });
      return;
    }
    await Linking.openURL(a.uri);
  } catch {
    Alert.alert(tr("Impossible d'ouvrir"), tr("Aucune application compatible trouvée pour ce fichier."));
  }
}

export const openUrl = (url: string) => Linking.openURL(url).catch(() => Alert.alert(tr("Lien"), tr("Impossible d'ouvrir le lien.")));
