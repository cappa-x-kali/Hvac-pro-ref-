import { MODELS, btuBucket } from "../data/models";
import { BRANDS } from "../data/brands";
import type { Model, SystemType } from "../data/types";
import type { CustomModel } from "./store";
import { loc } from "./i18n";

export type ModelFilters = {
  type?: SystemType;
  brandIds?: string[];
  btu?: number | null;
  refrigerant?: string | null;
  year?: number | null;
};

const clean = (s: string) => s.toUpperCase().replace(/[\s\-/*]/g, "");

export function allModels(custom: CustomModel[]): (Model | CustomModel)[] {
  return [...custom, ...MODELS];
}

export function brandName(m: Model | CustomModel) {
  if ("brandName" in m && m.brandName) return m.brandName;
  return BRANDS.find((b) => b.id === m.brandId)?.name ?? m.brandId;
}

export function searchModels(q: string, f: ModelFilters, custom: CustomModel[]) {
  const n = clean(q);
  const words = q.toLowerCase().split(/\s+/).filter(Boolean);
  return allModels(custom).filter((m) => {
    if (f.type && m.type !== f.type) return false;
    if (f.brandIds?.length && !f.brandIds.includes(m.brandId)) return false;
    if (f.btu && m.btu !== f.btu && btuBucket(m.type, m.btu) !== f.btu) return false;
    if (f.refrigerant && m.refrigerant !== f.refrigerant) return false;
    if (f.year && (m.yearFrom > f.year || (m.yearTo ?? 9999) < f.year)) return false;
    if (!n) return true;
    const hay = [m.indoor, m.outdoor ?? "", m.series, brandName(m), String(m.btu), m.refrigerant, (m as CustomModel).serial ?? "", m.zones ? "multi multizone multi-zone zones" : ""].join(" ");
    const hayClean = clean(hay);
    if (hayClean.includes(n)) return true;
    // Correspondance par modèle avec jokers (*)
    const pattern = clean(m.indoor).replace(/\\/g, "");
    if (pattern && n.length >= 4 && matchWildcard(m.indoor, q)) return true;
    return words.every((w) => hay.toLowerCase().includes(w));
  });
}

function matchWildcard(model: string, q: string) {
  const re = new RegExp("^" + clean(model).split("").map((ch) => (ch === "*" ? "." : ch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))).join(""), "i");
  const target = clean(q);
  const short = model.replace(/[\s\-/]/g, "").toUpperCase();
  const re2 = new RegExp("^" + short.split("").map((ch) => (ch === "*" ? "." : ch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))).join(""), "i");
  return re.test(target) || re2.test(target) || target.startsWith(short.replace(/\*/g, ""));
}

export const fmtTons = (b: number) => `${(b / 12000).toLocaleString(loc(), { maximumFractionDigits: 2 })} t`;
/** « 12k (1 t) » */
export const fmtK = (b: number) => `${(b / 1000).toLocaleString(loc())}k (${fmtTons(b)})`;
/** « 12 k BTU (1 t) » */
export const fmtBtu = (b: number) => `${(b / 1000).toLocaleString(loc())} k BTU (${fmtTons(b)})`;
/** Au-delà de 36k, les « muraux » sont en pratique des multi-zones / gainables. */
export const MURAL_SINGLE_MAX = 36000;
export const fmtYears = (m: { yearFrom: number; yearTo?: number }) => (m.yearTo ? `${m.yearFrom}–${m.yearTo}` : `${m.yearFrom}–auj.`);
