import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useColorScheme } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { THEMES, type ThemeColors, type ThemeId } from "../constants/theme";
import type { Model, Refrigerant, SystemType } from "../data/types";
import { setLang, type Lang } from "./i18n";

export type Attachment = { name: string; uri: string; kind: "pdf" | "image" | "file" };

export type Note = {
  id: string;
  title: string;
  body: string;
  brandId?: string;
  modelId?: string;
  modelLabel?: string;
  client?: string;
  address?: string;
  tags: string[];
  attachments: Attachment[];
  pinned?: boolean;
  createdAt: number;
  updatedAt: number;
};

export type CustomModel = Model & {
  brandName: string;
  serial?: string;
  remarks?: string;
  manuals: Attachment[];
};

/** Documents perso attachés à n'importe quel modèle (catalogue ou perso) */
export type ModelDocs = { photos: Attachment[]; parts: Attachment[]; wiring: Attachment[] };
export const EMPTY_DOCS: ModelDocs = { photos: [], parts: [], wiring: [] };

type Settings = {
  theme: ThemeId | "auto";
  tempUnit: "F" | "C";
  pressureUnit: "psig" | "kPa";
  primaryBrand?: string;
  favoriteBrands: string[];
  favoriteModels: string[];
  intro: boolean;
  /** Langue de l'interface — français par défaut */
  lang: Lang;
};

const DEFAULT_SETTINGS: Settings = {
  theme: "auto",
  tempUnit: "F",
  pressureUnit: "psig",
  favoriteBrands: [],
  favoriteModels: [],
  intro: true,
  lang: "fr",
};

type Store = {
  ready: boolean;
  settings: Settings;
  colors: ThemeColors;
  activeTheme: ThemeId;
  setSetting: <K extends keyof Settings>(k: K, v: Settings[K]) => void;
  toggleFavoriteBrand: (id: string) => void;
  toggleFavoriteModel: (id: string) => void;
  isFavBrand: (id: string) => boolean;
  isFavModel: (id: string) => boolean;
  /** Ordonne marques : principale, favoris, puis alphabétique */
  sortBrands: <T extends { id: string; name: string }>(list: T[]) => T[];
  notes: Note[];
  saveNote: (n: Partial<Note> & { id?: string }) => string;
  deleteNote: (id: string) => void;
  customModels: CustomModel[];
  saveCustomModel: (m: Partial<CustomModel> & { id?: string }) => string;
  deleteCustomModel: (id: string) => void;
  docsFor: (modelId: string) => ModelDocs;
  saveModelDocs: (modelId: string, patch: Partial<ModelDocs>) => void;
};

const Ctx = createContext<Store | null>(null);
const K = { settings: "hvac.settings.v1", notes: "hvac.notes.v1", models: "hvac.customModels.v1", docs: "hvac.modelDocs.v1" };
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
const isRecord = (value: unknown): value is Record<string, unknown> => !!value && typeof value === "object" && !Array.isArray(value);
function parseStored<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try { return JSON.parse(raw) as T; }
  catch { return fallback; }
}
async function persistStored(key: string, value: unknown) {
  try { await AsyncStorage.setItem(key, JSON.stringify(value)); }
  catch { console.warn(`[HVAC Pro Ref] Impossible de sauvegarder la cle locale: ${key}`); }
}

export function AppStoreProvider({ children }: { children: ReactNode }) {
  const system = useColorScheme();
  const [ready, setReady] = useState(false);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [notes, setNotes] = useState<Note[]>([]);
  const [customModels, setCustomModels] = useState<CustomModel[]>([]);
  const [modelDocs, setModelDocs] = useState<Record<string, ModelDocs>>({});

  useEffect(() => {
    (async () => {
      try {
        const [s, n, m, d] = await Promise.all([AsyncStorage.getItem(K.settings), AsyncStorage.getItem(K.notes), AsyncStorage.getItem(K.models), AsyncStorage.getItem(K.docs)]);
        const savedSettings = parseStored<unknown>(s, null);
        if (isRecord(savedSettings)) {
          const next = { ...DEFAULT_SETTINGS, ...savedSettings } as Settings;
          next.theme = next.theme === "auto" || (typeof next.theme === "string" && next.theme in THEMES) ? next.theme : "auto";
          next.tempUnit = next.tempUnit === "C" ? "C" : "F";
          next.pressureUnit = next.pressureUnit === "kPa" ? "kPa" : "psig";
          next.lang = next.lang === "en" ? "en" : "fr";
          next.favoriteBrands = Array.isArray(next.favoriteBrands) ? next.favoriteBrands.filter((x): x is string => typeof x === "string") : [];
          next.favoriteModels = Array.isArray(next.favoriteModels) ? next.favoriteModels.filter((x): x is string => typeof x === "string") : [];
          setSettings(next);
        }
        const savedNotes = parseStored<unknown>(n, []);
        if (Array.isArray(savedNotes)) setNotes(savedNotes as Note[]);
        const savedModels = parseStored<unknown>(m, []);
        if (Array.isArray(savedModels)) setCustomModels(savedModels as CustomModel[]);
        const savedDocs = parseStored<unknown>(d, {});
        if (isRecord(savedDocs)) setModelDocs(savedDocs as Record<string, ModelDocs>);
      } catch (error) {
        console.warn("[HVAC Pro Ref] Chargement des donnees locales partiellement impossible.", error);
      }
      setReady(true);
    })();
  }, []);

  useEffect(() => { setLang(settings.lang === "en" ? "en" : "fr"); }, [settings.lang]);
  useEffect(() => { if (ready) void persistStored(K.settings, settings); }, [settings, ready]);
  useEffect(() => { if (ready) void persistStored(K.notes, notes); }, [notes, ready]);
  useEffect(() => { if (ready) void persistStored(K.models, customModels); }, [customModels, ready]);
  useEffect(() => { if (ready) void persistStored(K.docs, modelDocs); }, [modelDocs, ready]);

  const activeTheme: ThemeId = settings.theme === "auto" ? (system === "dark" ? "nuit" : "glacier") : THEMES[settings.theme] ? settings.theme : "glacier";
  const colors = THEMES[activeTheme].colors;

  const setSetting = useCallback(<Key extends keyof Settings>(k: Key, v: Settings[Key]) => setSettings((p) => ({ ...p, [k]: v })), []);

  const toggleFavoriteBrand = useCallback((id: string) => setSettings((p) => {
    const has = p.favoriteBrands.includes(id);
    return { ...p, favoriteBrands: has ? p.favoriteBrands.filter((x) => x !== id) : [...p.favoriteBrands, id], primaryBrand: has && p.primaryBrand === id ? undefined : p.primaryBrand };
  }), []);
  const toggleFavoriteModel = useCallback((id: string) => setSettings((p) => ({
    ...p, favoriteModels: p.favoriteModels.includes(id) ? p.favoriteModels.filter((x) => x !== id) : [id, ...p.favoriteModels],
  })), []);

  const sortBrands = useCallback(<T extends { id: string; name: string }>(list: T[]) => {
    const rank = (id: string) => (id === settings.primaryBrand ? 0 : settings.favoriteBrands.includes(id) ? 1 + settings.favoriteBrands.indexOf(id) / 100 : 2);
    return [...list].sort((a, b) => rank(a.id) - rank(b.id) || a.name.localeCompare(b.name));
  }, [settings.primaryBrand, settings.favoriteBrands]);

  const saveNote = useCallback((n: Partial<Note> & { id?: string }) => {
    const id = n.id ?? uid();
    setNotes((prev) => {
      const ex = prev.find((x) => x.id === id);
      const now = Date.now();
      if (ex) return prev.map((x) => (x.id === id ? { ...x, ...n, id, updatedAt: now } : x));
      return [{ title: "", body: "", tags: [], attachments: [], createdAt: now, updatedAt: now, ...n, id } as Note, ...prev];
    });
    return id;
  }, []);
  const deleteNote = useCallback((id: string) => setNotes((p) => p.filter((x) => x.id !== id)), []);

  const saveCustomModel = useCallback((m: Partial<CustomModel> & { id?: string }) => {
    const id = m.id ?? `custom:${uid()}`;
    setCustomModels((prev) => {
      const ex = prev.find((x) => x.id === id);
      if (ex) return prev.map((x) => (x.id === id ? { ...x, ...m, id } : x));
      return [{
        brandId: "custom", brandName: "", type: "mural" as SystemType, series: "Perso", indoor: "", btu: 12000,
        refrigerant: "R410A" as Refrigerant, yearFrom: new Date().getFullYear(), voltage: "", manuals: [], custom: true, ...m, id,
      } as CustomModel, ...prev];
    });
    return id;
  }, []);
  const deleteCustomModel = useCallback((id: string) => setCustomModels((p) => p.filter((x) => x.id !== id)), []);

  const docsFor = useCallback((id: string) => ({ ...EMPTY_DOCS, ...modelDocs[id] }), [modelDocs]);
  const saveModelDocs = useCallback((id: string, patch: Partial<ModelDocs>) => setModelDocs((p) => ({ ...p, [id]: { ...EMPTY_DOCS, ...p[id], ...patch } })), []);

  const value = useMemo<Store>(() => ({
    ready, settings, colors, activeTheme, setSetting, toggleFavoriteBrand, toggleFavoriteModel,
    isFavBrand: (id) => settings.favoriteBrands.includes(id),
    isFavModel: (id) => settings.favoriteModels.includes(id),
    sortBrands, notes, saveNote, deleteNote, customModels, saveCustomModel, deleteCustomModel, docsFor, saveModelDocs,
  }), [ready, settings, colors, activeTheme, setSetting, toggleFavoriteBrand, toggleFavoriteModel, sortBrands, notes, saveNote, deleteNote, customModels, saveCustomModel, deleteCustomModel, docsFor, saveModelDocs]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useStore hors AppStoreProvider");
  return c;
}
