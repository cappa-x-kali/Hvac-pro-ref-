import { Children, isValidElement, useSyncExternalStore, type ReactNode } from "react";
import { EN, EN_PATTERNS } from "../data/i18n-en";

export type Lang = "fr" | "en";

/** Langue courante (globale, pour fonctionner aussi hors du AppStoreProvider). Français par défaut. */
let current: Lang = "fr";
const listeners = new Set<() => void>();

export function setLang(l: Lang) {
  if (l === current) return;
  current = l;
  listeners.forEach((f) => f());
}
export const getLang = () => current;
const subscribe = (f: () => void) => {
  listeners.add(f);
  return () => listeners.delete(f);
};
export function useLang(): Lang {
  return useSyncExternalStore(subscribe, getLang, getLang);
}

/** Locale pour les nombres et dates. */
export const loc = () => (current === "en" ? "en-CA" : "fr-CA");

const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

type Pat = { re: RegExp; idx: number[]; out: string; weight: number };
const PATTERNS: Pat[] = Object.entries(EN_PATTERNS)
  .map(([fr, en]) => {
    const idx: number[] = [];
    const parts = fr.split(/\{(\d+)\}/);
    let src = "";
    parts.forEach((p, i) => {
      if (i % 2 === 0) src += escapeRe(p);
      else {
        idx.push(Number(p));
        src += "([\\s\\S]*?)";
      }
    });
    return { re: new RegExp(`^${src}$`), idx, out: en, weight: fr.replace(/\{\d+\}/g, "").length };
  })
  .sort((a, b) => b.weight - a.weight);

const cache = new Map<string, string>();

function core(s: string, depth: number): string | undefined {
  const exact = EN[s];
  if (exact !== undefined) return exact;
  if (depth > 2) return undefined;
  for (const p of PATTERNS) {
    const m = p.re.exec(s);
    if (!m) continue;
    let out = p.out;
    p.idx.forEach((n, i) => {
      const cap = m[i + 1] ?? "";
      const t = cap.trim() ? core(cap.trim(), depth + 1) : undefined;
      out = out.split(`{${n}}`).join(t !== undefined ? cap.replace(cap.trim(), t) : cap);
    });
    return out;
  }
  return undefined;
}

/** Unités et abréviations françaises restantes (pi² → ft², ex. → e.g.). */
const units = (s: string) =>
  s
    .replace(/(\d|\s)pi²/g, "$1ft²")
    .replace(/(\d|\s)pi³/g, "$1ft³")
    .replace(/(\d|\s)pi\/min/g, "$1ft/min")
    .replace(/\bPieds² \(pi²\)/g, "Square feet (ft²)")
    .replace(/\(pi²\)/g, "(ft²)")
    .replace(/\bex\. /g, "e.g. ");

/** Traduit une chaîne française vers la langue courante (identité en français ou si inconnue). */
export function tr(s: string, lang: Lang = current): string {
  if (lang === "fr" || !s) return s;
  const hit = cache.get(s);
  if (hit !== undefined) return hit;
  let res = core(s, 0);
  if (res === undefined) {
    const t = s.trim();
    if (t && t !== s) {
      const r = core(t, 0);
      if (r !== undefined) res = s.replace(t, r);
    }
  }
  const out = units(res ?? s);
  cache.set(s, out);
  return out;
}

/** Traduit des enfants React (chaînes, nombres, tableaux) en conservant les éléments. */
export function trNode(children: ReactNode, lang: Lang = current): ReactNode {
  if (lang === "fr") return children;
  if (typeof children === "string") return tr(children, lang);
  if (Array.isArray(children)) {
    const flat = children.every((c) => typeof c === "string" || typeof c === "number" || c === null || c === undefined || typeof c === "boolean");
    if (flat) {
      const joined = children.filter((c) => typeof c === "string" || typeof c === "number").join("");
      const t = tr(joined, lang);
      if (t !== joined) return t;
    }
    return Children.map(children, (c) => (typeof c === "string" ? tr(c, lang) : isValidElement(c) ? c : c));
  }
  return children;
}
