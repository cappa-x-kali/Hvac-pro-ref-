import { Platform } from "react-native";
import { IrBlaster } from "../modules/ir-blaster";
import type { IrFrame } from "../data/ir-protocols";

export type IrStatus = "ready" | "no-emitter" | "no-module" | "web";

export function irStatus(): IrStatus {
  if (Platform.OS === "web") return "web";
  if (!IrBlaster) return "no-module";
  try {
    return IrBlaster.hasEmitter() ? "ready" : "no-emitter";
  } catch {
    return "no-emitter";
  }
}

export function irFrequencies(): number[][] {
  try {
    return IrBlaster?.frequencies() ?? [];
  } catch {
    return [];
  }
}

export async function irSend(f: IrFrame): Promise<void> {
  if (!IrBlaster) throw new Error("Module IR absent de ce build");
  await IrBlaster.transmit(f.frequency, f.pattern);
}
