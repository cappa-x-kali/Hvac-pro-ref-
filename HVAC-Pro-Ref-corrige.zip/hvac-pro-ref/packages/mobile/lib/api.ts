import Constants from "expo-constants";
import { createORPCClient } from "@orpc/client";
import { RPCLink } from "@orpc/client/fetch";
import { createTanstackQueryUtils } from "@orpc/tanstack-query";
import type { AppRouterClient } from "@hvac-pro-ref/web";

const configuredBaseUrl = Constants.expoConfig?.extra?.apiUrl ?? process.env.EXPO_PUBLIC_API_URL;
if (!configuredBaseUrl) {
  throw new Error("API URL missing. Configure EXPO_PUBLIC_API_URL for this build.");
}
// Avoid malformed double slashes when Expo config provides a trailing slash.
const baseUrl = configuredBaseUrl.replace(/\/+$/, "");

const link = new RPCLink({
  url: `${baseUrl}/api/rpc`,
});

/** Direct typed client: await client.ping() */
export const client: AppRouterClient = createORPCClient(link);

/** TanStack Query helpers: useQuery(orpc.ping.queryOptions()) */
export const orpc = createTanstackQueryUtils(client);
