import { ipcMain, dialog, Notification, type BrowserWindow, type IpcMainInvokeEvent } from "electron";

/** Reject IPC calls from iframes, navigated pages, or any renderer other than our main window. */
function assertTrustedSender(event: IpcMainInvokeEvent, getWindow: () => BrowserWindow | null) {
  const win = getWindow();
  if (!win || event.sender !== win.webContents || event.senderFrame !== win.webContents.mainFrame) {
    throw new Error("Unauthorized IPC sender");
  }
}

export function registerIpcHandlers(getWindow: () => BrowserWindow | null) {
  ipcMain.handle("dialog:open", async (event, opts: Electron.OpenDialogOptions = {}) => {
    assertTrustedSender(event, getWindow);
    const win = getWindow();
    const result = win ? await dialog.showOpenDialog(win, opts) : await dialog.showOpenDialog(opts);
    return result.canceled ? [] : result.filePaths;
  });

  ipcMain.handle("dialog:save", async (event, opts: Electron.SaveDialogOptions = {}) => {
    assertTrustedSender(event, getWindow);
    const win = getWindow();
    const result = win ? await dialog.showSaveDialog(win, opts) : await dialog.showSaveDialog(opts);
    return result.canceled ? null : result.filePath;
  });

  ipcMain.handle("notification:show", (event, title: string, body: string) => {
    assertTrustedSender(event, getWindow);
    if (!Notification.isSupported()) return false;
    new Notification({
      title: String(title ?? "HVAC Pro Ref").slice(0, 120),
      body: String(body ?? "").slice(0, 500),
    }).show();
    return true;
  });

  ipcMain.handle("window:minimize", (event) => {
    assertTrustedSender(event, getWindow);
    getWindow()?.minimize();
  });
  ipcMain.handle("window:maximize", (event) => {
    assertTrustedSender(event, getWindow);
    const win = getWindow();
    if (win?.isMaximized()) win.unmaximize();
    else win?.maximize();
  });
  ipcMain.handle("window:close", (event) => {
    assertTrustedSender(event, getWindow);
    getWindow()?.close();
  });
}
